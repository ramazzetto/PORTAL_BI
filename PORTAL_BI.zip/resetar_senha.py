"""
Script de recuperacao: redefine a senha de um usuario direto no banco de
dados, sem precisar que o portal esteja rodando nem de outro admin
disponivel. Use isso se voce esquecer sua propria senha e nao tiver
pergunta de seguranca configurada.

Uso:
    python resetar_senha.py

Precisa estar na mesma pasta do projeto, com o arquivo .env presente
(usa as mesmas variaveis DB_HOST/DB_PORT/DB_USER/DB_PASSWORD/DB_NAME que
o app.py ja usa).

Este script e uma ferramenta de manutencao para uso local, no seu
computador -- nunca deixe ele acessivel publicamente nem o suba para
nenhum servidor exposto na internet.
"""

import os
import sys
import getpass

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

import pymysql
import pymysql.cursors
from werkzeug.security import generate_password_hash

SENHA_REGRA = (
    "A senha deve ter pelo menos 6 caracteres, incluindo 1 letra maiuscula, "
    "1 numero e 1 caractere especial."
)


def senha_valida(senha):
    if len(senha) < 6:
        return False
    tem_maiuscula = any(c.isupper() for c in senha)
    tem_numero = any(c.isdigit() for c in senha)
    tem_especial = any(not c.isalnum() for c in senha)
    return tem_maiuscula and tem_numero and tem_especial


def conectar():
    host = os.environ.get("DB_HOST", "localhost")
    port = int(os.environ.get("DB_PORT", "3306"))
    user = os.environ.get("DB_USER")
    password = os.environ.get("DB_PASSWORD")
    database = os.environ.get("DB_NAME")

    if not all([user, password, database]):
        print("ERRO: nao encontrei as variaveis do banco (DB_USER/DB_PASSWORD/DB_NAME).")
        print("Rode este script de dentro da pasta do projeto, com o arquivo .env presente.")
        sys.exit(1)

    try:
        return pymysql.connect(
            host=host, port=port, user=user, password=password,
            database=database, charset="utf8mb4",
            cursorclass=pymysql.cursors.DictCursor,
        )
    except pymysql.err.OperationalError as e:
        print(f"ERRO ao conectar no banco: {e}")
        print("Confira se o MySQL/MariaDB esta rodando e se os dados do .env estao corretos.")
        sys.exit(1)


def main():
    print("=" * 55)
    print("  Portal BI - Redefinir senha (recuperacao de acesso)")
    print("=" * 55)

    conn = conectar()
    try:
        with conn.cursor() as cur:
            login = input("\nUsuario (login) que tera a senha trocada: ").strip()
            if not login:
                print("Login vazio, cancelado.")
                return

            cur.execute("SELECT id, nome, papel FROM usuarios WHERE usuario = %s", (login,))
            usuario = cur.fetchone()
            if not usuario:
                print(f"\nNenhum usuario encontrado com o login '{login}'.")
                return

            print(f"\nUsuario encontrado: {usuario['nome']} ({usuario['papel']})")

            nova_senha = getpass.getpass("Nova senha (nao aparece na tela ao digitar): ")
            confirmar = getpass.getpass("Confirme a nova senha: ")

            if nova_senha != confirmar:
                print("\nAs senhas digitadas nao coincidem. Cancelado, nada foi alterado.")
                return

            if not senha_valida(nova_senha):
                print(f"\nSenha fraca demais. {SENHA_REGRA}")
                print("Nada foi alterado.")
                return

            resposta = input(f"\nConfirma trocar a senha de '{login}'? (s/n): ").strip().lower()
            if resposta != "s":
                print("Cancelado, nada foi alterado.")
                return

            hash_novo = generate_password_hash(nova_senha)
            cur.execute("UPDATE usuarios SET senha_hash = %s WHERE id = %s", (hash_novo, usuario["id"]))
        conn.commit()
        print(f"\nSenha de '{login}' redefinida com sucesso!")
        print("Voce ja pode fazer login normalmente no portal com a nova senha.")
    finally:
        conn.close()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nCancelado.")