@echo off
chcp 65001 >nul
setlocal

set "ORIGEM=C:\Users\RodrigoMazzetto\Downloads\"
set "PASTA_HTML=C:\Users\RodrigoMazzetto\OneDrive - GNX Group\Área de Trabalho\Portal BI\Principal\templates"
set "PASTA_CSS=C:\Users\RodrigoMazzetto\OneDrive - GNX Group\Área de Trabalho\Portal BI\Principal\static\css"
set "PASTA_PY=C:\Users\RodrigoMazzetto\OneDrive - GNX Group\Área de Trabalho\Portal BI\Principal"
set "PASTA_MD=C:\Users\RodrigoMazzetto\OneDrive - GNX Group\Área de Trabalho\Portal BI\Principal"

if not exist "%PASTA_HTML%" mkdir "%PASTA_HTML%"
if not exist "%PASTA_CSS%" mkdir "%PASTA_CSS%"
if not exist "%PASTA_PY%" mkdir "%PASTA_PY%"
if not exist "%PASTA_MD%" mkdir "%PASTA_MD%"

echo Movendo arquivos .html...
copy /Y "%ORIGEM%*.html" "%PASTA_HTML%"
if %ERRORLEVEL% EQU 0 (
    del /F /Q "%ORIGEM%*.html"
) else (
    echo   Aviso: copia de .html falhou -- arquivos NAO foram apagados de Downloads.
)

echo.
echo Movendo arquivos .css...
copy /Y "%ORIGEM%*.css" "%PASTA_CSS%"
if %ERRORLEVEL% EQU 0 (
    del /F /Q "%ORIGEM%*.css"
) else (
    echo   Aviso: copia de .css falhou -- arquivos NAO foram apagados de Downloads.
)

echo.
echo Movendo arquivos .py...
copy /Y "%ORIGEM%*.py" "%PASTA_PY%"
if %ERRORLEVEL% EQU 0 (
    del /F /Q "%ORIGEM%*.py"
) else (
    echo   Aviso: copia de .py falhou -- arquivos NAO foram apagados de Downloads.
)

echo.
echo Movendo arquivos .md...
copy /Y "%ORIGEM%*.md" "%PASTA_MD%"
if %ERRORLEVEL% EQU 0 (
    del /F /Q "%ORIGEM%*.md"
) else (
    echo   Aviso: copia de .md falhou -- arquivos NAO foram apagados de Downloads.
)

echo.
echo Concluido.
