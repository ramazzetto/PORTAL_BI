"""Envio de e-mails transacionais do Portal BI.

Este módulo usa apenas a biblioteca padrão do Python. As credenciais ficam
exclusivamente no arquivo .env / nas variáveis do servidor, nunca no código
ou no banco de dados.
"""

from email.message import EmailMessage
from email.utils import parseaddr
from html import escape
import os
import smtplib
import ssl


class EmailNaoConfigurado(RuntimeError):
    """A recuperação foi usada antes de o SMTP do portal ser configurado."""


class EmailEnvioFalhou(RuntimeError):
    """O SMTP estava configurado, mas não aceitou ou não entregou o envio."""


def _bool_env(nome, padrao):
    valor = os.environ.get(nome, padrao).strip().lower()
    if valor not in {"true", "false"}:
        raise EmailNaoConfigurado(f"{nome} deve ser true ou false.")
    return valor == "true"


def obter_configuracao_email():
    """Lê e valida a configuração SMTP no momento do envio.

    A leitura tardia facilita testar configurações sem precisar manter
    credenciais em memória. Também impede tentativa de envio com um destino
    ou remetente incompleto.
    """
    host = os.environ.get("SMTP_HOST", "").strip()
    remetente = os.environ.get("SMTP_REMETENTE", "").strip()
    _, endereco_remetente = parseaddr(remetente)
    if (
        not host or not remetente or not endereco_remetente or "@" not in endereco_remetente
        or any(quebra in valor for valor in (host, remetente) for quebra in ("\r", "\n"))
    ):
        raise EmailNaoConfigurado(
            "Configure SMTP_HOST e SMTP_REMETENTE no arquivo .env para usar a recuperação por e-mail."
        )
    try:
        porta = int(os.environ.get("SMTP_PORT", "587"))
    except ValueError:
        raise EmailNaoConfigurado("SMTP_PORT deve ser um número entre 1 e 65535.") from None
    if not 1 <= porta <= 65535:
        raise EmailNaoConfigurado("SMTP_PORT deve ficar entre 1 e 65535.")

    usar_tls = _bool_env("SMTP_USAR_TLS", "true")
    usar_ssl = _bool_env("SMTP_USAR_SSL", "false")
    if usar_tls and usar_ssl:
        raise EmailNaoConfigurado("Use somente SMTP_USAR_TLS ou SMTP_USAR_SSL, nunca os dois.")

    usuario = os.environ.get("SMTP_USUARIO", "").strip()
    senha = os.environ.get("SMTP_SENHA", "")
    if any(quebra in usuario for quebra in ("\r", "\n")):
        raise EmailNaoConfigurado("SMTP_USUARIO é inválido.")
    if usuario and not senha:
        raise EmailNaoConfigurado("SMTP_SENHA é obrigatória quando SMTP_USUARIO estiver informado.")

    return {
        "host": host,
        "porta": porta,
        "remetente": remetente,
        "usuario": usuario,
        "senha": senha,
        "usar_tls": usar_tls,
        "usar_ssl": usar_ssl,
    }


def _montar_html_redefinicao(nome_exibicao, link, validade_minutos):
    """Monta o HTML do e-mail seguindo a identidade visual dark do Portal BI.

    O CSS fica inline e a estrutura usa tabelas para manter a aparência
    estável nos principais clientes de e-mail. O link continua sendo o mesmo
    token assinado e nunca é alterado por esta camada visual.
    """
    nome_html = escape(nome_exibicao)
    link_html = escape(link, quote=True)
    validade_html = escape(str(validade_minutos))
    return f"""\\
<!doctype html>
<html lang="pt-BR">
  <body style="margin:0;padding:0;background-color:#0f1218;color:#edf2fa;font-family:Arial,Helvetica,sans-serif;-webkit-text-size-adjust:100%;">
    <div style="display:none;max-height:0;overflow:hidden;opacity:0;color:transparent;">
      Link seguro para criar uma nova senha no Portal BI.
    </div>
    <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="width:100%;margin:0;background-color:#0f1218;border-collapse:collapse;">
      <tr>
        <td align="center" style="padding:34px 16px 38px;">
          <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="width:100%;max-width:620px;border-collapse:separate;border-spacing:0;background-color:#171b24;border:1px solid #2a3549;border-radius:16px;overflow:hidden;">
            <tr>
              <td height="4" style="height:4px;background-color:#306fe9;background-image:linear-gradient(100deg,#184aa2 0%,#1f5fca 58%,#4c9dff 100%);font-size:0;line-height:0;">&nbsp;</td>
            </tr>
            <tr>
              <td style="padding:30px 34px 34px;">
                <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="width:100%;border-collapse:collapse;">
                  <tr>
                    <td style="padding:0 0 4px;color:#edf2fa;font-family:Bahnschrift,'Arial Narrow',Arial,Helvetica,sans-serif;font-size:21px;line-height:1.2;font-weight:700;letter-spacing:-.02em;">
                      <span style="display:inline-block;width:9px;height:9px;margin:0 8px 2px 0;border-radius:50%;background-color:#4c9dff;box-shadow:0 0 12px rgba(76,157,255,.65);">&nbsp;</span>Portal BI
                    </td>
                  </tr>
                  <tr>
                    <td style="padding:0 0 28px;color:#7f9ac3;font-family:Bahnschrift,'Arial Narrow',Arial,Helvetica,sans-serif;font-size:9px;line-height:1.3;font-weight:600;letter-spacing:.16em;text-transform:uppercase;">
                      ANÁLISE DE DADOS EM MOVIMENTO
                    </td>
                  </tr>
                  <tr>
                    <td style="padding:0 0 10px;color:#edf2fa;font-size:28px;line-height:1.2;font-weight:700;letter-spacing:-.025em;">
                      Redefinição de senha
                    </td>
                  </tr>
                  <tr>
                    <td style="padding:0;color:#edf2fa;font-size:15px;line-height:1.7;">
                      Olá, {nome_html}.
                    </td>
                  </tr>
                  <tr>
                    <td style="padding:8px 0 0;color:#b6c1d2;font-size:15px;line-height:1.7;">
                      Recebemos uma solicitação para redefinir a senha da sua conta no Portal BI.
                    </td>
                  </tr>
                  <tr>
                    <td style="padding:28px 0 26px;">
                      <a href="{link_html}" style="display:inline-block;padding:13px 20px;border:1px solid #4c9dff;border-radius:9px;background-color:#306fe9;background-image:linear-gradient(115deg,#184aa2 0%,#1f5fca 58%,#4c9dff 100%);color:#ffffff;text-decoration:none;font-size:14px;line-height:1.2;font-weight:700;">
                        Criar nova senha
                      </a>
                    </td>
                  </tr>
                  <tr>
                    <td style="padding:15px 16px;border-left:3px solid #306fe9;background-color:#1d2635;color:#b6c1d2;font-size:13px;line-height:1.65;">
                      Este link expira em <strong style="color:#edf2fa;">{validade_html} minutos</strong> e deixa de valer assim que a senha for alterada.
                    </td>
                  </tr>
                  <tr>
                    <td style="padding:24px 0 0;color:#8e9db2;font-size:13px;line-height:1.65;">
                      Se você não solicitou esta alteração, ignore este e-mail. Sua senha atual permanece protegida.
                    </td>
                  </tr>
                  <tr>
                    <td style="padding:28px 0 0;border-top:1px solid #2a3549;color:#718096;font-size:11px;line-height:1.5;">
                      Este é um e-mail automático do Portal BI. Não responda a esta mensagem.
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
  </body>
</html>"""


def enviar_email_redefinicao(destinatario, nome, link, validade_minutos):
    """Envia um e-mail de redefinição sem registrar senha ou token em log."""
    config = obter_configuracao_email()
    nome_exibicao = (nome or "").strip() or "usuário"
    assunto = "Redefinição de senha — Portal BI"
    texto = (
        f"Olá, {nome_exibicao}.\n\n"
        "Recebemos uma solicitação para redefinir a senha da sua conta no Portal BI.\n"
        f"Use este link para criar uma nova senha: {link}\n\n"
        f"O link expira em {validade_minutos} minutos e deixa de valer assim que a senha for alterada.\n"
        "Se você não solicitou esta alteração, ignore este e-mail."
    )
    html = _montar_html_redefinicao(nome_exibicao, link, validade_minutos)

    mensagem = EmailMessage()
    mensagem["Subject"] = assunto
    mensagem["From"] = config["remetente"]
    mensagem["To"] = destinatario
    mensagem.set_content(texto)
    mensagem.add_alternative(html, subtype="html")

    try:
        contexto = ssl.create_default_context()
        if config["usar_ssl"]:
            with smtplib.SMTP_SSL(
                config["host"], config["porta"], timeout=20, context=contexto
            ) as servidor:
                if config["usuario"]:
                    servidor.login(config["usuario"], config["senha"])
                servidor.send_message(mensagem)
        else:
            with smtplib.SMTP(config["host"], config["porta"], timeout=20) as servidor:
                servidor.ehlo()
                if config["usar_tls"]:
                    servidor.starttls(context=contexto)
                    servidor.ehlo()
                if config["usuario"]:
                    servidor.login(config["usuario"], config["senha"])
                servidor.send_message(mensagem)
    except (OSError, smtplib.SMTPException) as exc:
        raise EmailEnvioFalhou("Não foi possível enviar o e-mail de recuperação.") from exc
