"""
Camada de banco de dados (MySQL / MariaDB)
--------------------------------------------------------------------------
Substitui o armazenamento em arquivos JSON por um banco MySQL/MariaDB de
verdade, mantendo as MESMAS funcoes e formatos de dados que o app.py ja
usava (load_data/save_data, load_users/save_users, load_acessos etc.),
para que o resto do app.py nao precise ser reescrito.

Configuracao (variaveis de ambiente, com valores padrao para
desenvolvimento local):
  DB_HOST      -> host do MySQL/MariaDB (padrao: localhost)
  DB_PORT      -> porta (padrao: 3306)
  DB_USER      -> usuario do banco (padrao: portal_bi)
  DB_PASSWORD  -> senha do banco (padrao: vazio -- DEFINA em producao!)
  DB_NAME      -> nome do banco (padrao: portal_bi)

Em desenvolvimento local, se existir um arquivo ".env" na pasta do
projeto, ele e carregado automaticamente (veja app.py). Em producao
(Apache/mod_wsgi ou similar), defina essas variaveis no arquivo .wsgi ou
na configuracao do servidor -- nunca deixe a senha do banco escrita no
codigo.

As tabelas sao criadas automaticamente na primeira execucao
(CREATE TABLE IF NOT EXISTS), entao nao e preciso rodar nenhum script
de setup manual alem de criar o banco e o usuario no MySQL.
"""

import os
from pathlib import Path
from dotenv import load_dotenv
import uuid
import json
import hashlib
from datetime import datetime, timedelta
from contextlib import contextmanager
from queue import Empty, Full, LifoQueue
from threading import Lock

import pymysql
import pymysql.cursors
from flask import g, has_app_context, has_request_context
from ambientes import contexto_ambiente, INICIAL

# O arquivo desta instalação prevalece sobre valores herdados da IDE.
# Sem .env, mantém o suporte às variáveis definidas no servidor.
ARQUIVO_ENV = Path(__file__).resolve().parent / ".env"
if ARQUIVO_ENV.is_file():
    load_dotenv(ARQUIVO_ENV, override=True, encoding="utf-8-sig")

DB_HOST = os.environ.get("DB_HOST", "localhost")
DB_PORT = int(os.environ.get("DB_PORT", "3306"))
DB_USER = os.environ.get("DB_USER", "portal_bi")
DB_PASSWORD = os.environ.get("DB_PASSWORD", "")
DB_NAME = os.environ.get("DB_NAME", "portal_bi")
DB_POOL_MAX_CONEXOES = max(1, int(os.environ.get("DB_POOL_MAX_CONEXOES", "12")))
DB_POOL_TEMPO_ESPERA = max(1, int(os.environ.get("DB_POOL_TEMPO_ESPERA", "10")))
DB_CONNECT_TIMEOUT = max(1, int(os.environ.get("DB_CONNECT_TIMEOUT", "5")))



def _abrir_conexao():
    """Abre uma conexão física. O restante do módulo usa o pool abaixo."""
    return pymysql.connect(
        host=DB_HOST,
        port=DB_PORT,
        user=DB_USER,
        password=DB_PASSWORD,
        database=DB_NAME,
        charset="utf8mb4",
        cursorclass=pymysql.cursors.DictCursor,
        connect_timeout=DB_CONNECT_TIMEOUT,
        autocommit=False,
    )


class _ConexaoDoPool:
    """Fachada de uma conexão física devolvida ao pool ao ser fechada."""
    def __init__(self, pool, conexao_fisica, cursorclass):
        self._pool = pool
        self._conexao_fisica = conexao_fisica
        self._cursorclass = cursorclass
        self._fechada = False

    def cursor(self, cursor=None):
        return self._conexao_fisica.cursor(cursor or self._cursorclass)

    def close(self):
        if not self._fechada:
            self._fechada = True
            self._pool.devolver(self._conexao_fisica)

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    def __getattr__(self, nome):
        return getattr(self._conexao_fisica, nome)


class _PoolConexoes:
    """Pool pequeno, local ao processo e seguro entre as threads do Flask.

    Cada processo do Waitress possui seu próprio pool. O limite deve ser
    calculado por processo ao configurar o servidor e o MySQL/MariaDB.
    """
    def __init__(self, limite, espera):
        self._disponiveis = LifoQueue(maxsize=limite)
        self._limite = limite
        self._espera = espera
        self._quantidade = 0
        self._trava = Lock()

    def _descartar(self, conexao_fisica):
        try:
            conexao_fisica.close()
        finally:
            with self._trava:
                self._quantidade = max(0, self._quantidade - 1)

    def obter(self):
        while True:
            try:
                conexao_fisica = self._disponiveis.get_nowait()
            except Empty:
                with self._trava:
                    criar = self._quantidade < self._limite
                    if criar:
                        self._quantidade += 1
                if criar:
                    try:
                        return _abrir_conexao()
                    except Exception:
                        with self._trava:
                            self._quantidade = max(0, self._quantidade - 1)
                        raise
                try:
                    conexao_fisica = self._disponiveis.get(timeout=self._espera)
                except Empty as erro:
                    raise RuntimeError(
                        "O banco está no limite temporário de conexões do Portal BI. "
                        "Tente novamente em instantes."
                    ) from erro
            try:
                conexao_fisica.ping(reconnect=False)
                return conexao_fisica
            except Exception:
                self._descartar(conexao_fisica)

    def devolver(self, conexao_fisica):
        try:
            # Uma rotina que terminou por exceção pode ter deixado uma
            # transação aberta. O rollback deixa a conexão limpa para a
            # próxima requisição sem afetar operações que já deram commit.
            conexao_fisica.rollback()
            conexao_fisica.ping(reconnect=False)
            self._disponiveis.put_nowait(conexao_fisica)
        except (Exception, Full):
            self._descartar(conexao_fisica)


_POOL_CONEXOES = _PoolConexoes(DB_POOL_MAX_CONEXOES, DB_POOL_TEMPO_ESPERA)


def get_connection(cursorclass=pymysql.cursors.DictCursor):
    """Reserva uma conexão reutilizável e compatível com o cursor solicitado.

    ``close()`` não encerra a sessão física: ela a devolve limpa ao pool.
    Isso preserva os chamadores existentes e torna a mudança transparente
    tanto para o MySQL local quanto para o servidor futuro.
    """
    return _ConexaoDoPool(_POOL_CONEXOES, _POOL_CONEXOES.obter(), cursorclass)


@contextmanager
def conexao():
    """Context manager: reserva uma conexão, controla a transação e a
    devolve ao pool no final."""
    conn = get_connection()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


# ===========================================================================
# Criacao das tabelas (rodar uma vez, automaticamente, ao iniciar o app)
# ===========================================================================
@contextmanager
def _trava_migracao(conn):
    # ALTER TABLE faz commit implícito; um bloqueio transacional não basta
    # para impedir que dois processos tentem criar a mesma coluna/FK.
    nome = "portalbi:schema:" + hashlib.sha256(DB_NAME.encode()).hexdigest()[:32]
    with conn.cursor() as cur:
        cur.execute("SELECT GET_LOCK(%s, 30) AS obtido", (nome,))
        if cur.fetchone()["obtido"] != 1:
            raise RuntimeError("Outro processo está atualizando o banco. Aguarde e reinicie o portal.")
    try:
        yield
    finally:
        with conn.cursor() as cur:
            cur.execute("SELECT RELEASE_LOCK(%s)", (nome,))


def _garantir_indice(cur, tabela, nome, colunas):
    """Cria um índice aditivo somente quando ele ainda não existe.

    ``CREATE INDEX IF NOT EXISTS`` não é compatível com todas as versões de
    MySQL/MariaDB usadas pelo portal. A consulta ao catálogo mantém a
    migração idempotente e os valores abaixo são internos/fixos, nunca dados
    recebidos de formulário.
    """
    cur.execute(
        """SELECT COUNT(*) AS qtd FROM INFORMATION_SCHEMA.STATISTICS
           WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s AND INDEX_NAME = %s""",
        (DB_NAME, tabela, nome),
    )
    if not cur.fetchone()["qtd"]:
        cur.execute(f"ALTER TABLE `{tabela}` ADD INDEX `{nome}` ({colunas})")


def criar_tabelas():
    """Cria a estrutura principal e aplica pequenas migracoes idempotentes.

    A tabela de subpastas e a coluna ``dashboards.subpasta_id`` sao criadas
    automaticamente ao iniciar o portal. Assim, uma instalacao que ja possua
    dados nao precisa executar SQL manual para usar a nova organizacao.
    """
    with conexao() as conn, _trava_migracao(conn):
        with conn.cursor() as cur:
            cur.execute("""
                CREATE TABLE IF NOT EXISTS pastas (
                    id VARCHAR(32) PRIMARY KEY,
                    nome VARCHAR(255) NOT NULL,
                    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
            cur.execute("""
                CREATE TABLE IF NOT EXISTS subpastas (
                    id VARCHAR(32) PRIMARY KEY,
                    nome VARCHAR(255) NOT NULL,
                    pasta_id VARCHAR(32) NOT NULL,
                    parent_subpasta_id VARCHAR(32) NULL,
                    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_subpastas_pasta (pasta_id),
                    INDEX idx_subpastas_parent (parent_subpasta_id),
                    CONSTRAINT fk_subpastas_pasta
                        FOREIGN KEY (pasta_id) REFERENCES pastas(id) ON DELETE CASCADE,
                    CONSTRAINT fk_subpastas_parent
                        FOREIGN KEY (parent_subpasta_id) REFERENCES subpastas(id) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
            # Instalacoes que ja possuem subpastas recebem um segundo nivel
            # opcional. Subpastas atuais ficam com parent_subpasta_id = NULL
            # e continuam sendo as divisoes diretamente abaixo da pasta.
            cur.execute("""
                SELECT COUNT(*) AS qtd
                FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_SCHEMA = %s
                  AND TABLE_NAME = 'subpastas'
                  AND COLUMN_NAME = 'parent_subpasta_id'
            """, (DB_NAME,))
            if cur.fetchone()["qtd"] == 0:
                cur.execute("ALTER TABLE subpastas ADD COLUMN parent_subpasta_id VARCHAR(32) NULL AFTER pasta_id")

            cur.execute("""
                SELECT COUNT(*) AS qtd
                FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS
                WHERE CONSTRAINT_SCHEMA = %s
                  AND TABLE_NAME = 'subpastas'
                  AND CONSTRAINT_NAME = 'fk_subpastas_parent'
                  AND CONSTRAINT_TYPE = 'FOREIGN KEY'
            """, (DB_NAME,))
            if cur.fetchone()["qtd"] == 0:
                cur.execute("""
                    ALTER TABLE subpastas
                    ADD CONSTRAINT fk_subpastas_parent
                    FOREIGN KEY (parent_subpasta_id) REFERENCES subpastas(id)
                    ON DELETE CASCADE
                """)

            cur.execute("""
                CREATE TABLE IF NOT EXISTS dashboards (
                    id VARCHAR(32) PRIMARY KEY,
                    nome VARCHAR(255) NOT NULL,
                    descricao TEXT,
                    embed_url TEXT NOT NULL,
                    pasta_id VARCHAR(32),
                    subpasta_id VARCHAR(32),
                    ativo TINYINT(1) NOT NULL DEFAULT 1,
                    permitir_favoritar TINYINT(1) NOT NULL DEFAULT 1,
                    ordem_exibicao INT NOT NULL DEFAULT 0,
                    cadastrado_por VARCHAR(32) NULL,
                    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (pasta_id) REFERENCES pastas(id) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)

            # Instalacoes antigas ja possuem a tabela dashboards sem a coluna
            # de subpasta. Fazemos a migracao apenas quando necessario.
            cur.execute("""
                SELECT COUNT(*) AS qtd
                FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_SCHEMA = %s
                  AND TABLE_NAME = 'dashboards'
                  AND COLUMN_NAME = 'subpasta_id'
            """, (DB_NAME,))
            if cur.fetchone()["qtd"] == 0:
                cur.execute("ALTER TABLE dashboards ADD COLUMN subpasta_id VARCHAR(32) NULL AFTER pasta_id")

            # Opcoes de publicacao/exibicao adicionadas pelo novo cadastro.
            # Cada ALTER e idempotente para manter compatibilidade com bancos
            # instalados em versoes anteriores do portal.
            for coluna, definicao in (
                ("ativo", "TINYINT(1) NOT NULL DEFAULT 1"),
                ("permitir_favoritar", "TINYINT(1) NOT NULL DEFAULT 1"),
                ("ordem_exibicao", "INT NOT NULL DEFAULT 0"),
                ("cadastrado_por", "VARCHAR(32) NULL"),
            ):
                cur.execute("""
                    SELECT COUNT(*) AS qtd
                    FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE TABLE_SCHEMA = %s
                      AND TABLE_NAME = 'dashboards'
                      AND COLUMN_NAME = %s
                """, (DB_NAME, coluna))
                if cur.fetchone()["qtd"] == 0:
                    cur.execute(f"ALTER TABLE dashboards ADD COLUMN {coluna} {definicao}")

            # Garante a FK em bancos que foram migrados da versao anterior.
            cur.execute("""
                SELECT COUNT(*) AS qtd
                FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS
                WHERE CONSTRAINT_SCHEMA = %s
                  AND TABLE_NAME = 'dashboards'
                  AND CONSTRAINT_NAME = 'fk_dashboards_subpasta'
                  AND CONSTRAINT_TYPE = 'FOREIGN KEY'
            """, (DB_NAME,))
            if cur.fetchone()["qtd"] == 0:
                cur.execute("""
                    ALTER TABLE dashboards
                    ADD CONSTRAINT fk_dashboards_subpasta
                    FOREIGN KEY (subpasta_id) REFERENCES subpastas(id)
                    ON DELETE SET NULL
                """)

            cur.execute("""
                CREATE TABLE IF NOT EXISTS usuarios (
                    id VARCHAR(32) PRIMARY KEY,
                    nome VARCHAR(255) NOT NULL,
                    usuario VARCHAR(100) NOT NULL UNIQUE,
                    email VARCHAR(254) NOT NULL,
                    senha_hash VARCHAR(255) NOT NULL,
                    papel VARCHAR(20) NOT NULL,
                    troca_senha_obrigatoria TINYINT(1) NOT NULL DEFAULT 0,
                    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
            cur.execute("""
                SELECT COUNT(*) AS qtd FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_SCHEMA = %s AND TABLE_NAME = 'usuarios'
                  AND COLUMN_NAME = 'troca_senha_obrigatoria'
            """, (DB_NAME,))
            if cur.fetchone()["qtd"] == 0:
                cur.execute("ALTER TABLE usuarios ADD COLUMN troca_senha_obrigatoria TINYINT(1) NOT NULL DEFAULT 0")
            cur.execute("""
                SELECT COUNT(*) AS qtd FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_SCHEMA = %s AND TABLE_NAME = 'usuarios' AND COLUMN_NAME = 'email'
            """, (DB_NAME,))
            if cur.fetchone()["qtd"] == 0:
                cur.execute("ALTER TABLE usuarios ADD COLUMN email VARCHAR(254) NULL")
            cur.execute("""SELECT COUNT(*) AS qtd FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_SCHEMA = %s AND TABLE_NAME = 'usuarios' AND COLUMN_NAME = 'versao'""",
                        (DB_NAME,))
            if cur.fetchone()["qtd"] == 0:
                # Controle otimista: atualizações concorrentes de uma mesma
                # conta são detectadas sem bloquear ou regravar as demais.
                cur.execute("ALTER TABLE usuarios ADD COLUMN versao INT NOT NULL DEFAULT 1")
            # O perfil Gestor foi descontinuado. A conversão mantém o mesmo
            # id da conta e, portanto, preserva associações de ambientes,
            # permissões de pastas, subpastas, dashboards e favoritos.
            cur.execute("UPDATE usuarios SET papel = 'viewer' WHERE papel = 'gestor'")
            # A recuperação de senha passou a ser exclusivamente por e-mail.
            # Em instalações antigas, removemos também os hashes das respostas
            # de segurança: eles não são mais utilizados nem devem permanecer
            # armazenados no banco.
            for coluna in ("resposta_hash", "pergunta"):
                cur.execute("""
                    SELECT COUNT(*) AS qtd FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE TABLE_SCHEMA = %s AND TABLE_NAME = 'usuarios'
                      AND COLUMN_NAME = %s
                """, (DB_NAME, coluna))
                if cur.fetchone()["qtd"]:
                    cur.execute(f"ALTER TABLE usuarios DROP COLUMN {coluna}")
            # Fotos de perfil ficam em uma tabela própria. Assim, salvar ou
            # administrar usuários não regrava imagens, e excluir uma conta
            # limpa a foto automaticamente pela chave estrangeira.
            cur.execute("""
                CREATE TABLE IF NOT EXISTS usuario_fotos (
                    usuario_id VARCHAR(32) PRIMARY KEY,
                    dados MEDIUMBLOB NOT NULL,
                    mime VARCHAR(50) NOT NULL,
                    nome VARCHAR(255) NULL,
                    atualizada_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
                        ON UPDATE CURRENT_TIMESTAMP,
                    CONSTRAINT fk_usuario_fotos_usuario
                        FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
            # Separada das regravacoes de usuarios: somente o Master altera guias.
            cur.execute("""
                CREATE TABLE IF NOT EXISTS usuario_guias (
                    usuario_id VARCHAR(32) PRIMARY KEY,
                    guias_json TEXT NOT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
            cur.execute("""
                CREATE TABLE IF NOT EXISTS portal_master_controle (
                    id TINYINT PRIMARY KEY,
                    usuario_id VARCHAR(32) NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
            cur.execute("INSERT IGNORE INTO portal_master_controle (id) VALUES (1)")
            cur.execute("""
                CREATE TABLE IF NOT EXISTS usuario_pastas (
                    usuario_id VARCHAR(32) NOT NULL,
                    pasta_id VARCHAR(32) NOT NULL,
                    PRIMARY KEY (usuario_id, pasta_id),
                    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
                    FOREIGN KEY (pasta_id) REFERENCES pastas(id) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
            cur.execute("""
                CREATE TABLE IF NOT EXISTS usuario_subpastas (
                    usuario_id VARCHAR(32) NOT NULL,
                    subpasta_id VARCHAR(32) NOT NULL,
                    PRIMARY KEY (usuario_id, subpasta_id),
                    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
                    FOREIGN KEY (subpasta_id) REFERENCES subpastas(id) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
            cur.execute("""
                CREATE TABLE IF NOT EXISTS usuario_dashboards (
                    usuario_id VARCHAR(32) NOT NULL,
                    dashboard_id VARCHAR(32) NOT NULL,
                    PRIMARY KEY (usuario_id, dashboard_id),
                    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
                    FOREIGN KEY (dashboard_id) REFERENCES dashboards(id) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
            cur.execute("""
                CREATE TABLE IF NOT EXISTS favoritos (
                    usuario_id VARCHAR(32) NOT NULL,
                    dashboard_id VARCHAR(32) NOT NULL,
                    PRIMARY KEY (usuario_id, dashboard_id),
                    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
                    FOREIGN KEY (dashboard_id) REFERENCES dashboards(id) ON DELETE CASCADE
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
            cur.execute("""
                CREATE TABLE IF NOT EXISTS aviso_fixado (
                    id TINYINT PRIMARY KEY DEFAULT 1,
                    texto TEXT NOT NULL,
                    atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
            cur.execute("""
                CREATE TABLE IF NOT EXISTS avisos_publicacoes (
                    id VARCHAR(32) PRIMARY KEY,
                    assunto VARCHAR(120) NOT NULL DEFAULT 'Sem assunto',
                    texto TEXT NOT NULL,
                    publicado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    expira_em DATETIME NULL,
                    publicado_por VARCHAR(32) NULL,
                    publicado_por_nome VARCHAR(255) NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
            cur.execute("""
                SELECT COUNT(*) AS qtd FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_SCHEMA = %s AND TABLE_NAME = 'avisos_publicacoes'
                  AND COLUMN_NAME = 'assunto'
            """, (DB_NAME,))
            if not cur.fetchone()["qtd"]:
                cur.execute("ALTER TABLE avisos_publicacoes ADD COLUMN assunto VARCHAR(120) NOT NULL DEFAULT 'Sem assunto'")
            cur.execute("""SELECT COUNT(*) AS qtd FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_SCHEMA = %s AND TABLE_NAME = 'avisos_publicacoes' AND COLUMN_NAME = 'expira_em'""",
                        (DB_NAME,))
            if not cur.fetchone()["qtd"]:
                cur.execute("ALTER TABLE avisos_publicacoes ADD COLUMN expira_em DATETIME NULL")
            cur.execute("""UPDATE avisos_publicacoes
                           SET expira_em = DATE_ADD(publicado_em, INTERVAL 24 HOUR)
                           WHERE expira_em IS NULL""")
            for coluna, definicao in (
                ("inicio_em", "DATETIME NULL"),
                ("publicado_por", "VARCHAR(32) NULL"),
                ("publicado_por_nome", "VARCHAR(255) NULL"),
            ):
                cur.execute("""
                    SELECT COUNT(*) AS qtd FROM INFORMATION_SCHEMA.COLUMNS
                    WHERE TABLE_SCHEMA = %s AND TABLE_NAME = 'avisos_publicacoes'
                      AND COLUMN_NAME = %s
                """, (DB_NAME, coluna))
                if not cur.fetchone()["qtd"]:
                    cur.execute(f"ALTER TABLE avisos_publicacoes ADD COLUMN {coluna} {definicao}")
            cur.execute("""
                CREATE TABLE IF NOT EXISTS avisos_estado (
                    id TINYINT PRIMARY KEY,
                    aviso_id VARCHAR(32) NULL,
                    migrado TINYINT NOT NULL DEFAULT 0
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
            # Sem FK para usuarios: save_users recria esses registros.
            # Os destinatarios e seus comprovantes permanecem como historico.
            cur.execute("""
                CREATE TABLE IF NOT EXISTS avisos_destinatarios (
                    aviso_id VARCHAR(32) NOT NULL,
                    usuario_id VARCHAR(32) NOT NULL,
                    nome VARCHAR(255) NOT NULL,
                    usuario VARCHAR(100) NOT NULL,
                    papel VARCHAR(20) NOT NULL,
                    visualizado_em DATETIME NULL,
                    aceito_em DATETIME NULL,
                    recusado_em DATETIME NULL,
                    PRIMARY KEY (aviso_id, usuario_id),
                    FOREIGN KEY (aviso_id) REFERENCES avisos_publicacoes(id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
            cur.execute("""
                SELECT COUNT(*) AS qtd FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_SCHEMA = %s AND TABLE_NAME = 'avisos_destinatarios'
                  AND COLUMN_NAME = 'recusado_em'
            """, (DB_NAME,))
            if not cur.fetchone()["qtd"]:
                cur.execute("ALTER TABLE avisos_destinatarios ADD COLUMN recusado_em DATETIME NULL")
            cur.execute("""
                CREATE TABLE IF NOT EXISTS avisos_eventos (
                    aviso_id VARCHAR(32) NOT NULL,
                    usuario_id VARCHAR(32) NOT NULL,
                    evento_id VARCHAR(40) NOT NULL,
                    nome VARCHAR(255) NOT NULL,
                    usuario VARCHAR(100) NOT NULL,
                    papel VARCHAR(20) NOT NULL,
                    visualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    aceito_em DATETIME NULL,
                    recusado_em DATETIME NULL,
                    PRIMARY KEY (aviso_id, usuario_id, evento_id),
                    FOREIGN KEY (aviso_id) REFERENCES avisos_publicacoes(id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
            cur.execute("""
                SELECT COUNT(*) AS qtd FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_SCHEMA = %s AND TABLE_NAME = 'avisos_estado'
                  AND COLUMN_NAME = 'eventos_migrados'
            """, (DB_NAME,))
            if not cur.fetchone()["qtd"]:
                cur.execute("ALTER TABLE avisos_estado ADD COLUMN eventos_migrados TINYINT NOT NULL DEFAULT 0")
            cur.execute("INSERT IGNORE INTO avisos_estado (id) VALUES (1)")
            cur.execute("SELECT migrado FROM avisos_estado WHERE id = 1 FOR UPDATE")
            if not cur.fetchone()["migrado"]:
                cur.execute("SELECT texto, atualizado_em FROM aviso_fixado WHERE id = 1")
                antigo = cur.fetchone()
                aviso_id = None
                if antigo:
                    aviso_id = uuid.uuid4().hex
                    cur.execute("INSERT INTO avisos_publicacoes (id, texto, publicado_em) VALUES (%s, %s, %s)",
                                (aviso_id, antigo["texto"], antigo["atualizado_em"]))
                    _incluir_destinatarios_aviso(cur, aviso_id)
                cur.execute("UPDATE avisos_estado SET aviso_id = %s, migrado = 1 WHERE id = 1", (aviso_id,))
            cur.execute("SELECT eventos_migrados FROM avisos_estado WHERE id = 1 FOR UPDATE")
            if not cur.fetchone()["eventos_migrados"]:
                # Preserva os fatos que a versao anterior armazenava, sem criar
                # eventos para destinatarios que nunca abriram o modal.
                cur.execute("""
                    INSERT IGNORE INTO avisos_eventos
                        (aviso_id, usuario_id, evento_id, nome, usuario, papel, visualizado_em, aceito_em)
                    SELECT aviso_id, usuario_id, 'anterior-aceite', nome, usuario, papel,
                           COALESCE(visualizado_em, aceito_em), aceito_em
                    FROM avisos_destinatarios WHERE aceito_em IS NOT NULL
                """)
                cur.execute("""
                    INSERT IGNORE INTO avisos_eventos
                        (aviso_id, usuario_id, evento_id, nome, usuario, papel, visualizado_em, recusado_em)
                    SELECT aviso_id, usuario_id, 'anterior-recusa', nome, usuario, papel,
                           COALESCE(visualizado_em, recusado_em), recusado_em
                    FROM avisos_destinatarios WHERE recusado_em IS NOT NULL
                """)
                cur.execute("""
                    INSERT IGNORE INTO avisos_eventos
                        (aviso_id, usuario_id, evento_id, nome, usuario, papel, visualizado_em)
                    SELECT aviso_id, usuario_id, 'anterior-visualizacao', nome, usuario, papel, visualizado_em
                    FROM avisos_destinatarios
                    WHERE visualizado_em IS NOT NULL AND aceito_em IS NULL AND recusado_em IS NULL
                """)
                cur.execute("UPDATE avisos_estado SET eventos_migrados = 1 WHERE id = 1")
            cur.execute("""
                CREATE TABLE IF NOT EXISTS usuario_eventos (
                    id VARCHAR(32) PRIMARY KEY,
                    data_hora VARCHAR(19) NOT NULL,
                    ator_id VARCHAR(32),
                    ator_nome VARCHAR(255),
                    tipo VARCHAR(40) NOT NULL,
                    usuario_id VARCHAR(32),
                    usuario_nome VARCHAR(255),
                    detalhe VARCHAR(500),
                    INDEX idx_usuario_eventos_data (data_hora),
                    INDEX idx_usuario_eventos_usuario (usuario_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
            cur.execute("""
                CREATE TABLE IF NOT EXISTS acessos (
                    id VARCHAR(32) PRIMARY KEY,
                    data_hora VARCHAR(19) NOT NULL,
                    usuario_id VARCHAR(32),
                    usuario_nome VARCHAR(255),
                    usuario_login VARCHAR(100),
                    usuario_papel VARCHAR(20),
                    dashboard_id VARCHAR(32),
                    dashboard_nome VARCHAR(255),
                    pasta_nome VARCHAR(255),
                    status VARCHAR(20),
                    ip VARCHAR(64),
                    INDEX idx_data_hora (data_hora)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)

        from ambientes import preparar_ambientes
        preparar_ambientes(conn)

        # Índices orientados às consultas de volume. Eles são aplicados uma
        # única vez, de forma idempotente, e já deixam o banco preparado para
        # a próxima etapa: paginação do histórico diretamente no MySQL.
        with conn.cursor() as cur:
            _garantir_indice(cur, "pastas", "idx_pastas_ambiente_nome", "ambiente_id, nome(128)")
            _garantir_indice(cur, "acessos", "idx_acessos_ambiente_data", "ambiente_id, data_hora")
            _garantir_indice(cur, "acessos", "idx_acessos_dashboard_data", "dashboard_id, data_hora")
            _garantir_indice(cur, "acessos", "idx_acessos_usuario_data", "usuario_id, data_hora")
            _garantir_indice(cur, "usuario_eventos", "idx_eventos_ambiente_data", "ambiente_id, data_hora")


# ===========================================================================
# Pastas + Dashboards
# ===========================================================================
def _cache_get(chave):
    """Le um valor do cache da requisicao atual (via flask.g), se houver
    uma requisicao em andamento. Fora de um contexto Flask (ex.: script
    de migracao) simplesmente nao usa cache."""
    if has_app_context() and hasattr(g, chave):
        return getattr(g, chave)
    return None


def _cache_set(chave, valor):
    if has_app_context():
        setattr(g, chave, valor)


def _cache_clear(chave):
    if has_app_context() and hasattr(g, chave):
        delattr(g, chave)


class ConflitoGravacao(RuntimeError):
    """O formulário foi baseado em dados que outro acesso já alterou."""


class _DadosSnapshot(dict):
    pass


class _UsuariosSnapshot(list):
    pass


def _assinatura(valor):
    return hashlib.sha256(json.dumps(valor, sort_keys=True, default=str, ensure_ascii=False).encode()).hexdigest()


def _validar_snapshot(valor, atual, chave_cache):
    origem = valor if hasattr(valor, "_assinatura_original") else _cache_get(chave_cache)
    esperado = getattr(origem, "_assinatura_original", None)
    if esperado is None:
        if has_request_context():
            raise ConflitoGravacao("Conflito de gravação: recarregue a página antes de salvar.")
        return  # Compatibilidade com scripts locais de importação, fora de uma requisição.
    if (getattr(origem, "_ambiente_original", None) != contexto_ambiente() and chave_cache == "_dados_cache") or esperado != _assinatura(atual):
        raise ConflitoGravacao("Conflito de gravação: os dados foram alterados em outro acesso. Recarregue a página e tente novamente.")


def _ids_ambientes_ordenados(ambiente_ids):
    """Normaliza o escopo de ambiente usado nas consultas da árvore."""
    if ambiente_ids is None:
        return ()
    if isinstance(ambiente_ids, str):
        ambiente_ids = (ambiente_ids,)
    return tuple(sorted({str(valor).strip() for valor in ambiente_ids if valor and str(valor).strip()}))


def _filtro_ambientes_sql(alias, ambiente_ids, incluir_legado=False):
    """Monta um filtro parametrizado e, se solicitado, inclui linhas legadas."""
    placeholders = ", ".join(["%s"] * len(ambiente_ids))
    filtro = f"{alias}.ambiente_id IN ({placeholders})"
    if incluir_legado and INICIAL in ambiente_ids:
        filtro = (
            f"({filtro} OR ({alias}.id IS NOT NULL AND "
            f"({alias}.ambiente_id IS NULL OR {alias}.ambiente_id = '')))"
        )
    return filtro, list(ambiente_ids)


def _ler_dados(cur, ambiente_ids=None):
    """Carrega a estrutura e filtra no MySQL quando há escopo de ambiente.

    Sem parâmetro, mantém o comportamento das telas administrativas: o Master
    vê todos os ambientes ou somente o ambiente escolhido na sessão. Com uma
    lista explícita, a árvore multiambiente do Admin/Visualizador lê apenas os
    ambientes atribuídos a essa pessoa.
    """
    escopo_explicito = ambiente_ids is not None
    if ambiente_ids is None:
        contexto = contexto_ambiente()
        escopo = (contexto,) if contexto else None
    else:
        escopo = _ids_ambientes_ordenados(ambiente_ids)

    if escopo == ():
        return {"pastas": [], "subpastas": [], "dashboards": []}

    sql_pastas = "SELECT p.id, p.nome, p.criado_em, p.ambiente_id FROM pastas p"
    params_pastas = ()
    if escopo:
        filtro, params_pastas = _filtro_ambientes_sql(
            "p", escopo, incluir_legado=escopo_explicito
        )
        sql_pastas += " WHERE " + filtro
    cur.execute(sql_pastas + " ORDER BY p.criado_em, p.id", tuple(params_pastas))
    pastas = list(cur.fetchall())

    sql_subpastas = (
        "SELECT sp.id, sp.nome, sp.pasta_id, sp.parent_subpasta_id, sp.criado_em "
        "FROM subpastas sp"
    )
    params_subpastas = ()
    if escopo:
        filtro, params_subpastas = _filtro_ambientes_sql(
            "p", escopo, incluir_legado=escopo_explicito
        )
        sql_subpastas += " JOIN pastas p ON p.id = sp.pasta_id WHERE " + filtro
    cur.execute(sql_subpastas + " ORDER BY sp.criado_em, sp.id", tuple(params_subpastas))
    subpastas = list(cur.fetchall())

    sql_dashboards = (
        "SELECT d.id, d.nome, d.descricao, d.embed_url, d.pasta_id, d.subpasta_id, "
        "d.ativo, d.permitir_favoritar, d.ordem_exibicao, d.cadastrado_por, d.criado_em, "
        "COALESCE(p.ambiente_id, %s) AS ambiente_id "
        "FROM dashboards d LEFT JOIN pastas p ON p.id = d.pasta_id"
    )
    params_dashboards = [INICIAL]
    if escopo:
        filtro, params = _filtro_ambientes_sql(
            "p", escopo, incluir_legado=escopo_explicito
        )
        if INICIAL in escopo:
            filtro = f"({filtro} OR d.pasta_id IS NULL)"
        condicoes = [filtro]
        params_dashboards.extend(params)
        if escopo_explicito:
            filtro_subpasta, params_subpasta = _filtro_ambientes_sql(
                "ps", escopo, incluir_legado=True
            )
            condicoes.append(
                "(d.subpasta_id IS NULL OR EXISTS ("
                "SELECT 1 FROM subpastas sp "
                "JOIN pastas ps ON ps.id = sp.pasta_id "
                "WHERE sp.id = d.subpasta_id AND " + filtro_subpasta + "))"
            )
            params_dashboards.extend(params_subpasta)
        sql_dashboards += " WHERE " + " AND ".join(condicoes)
    cur.execute(
        sql_dashboards + " ORDER BY d.ordem_exibicao, d.criado_em, d.id",
        tuple(params_dashboards),
    )
    dashboards = list(cur.fetchall())
    return {"pastas": pastas, "subpastas": subpastas, "dashboards": dashboards}


def load_data():
    """Snapshot consistente por requisição, com detecção de alterações concorrentes."""
    cache = _cache_get("_dados_cache")
    if cache is not None:
        return cache
    with conexao() as conn, conn.cursor() as cur:
        resultado = _DadosSnapshot(_ler_dados(cur))
    resultado._assinatura_original = _assinatura(resultado)
    resultado._ambiente_original = contexto_ambiente()
    _cache_set("_dados_cache", resultado)
    return resultado


def load_data_ambientes(ambiente_ids):
    """Carrega somente os ambientes autorizados, com cache por requisição."""
    ids = _ids_ambientes_ordenados(ambiente_ids)
    if not ids:
        return {"pastas": [], "subpastas": [], "dashboards": []}

    cache = _cache_get("_dados_ambientes_cache") or {}
    if ids in cache:
        return cache[ids]

    with conexao() as conn, conn.cursor() as cur:
        resultado = _DadosSnapshot(_ler_dados(cur, ambiente_ids=ids))
    cache[ids] = resultado
    _cache_set("_dados_ambientes_cache", cache)
    return resultado


def _delete_missing(cur, tabela, ids_presentes):
    """Remove somente registros que realmente sairam do modelo em memoria.

    A versao antiga de save_data apagava e recriava tudo, o que podia acionar
    FKs com ON DELETE CASCADE e remover favoritos/permissoes. A sincronizacao
    incremental preserva relacionamentos dos itens que continuam existindo.
    """
    condicoes, params = [], []
    if contexto_ambiente():
        if tabela == "pastas":
            condicoes.append("ambiente_id = %s")
        else:
            condicao = "pasta_id IN (SELECT id FROM pastas WHERE ambiente_id = %s)"
            if tabela == "dashboards" and contexto_ambiente() == INICIAL:
                condicao = "(" + condicao + " OR pasta_id IS NULL)"
            condicoes.append(condicao)
        params.append(contexto_ambiente())
    if ids_presentes:
        condicoes.append("id NOT IN (" + ",".join(["%s"] * len(ids_presentes)) + ")")
        params.extend(ids_presentes)
    cur.execute(f"DELETE FROM {tabela}" + (" WHERE " + " AND ".join(condicoes) if condicoes else ""), tuple(params))


def _validar_estrutura_ambiente(cur, data):
    """Impede IDs e vínculos entre ambientes, inclusive em gravações diretas."""
    ambiente = contexto_ambiente()
    cur.execute("SELECT id, ambiente_id FROM pastas FOR UPDATE")
    existentes = {p["id"]: p["ambiente_id"] for p in cur.fetchall()}
    pastas = {p["id"]: p.get("ambiente_id") or ambiente or INICIAL for p in data.get("pastas", [])}
    cur.execute("SELECT id FROM ambientes")
    ambientes_validos = {a["id"] for a in cur.fetchall()}
    for pid, aid in pastas.items():
        if aid not in ambientes_validos or (ambiente and aid != ambiente):
            raise PermissionError("Pasta fora do ambiente atual.")
        if pid in existentes and existentes[pid] != aid:
            raise PermissionError("Uma pasta não pode ser movida entre ambientes.")
    subs = {sp["id"]: sp for sp in data.get("subpastas", [])}
    for sp in subs.values():
        pai = subs.get(sp.get("parent_subpasta_id"))
        if sp["pasta_id"] not in pastas or (sp.get("parent_subpasta_id") and
                (not pai or pai["pasta_id"] != sp["pasta_id"])):
            raise PermissionError("Subpasta fora da estrutura do ambiente.")
    for d in data.get("dashboards", []):
        sub = subs.get(d.get("subpasta_id"))
        if d.get("pasta_id") not in pastas and d.get("pasta_id"):
            raise PermissionError("Dashboard fora do ambiente atual.")
        if d.get("subpasta_id") and (not sub or sub["pasta_id"] != d.get("pasta_id")):
            raise PermissionError("Localização de dashboard inválida.")
        if not d.get("pasta_id") and ambiente and ambiente != INICIAL:
            raise PermissionError("Selecione uma pasta para o dashboard.")
    # Um ID já existente em outro ambiente nunca pode ser sobrescrito pelo upsert.
    if ambiente:
        for tabela in ("subpastas", "dashboards"):
            cur.execute(f"SELECT id, pasta_id FROM {tabela}")
            for linha in cur.fetchall():
                if any(x["id"] == linha["id"] for x in data.get(tabela, [])) and \
                        existentes.get(linha["pasta_id"], INICIAL) != ambiente:
                    raise PermissionError("Registro pertence a outro ambiente.")
    return existentes


def _ordenar_subpastas(subpastas):
    por_id = {sp["id"]: sp for sp in subpastas}
    ordem, finalizados, visitando = [], set(), set()
    def visitar(sp):
        sid = sp["id"]
        if sid in finalizados:
            return
        if sid in visitando:
            raise ValueError("A estrutura de subpastas contém um ciclo.")
        visitando.add(sid)
        pai = sp.get("parent_subpasta_id")
        if pai:
            if pai not in por_id:
                raise ValueError("A pasta superior não existe na estrutura enviada.")
            visitar(por_id[pai])
        visitando.remove(sid)
        finalizados.add(sid)
        ordem.append(sp)
    for sp in subpastas:
        visitar(sp)
    return ordem


def _ambiente_do_dashboard(cur, dashboard_id):
    if contexto_ambiente():
        return contexto_ambiente()
    cur.execute("""SELECT p.ambiente_id FROM dashboards d JOIN pastas p ON p.id = d.pasta_id
        WHERE d.id = %s""", (dashboard_id,))
    linha = cur.fetchone()
    return linha["ambiente_id"] if linha else INICIAL


def save_data(data):
    """Sincroniza pastas, subpastas e dashboards sem recriar itens existentes."""
    pastas = data.get("pastas", [])
    subpastas = data.get("subpastas", [])
    dashboards = data.get("dashboards", [])

    with conexao() as conn:
        with conn.cursor() as cur:
            # Mesmo bloqueio usado pelo cadastro/edição de contas; evita gravar
            # uma fotografia antiga por cima de uma criação ou mudança recente.
            cur.execute("SELECT usuario_id FROM portal_master_controle WHERE id = 1 FOR UPDATE")
            _validar_snapshot(data, _ler_dados(cur), "_dados_cache")
            pastas_anteriores = _validar_estrutura_ambiente(cur, data)
            # Pais primeiro, para todas as FKs estarem validas nos upserts.
            for p in pastas:
                if p.get("criado_em"):
                    cur.execute("""
                        INSERT INTO pastas (id, nome, criado_em, ambiente_id)
                        VALUES (%s, %s, %s, %s)
                        ON DUPLICATE KEY UPDATE nome = VALUES(nome)
                    """, (p["id"], p["nome"], p["criado_em"], p.get("ambiente_id") or contexto_ambiente() or INICIAL))
                else:
                    cur.execute("""
                        INSERT INTO pastas (id, nome, ambiente_id)
                        VALUES (%s, %s, %s)
                        ON DUPLICATE KEY UPDATE nome = VALUES(nome)
                    """, (p["id"], p["nome"], p.get("ambiente_id") or contexto_ambiente() or INICIAL))

                ator = getattr(g, "_portal_current_user", None) if has_app_context() else None
                if p["id"] not in pastas_anteriores and contexto_ambiente() and ator and ator.get("papel") == "admin":
                    cur.execute("INSERT IGNORE INTO usuario_pastas (usuario_id, pasta_id) VALUES (%s, %s)", (ator["id"], p["id"]))
            _cache_clear("_usuarios_cache")

            # Todo pai precede seus filhos, inclusive Tema → Subnível.
            subpastas_ordenadas = _ordenar_subpastas(subpastas)
            for sp in subpastas_ordenadas:
                parent_id = sp.get("parent_subpasta_id") or None
                if sp.get("criado_em"):
                    cur.execute("""
                        INSERT INTO subpastas (id, nome, pasta_id, parent_subpasta_id, criado_em)
                        VALUES (%s, %s, %s, %s, %s)
                        ON DUPLICATE KEY UPDATE
                            nome = VALUES(nome),
                            pasta_id = VALUES(pasta_id),
                            parent_subpasta_id = VALUES(parent_subpasta_id)
                    """, (sp["id"], sp["nome"], sp["pasta_id"], parent_id, sp["criado_em"]))
                else:
                    cur.execute("""
                        INSERT INTO subpastas (id, nome, pasta_id, parent_subpasta_id)
                        VALUES (%s, %s, %s, %s)
                        ON DUPLICATE KEY UPDATE
                            nome = VALUES(nome),
                            pasta_id = VALUES(pasta_id),
                            parent_subpasta_id = VALUES(parent_subpasta_id)
                    """, (sp["id"], sp["nome"], sp["pasta_id"], parent_id))

            for d in dashboards:
                valores = (
                    d["id"], d["nome"], d.get("descricao", ""), d["embed_url"],
                    d.get("pasta_id"), d.get("subpasta_id") or None,
                    1 if d.get("ativo", True) else 0,
                    1 if d.get("permitir_favoritar", True) else 0,
                    int(d.get("ordem_exibicao", 0) or 0),
                    d.get("cadastrado_por") or None,
                )
                if d.get("criado_em"):
                    cur.execute("""
                        INSERT INTO dashboards
                            (id, nome, descricao, embed_url, pasta_id, subpasta_id,
                             ativo, permitir_favoritar, ordem_exibicao, cadastrado_por, criado_em)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                        ON DUPLICATE KEY UPDATE
                            nome = VALUES(nome),
                            descricao = VALUES(descricao),
                            embed_url = VALUES(embed_url),
                            pasta_id = VALUES(pasta_id),
                            subpasta_id = VALUES(subpasta_id),
                            ativo = VALUES(ativo),
                            permitir_favoritar = VALUES(permitir_favoritar),
                            ordem_exibicao = VALUES(ordem_exibicao),
                            cadastrado_por = VALUES(cadastrado_por)
                    """, valores + (d["criado_em"],))
                else:
                    cur.execute("""
                        INSERT INTO dashboards
                            (id, nome, descricao, embed_url, pasta_id, subpasta_id,
                             ativo, permitir_favoritar, ordem_exibicao, cadastrado_por)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                        ON DUPLICATE KEY UPDATE
                            nome = VALUES(nome),
                            descricao = VALUES(descricao),
                            embed_url = VALUES(embed_url),
                            pasta_id = VALUES(pasta_id),
                            subpasta_id = VALUES(subpasta_id),
                            ativo = VALUES(ativo),
                            permitir_favoritar = VALUES(permitir_favoritar),
                            ordem_exibicao = VALUES(ordem_exibicao),
                            cadastrado_por = VALUES(cadastrado_por)
                    """, valores)

            # Filhos primeiro na exclusao. Itens mantidos nao sao apagados,
            # preservando favoritos e permissoes existentes.
            _delete_missing(cur, "dashboards", [d["id"] for d in dashboards])
            _delete_missing(cur, "subpastas", [sp["id"] for sp in subpastas])
            _delete_missing(cur, "pastas", [p["id"] for p in pastas])

    _cache_clear("_dados_cache")


def inserir_pasta(nome, ambiente_id, usuario_id=None, papel=None,
                  idempotency_id=None, retornar_status=False):
    """Cria uma pasta de forma atômica, sem sincronizar a árvore inteira.

    A criação é uma operação independente: evita que um snapshot antigo da
    tela de Cadastro de Dashboard bloqueie uma nova pasta do Master. O
    identificador opcional torna seguro reenviar a mesma solicitação após uma
    falha de rede; a linha de ambiente serializa criações da mesma árvore.
    """
    nome = (nome or "").strip()
    ambiente_id = (ambiente_id or "").strip()
    if not nome:
        raise ValueError("Informe o nome da pasta.")
    if len(nome) > 255:
        raise ValueError("O nome da pasta deve ter no máximo 255 caracteres.")
    if not ambiente_id:
        raise ValueError("Informe o ambiente da pasta.")
    pasta_id = (idempotency_id or uuid.uuid4().hex).strip().lower()
    if len(pasta_id) != 32 or any(c not in "0123456789abcdef" for c in pasta_id):
        raise ValueError("A solicitação de criação da pasta expirou. Atualize a página e tente novamente.")
    ja_existia = False
    with conexao() as conn, conn.cursor() as cur:
        cur.execute("SELECT id FROM ambientes WHERE id = %s FOR UPDATE", (ambiente_id,))
        if not cur.fetchone():
            raise ValueError("Ambiente não encontrado.")

        cur.execute(
            "SELECT id, nome, ambiente_id FROM pastas WHERE id = %s FOR UPDATE",
            (pasta_id,),
        )
        existente = cur.fetchone()
        if existente:
            mesmo_pedido = (
                existente.get("ambiente_id") == ambiente_id
                and (existente.get("nome") or "").strip().casefold() == nome.casefold()
            )
            if not mesmo_pedido:
                raise ConflitoGravacao(
                    "Esta solicitação já foi usada para outra pasta. Atualize a página antes de tentar novamente."
                )
            ja_existia = True
        else:
            cur.execute(
                "SELECT id, nome FROM pastas WHERE ambiente_id = %s FOR UPDATE",
                (ambiente_id,),
            )
            duplicada = next(
                (p for p in cur.fetchall()
                 if (p.get("nome") or "").strip().casefold() == nome.casefold()),
                None,
            )
            if duplicada:
                raise ConflitoGravacao("Já existe uma pasta com esse nome neste ambiente.")
            cur.execute(
                "INSERT INTO pastas (id, nome, ambiente_id) VALUES (%s, %s, %s)",
                (pasta_id, nome, ambiente_id),
            )
        # Administradores que criam uma pasta dentro do próprio ambiente
        # continuam recebendo a permissão de Cliente usada pelo fluxo antigo.
        if usuario_id and papel == "admin":
            cur.execute(
                "INSERT IGNORE INTO usuario_pastas (usuario_id, pasta_id) VALUES (%s, %s)",
                (usuario_id, pasta_id),
            )
    _cache_clear("_dados_cache")
    return (pasta_id, ja_existia) if retornar_status else pasta_id


def inserir_subpasta(nome, pasta_id, parent_subpasta_id=None):
    """Cria uma subpasta sem regravar dashboards ou outras estruturas."""
    nome = (nome or "").strip()
    pasta_id = (pasta_id or "").strip()
    parent_subpasta_id = (parent_subpasta_id or "").strip() or None
    if not nome:
        raise ValueError("Informe o nome da subpasta.")
    if not pasta_id:
        raise ValueError("Pasta não informada.")
    subpasta_id = uuid.uuid4().hex
    with conexao() as conn, conn.cursor() as cur:
        cur.execute("SELECT id FROM pastas WHERE id = %s FOR UPDATE", (pasta_id,))
        if not cur.fetchone():
            raise ValueError("Pasta não encontrada.")
        if parent_subpasta_id:
            cur.execute(
                "SELECT id, pasta_id FROM subpastas WHERE id = %s FOR UPDATE",
                (parent_subpasta_id,),
            )
            parent = cur.fetchone()
            if not parent or parent["pasta_id"] != pasta_id:
                raise ValueError("A pasta superior não pertence à pasta escolhida.")
        cur.execute(
            "INSERT INTO subpastas (id, nome, pasta_id, parent_subpasta_id) VALUES (%s, %s, %s, %s)",
            (subpasta_id, nome[:255], pasta_id, parent_subpasta_id),
        )
    _cache_clear("_dados_cache")
    return subpasta_id


def salvar_dashboard_pontual(dashboard, criar=False):
    """Cria ou atualiza um dashboard sem sincronizar a árvore inteira.

    Criações usam o ID enviado no formulário como chave de idempotência. Se o
    navegador repetir exatamente a mesma operação após perder a resposta, o
    registro existente é confirmado sem criar um segundo dashboard.
    """
    campos = (
        "id", "nome", "descricao", "embed_url", "pasta_id", "subpasta_id",
        "ativo", "permitir_favoritar", "ordem_exibicao", "cadastrado_por",
    )
    valores = [dashboard.get(campo) for campo in campos]
    valores[5] = valores[5] or None
    valores[6] = int(bool(valores[6]))
    valores[7] = int(bool(valores[7]))
    valores[8] = int(valores[8] or 0)
    ja_existia = False
    with conexao() as conn, conn.cursor() as cur:
        cur.execute(
            "SELECT id, ambiente_id FROM pastas WHERE id = %s FOR UPDATE",
            (dashboard.get("pasta_id"),),
        )
        pasta = cur.fetchone()
        if not pasta:
            raise ValueError("Pasta não encontrada.")
        ambiente_esperado = dashboard.get("ambiente_id")
        if ambiente_esperado and pasta.get("ambiente_id") != ambiente_esperado:
            raise PermissionError("A pasta não pertence ao ambiente selecionado.")
        subpasta_id = valores[5]
        if subpasta_id:
            cur.execute(
                "SELECT id, pasta_id FROM subpastas WHERE id = %s FOR UPDATE",
                (subpasta_id,),
            )
            subpasta = cur.fetchone()
            if not subpasta or subpasta.get("pasta_id") != dashboard.get("pasta_id"):
                raise ValueError("A subpasta escolhida não pertence à pasta selecionada.")
        if criar:
            cur.execute(
                """SELECT id, nome, descricao, embed_url, pasta_id, subpasta_id,
                          ativo, permitir_favoritar, ordem_exibicao, cadastrado_por
                   FROM dashboards WHERE id = %s FOR UPDATE""",
                (dashboard.get("id"),),
            )
            existente = cur.fetchone()
            if existente:
                atuais = [existente.get(campo) for campo in campos]
                esperados = list(valores)
                atuais[2] = atuais[2] or ""
                esperados[2] = esperados[2] or ""
                atuais[5] = atuais[5] or None
                esperados[5] = esperados[5] or None
                for indice in (6, 7, 8):
                    atuais[indice] = int(atuais[indice] or 0)
                    esperados[indice] = int(esperados[indice] or 0)
                if atuais != esperados:
                    raise ConflitoGravacao(
                        "Este cadastro já foi enviado com outros dados. Atualize a página e confira a árvore antes de reenviar."
                    )
                ja_existia = True
            else:
                cur.execute(
                    """INSERT INTO dashboards
                        (id, nome, descricao, embed_url, pasta_id, subpasta_id, ativo,
                         permitir_favoritar, ordem_exibicao, cadastrado_por)
                       VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)""",
                    tuple(valores),
                )
        else:
            cur.execute("SELECT id FROM dashboards WHERE id = %s FOR UPDATE", (dashboard.get("id"),))
            if not cur.fetchone():
                raise ValueError("Dashboard não encontrado.")
            cur.execute(
                """UPDATE dashboards SET nome = %s, descricao = %s, embed_url = %s,
                       pasta_id = %s, subpasta_id = %s, ativo = %s,
                       permitir_favoritar = %s, ordem_exibicao = %s,
                       cadastrado_por = %s WHERE id = %s""",
                tuple(valores[1:]) + (valores[0],),
            )
    _cache_clear("_dados_cache")
    return not ja_existia if criar else None


def mover_dashboard_pontual(dashboard_id, pasta_id, subpasta_id=None):
    """Altera apenas a localização de um dashboard existente."""
    with conexao() as conn, conn.cursor() as cur:
        cur.execute("SELECT id FROM dashboards WHERE id = %s FOR UPDATE", (dashboard_id,))
        if not cur.fetchone():
            raise ValueError("Dashboard não encontrado.")
        cur.execute("SELECT id FROM pastas WHERE id = %s FOR UPDATE", (pasta_id,))
        if not cur.fetchone():
            raise ValueError("Pasta não encontrada.")
        if subpasta_id:
            cur.execute("SELECT pasta_id FROM subpastas WHERE id = %s FOR UPDATE", (subpasta_id,))
            subpasta = cur.fetchone()
            if not subpasta or subpasta["pasta_id"] != pasta_id:
                raise ValueError("Subpasta não pertence à pasta escolhida.")
        cur.execute("UPDATE dashboards SET pasta_id = %s, subpasta_id = %s WHERE id = %s",
                    (pasta_id, subpasta_id or None, dashboard_id))
    _cache_clear("_dados_cache")


def excluir_dashboard_pontual(dashboard_id):
    """Remove um dashboard; as permissões positivas seguem a FK em cascata."""
    with conexao() as conn, conn.cursor() as cur:
        cur.execute("DELETE FROM dashboards WHERE id = %s", (dashboard_id,))
        removido = cur.rowcount > 0
    _cache_clear("_dados_cache")
    return removido


def renomear_pasta_pontual(pasta_id, nome):
    with conexao() as conn, conn.cursor() as cur:
        cur.execute("UPDATE pastas SET nome = %s WHERE id = %s", ((nome or "").strip()[:255], pasta_id))
        if not cur.rowcount:
            raise ValueError("Pasta não encontrada.")
    _cache_clear("_dados_cache")


def renomear_subpasta_pontual(subpasta_id, nome):
    with conexao() as conn, conn.cursor() as cur:
        cur.execute("UPDATE subpastas SET nome = %s WHERE id = %s", ((nome or "").strip()[:255], subpasta_id))
        if not cur.rowcount:
            raise ValueError("Subpasta não encontrada.")
    _cache_clear("_dados_cache")


def mover_subpasta_pontual(subpasta_id, nome, parent_subpasta_id, pasta_id,
                            subpastas_da_arvore, dashboards_da_arvore):
    """Atualiza uma subárvore sem regravar itens de outros clientes."""
    subpastas_da_arvore = sorted({str(item) for item in subpastas_da_arvore if item})
    dashboards_da_arvore = sorted({str(item) for item in dashboards_da_arvore if item})
    if subpasta_id not in subpastas_da_arvore:
        raise ValueError("Estrutura de subpastas inválida.")
    with conexao() as conn, conn.cursor() as cur:
        cur.execute("SELECT id FROM subpastas WHERE id = %s FOR UPDATE", (subpasta_id,))
        if not cur.fetchone():
            raise ValueError("Subpasta não encontrada.")
        cur.execute("SELECT id FROM pastas WHERE id = %s FOR UPDATE", (pasta_id,))
        if not cur.fetchone():
            raise ValueError("Pasta de destino não encontrada.")
        if parent_subpasta_id:
            cur.execute("SELECT id, pasta_id FROM subpastas WHERE id = %s FOR UPDATE", (parent_subpasta_id,))
            pai = cur.fetchone()
            if not pai or pai["pasta_id"] != pasta_id:
                raise ValueError("Nível superior inválido.")
        cur.execute("UPDATE subpastas SET nome = %s, parent_subpasta_id = %s WHERE id = %s",
                    ((nome or "").strip()[:255], parent_subpasta_id or None, subpasta_id))
        marcadores = ", ".join(["%s"] * len(subpastas_da_arvore))
        cur.execute(f"UPDATE subpastas SET pasta_id = %s WHERE id IN ({marcadores})",
                    (pasta_id, *subpastas_da_arvore))
        if dashboards_da_arvore:
            marcadores = ", ".join(["%s"] * len(dashboards_da_arvore))
            cur.execute(f"UPDATE dashboards SET pasta_id = %s WHERE id IN ({marcadores})",
                        (pasta_id, *dashboards_da_arvore))
    _cache_clear("_dados_cache")


def excluir_subpastas_pontual(subpasta_ids, parent_subpasta_id=None):
    """Remove uma subárvore e reposiciona seus dashboards no nível superior."""
    ids = sorted({str(item) for item in subpasta_ids if item})
    if not ids:
        return
    with conexao() as conn, conn.cursor() as cur:
        marcadores = ", ".join(["%s"] * len(ids))
        cur.execute(f"UPDATE dashboards SET subpasta_id = %s WHERE subpasta_id IN ({marcadores})",
                    (parent_subpasta_id or None, *ids))
        cur.execute(f"DELETE FROM subpastas WHERE id IN ({marcadores})", tuple(ids))
    _cache_clear("_dados_cache")


def excluir_pasta_pontual(pasta_id, subpasta_ids, dashboard_ids):
    """Remove uma pasta e seus descendentes, sem tocar em outras estruturas."""
    subpasta_ids = sorted({str(item) for item in subpasta_ids if item})
    dashboard_ids = sorted({str(item) for item in dashboard_ids if item})
    with conexao() as conn, conn.cursor() as cur:
        if dashboard_ids:
            marcadores = ", ".join(["%s"] * len(dashboard_ids))
            cur.execute(f"DELETE FROM dashboards WHERE id IN ({marcadores})", tuple(dashboard_ids))
        if subpasta_ids:
            marcadores = ", ".join(["%s"] * len(subpasta_ids))
            cur.execute(f"DELETE FROM subpastas WHERE id IN ({marcadores})", tuple(subpasta_ids))
        cur.execute("DELETE FROM pastas WHERE id = %s", (pasta_id,))
        if not cur.rowcount:
            raise ValueError("Pasta não encontrada.")
    _cache_clear("_dados_cache")


# ===========================================================================
# Usuarios
# ===========================================================================
def _ler_usuarios(cur):
    cur.execute("SELECT * FROM usuarios ORDER BY criado_em, id")
    usuarios = list(cur.fetchall())
    if not usuarios:
        # Instalações novas começam com criar_master.py. Somente esse
        # Master poderá cadastrar o primeiro Administrador pelo portal.
        return []

    cur.execute("SELECT usuario_id, pasta_id FROM usuario_pastas")
    pastas_por_usuario = {}
    for row in list(cur.fetchall()):
        pastas_por_usuario.setdefault(row["usuario_id"], []).append(row["pasta_id"])

    cur.execute("SELECT usuario_id, subpasta_id FROM usuario_subpastas")
    subpastas_por_usuario = {}
    for row in list(cur.fetchall()):
        subpastas_por_usuario.setdefault(row["usuario_id"], []).append(row["subpasta_id"])

    cur.execute("SELECT usuario_id, dashboard_id FROM usuario_dashboards")
    dashboards_por_usuario = {}
    for row in list(cur.fetchall()):
        dashboards_por_usuario.setdefault(row["usuario_id"], []).append(row["dashboard_id"])

    cur.execute("SELECT usuario_id, guias_json FROM usuario_guias")
    guias_por_usuario = {}
    for row in cur.fetchall():
        try:
            valor = json.loads(row["guias_json"])
            guias_por_usuario[row["usuario_id"]] = valor if isinstance(valor, list) and all(isinstance(x, str) for x in valor) else []
        except (ValueError, TypeError):
            guias_por_usuario[row["usuario_id"]] = []
    for u in usuarios:
        u["guias"] = guias_por_usuario.get(u["id"])
        u["pastas"] = pastas_por_usuario.get(u["id"], [])
        u["subpastas"] = subpastas_por_usuario.get(u["id"], [])
        u["dashboards"] = dashboards_por_usuario.get(u["id"], [])
    return usuarios


def load_users():
    """Lê contas e permissões no mesmo snapshot para detectar gravações obsoletas."""
    cache = _cache_get("_usuarios_cache")
    if cache is not None:
        return cache
    with conexao() as conn, conn.cursor() as cur:
        usuarios = _UsuariosSnapshot(_ler_usuarios(cur))
    usuarios._assinatura_original = _assinatura(usuarios)
    _cache_set("_usuarios_cache", usuarios)
    return usuarios


def info_foto_usuario(usuario_id):
    """Retorna somente os metadados necessários para desenhar o avatar.

    Não coloca o BLOB no cache de usuários nem no contexto dos templates,
    evitando que uma foto aumente as consultas usadas em toda a aplicação.
    """
    if not usuario_id:
        return None
    with conexao() as conn, conn.cursor() as cur:
        cur.execute(
            "SELECT UNIX_TIMESTAMP(atualizada_em) AS versao FROM usuario_fotos WHERE usuario_id = %s",
            (usuario_id,),
        )
        return cur.fetchone()


def carregar_foto_usuario(usuario_id):
    """Busca a imagem do avatar para entrega exclusiva ao dono da conta."""
    if not usuario_id:
        return None
    with conexao() as conn, conn.cursor() as cur:
        cur.execute(
            "SELECT dados, mime, nome, UNIX_TIMESTAMP(atualizada_em) AS versao "
            "FROM usuario_fotos WHERE usuario_id = %s",
            (usuario_id,),
        )
        return cur.fetchone()


def salvar_foto_usuario(usuario_id, dados, mime, nome=""):
    """Inclui ou substitui a foto de uma conta já existente."""
    if not usuario_id or not dados or not mime:
        raise ValueError("Dados da foto inválidos.")
    with conexao() as conn, conn.cursor() as cur:
        cur.execute("SELECT id FROM usuarios WHERE id = %s", (usuario_id,))
        if not cur.fetchone():
            raise ValueError("Usuário não encontrado.")
        cur.execute(
            """INSERT INTO usuario_fotos (usuario_id, dados, mime, nome)
               VALUES (%s, %s, %s, %s)
               ON DUPLICATE KEY UPDATE dados = VALUES(dados), mime = VALUES(mime),
                                       nome = VALUES(nome), atualizada_em = CURRENT_TIMESTAMP""",
            (usuario_id, dados, mime, (nome or "")[:255]),
        )


def remover_foto_usuario(usuario_id):
    """Remove a foto sem alterar a conta ou suas permissões."""
    if not usuario_id:
        return False
    with conexao() as conn, conn.cursor() as cur:
        cur.execute("DELETE FROM usuario_fotos WHERE usuario_id = %s", (usuario_id,))
        return cur.rowcount > 0


def concluir_primeiro_acesso(usuario_id, senha_hash_anterior, senha_hash_nova):
    """Atualiza somente a conta autenticada, sem regravar usuarios/permissoes.

    A condicao impede duas abas de concluir a troca com a mesma credencial.
    """
    with conexao() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT usuario_id FROM portal_master_controle WHERE id = 1 FOR UPDATE")
            cur.execute(
                "UPDATE usuarios SET senha_hash = %s, troca_senha_obrigatoria = 0 "
                "WHERE id = %s AND senha_hash = %s AND troca_senha_obrigatoria = 1",
                (senha_hash_nova, usuario_id, senha_hash_anterior),
            )
            atualizado = cur.rowcount == 1
    _cache_clear("_usuarios_cache")
    return atualizado


def redefinir_senha_por_email(usuario_id, senha_hash_anterior, email, senha_hash_nova):
    """Conclui uma redefinição solicitada por e-mail de forma atômica.

    A comparação da senha e do e-mail impede que um link aberto em uma aba
    antiga seja aceito depois que a conta foi alterada em outro lugar. Como o
    cookie de autenticação também depende do hash da senha, todas as sessões
    existentes passam a ser invalidadas após a troca.
    """
    if not usuario_id or not senha_hash_anterior or not email or not senha_hash_nova:
        return False
    with conexao() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT usuario_id FROM portal_master_controle WHERE id = 1 FOR UPDATE")
            cur.execute(
                "UPDATE usuarios SET senha_hash = %s, troca_senha_obrigatoria = 0 "
                "WHERE id = %s AND senha_hash = %s AND email = %s",
                (senha_hash_nova, usuario_id, senha_hash_anterior, email),
            )
            atualizado = cur.rowcount == 1
    _cache_clear("_usuarios_cache")
    return atualizado


def _exigir_master_no_banco(cur, ator_id):
    """Confere o papel persistido, sem confiar em um papel recebido pelo chamador."""
    cur.execute("SELECT papel FROM usuarios WHERE id = %s", (ator_id,))
    ator = cur.fetchone()
    if not ator or ator["papel"] != "master":
        raise PermissionError("Somente o Master pode cadastrar ou promover Administradores.")


def inserir_novos_usuarios(usuarios, ator, origem="Cadastro individual"):
    """Inclui contas, permissões e auditoria na mesma transação.

    Não regrava contas existentes. Qualquer falha desfaz o lote inteiro.
    """
    if not usuarios:
        raise ValueError("Nenhum usuário para cadastrar.")
    if any(u.get("papel") not in {"viewer", "admin"} or
           (u["papel"] == "admin" and ator.get("papel") != "master") for u in usuarios):
        raise ValueError("Perfil não permitido para este cadastro.")
    emails_lote = set()
    for u in usuarios:
        email = u.get("email")
        if not isinstance(email, str) or not email.strip():
            raise ValueError("E-mail é obrigatório para cadastrar usuários.")
        email_normalizado = email.strip().casefold()
        if email_normalizado in emails_lote:
            raise ValueError("Há e-mails repetidos no cadastro. Nenhum usuário foi cadastrado.")
        emails_lote.add(email_normalizado)
    with conexao() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT usuario_id FROM portal_master_controle WHERE id = 1 FOR UPDATE")
            if any(u["papel"] == "admin" for u in usuarios):
                _exigir_master_no_banco(cur, ator.get("id"))
            cur.execute("SELECT usuario FROM usuarios")
            ocupados = {u["usuario"].casefold() for u in cur.fetchall()}
            for u in usuarios:
                login = u["usuario"].casefold()
                if login in ocupados:
                    raise ValueError(f'O login {u["usuario"]} já existe. Nenhum usuário foi cadastrado.')
                ocupados.add(login)
            cur.execute("SELECT email FROM usuarios WHERE email IS NOT NULL AND email <> ''")
            emails_ocupados = {u["email"].strip().casefold() for u in cur.fetchall()}
            for u in usuarios:
                if u["email"].strip().casefold() in emails_ocupados:
                    raise ValueError(f'O e-mail {u["email"]} já está associado a outro usuário. Nenhum usuário foi cadastrado.')
                emails_ocupados.add(u["email"].strip().casefold())
            cur.execute("SELECT id FROM pastas")
            pastas = [p["id"] for p in cur.fetchall()]
            # Novos Visualizadores criados por um Administrador herdam no máximo
            # o escopo persistido dele, incluindo exceções negativas.
            cur.execute("SELECT papel FROM usuarios WHERE id = %s", (ator.get("id"),))
            perfil_ator = cur.fetchone()
            if not perfil_ator:
                raise PermissionError("Usuário responsável pelo cadastro não encontrado.")
            permissoes_iniciais = [("usuario_pastas", "pasta_id", list(pastas))]
            if perfil_ator["papel"] == "admin":
                permissoes_iniciais = []
                for tabela, campo in (("usuario_pastas", "pasta_id"),
                                      ("usuario_subpastas", "subpasta_id"),
                                      ("usuario_dashboards", "dashboard_id"),
                                      ("usuario_subpasta_bloqueios", "subpasta_id"),
                                      ("usuario_dashboard_bloqueios", "dashboard_id")):
                    cur.execute(f"SELECT {campo} FROM {tabela} WHERE usuario_id = %s", (ator["id"],))
                    permissoes_iniciais.append((tabela, campo, [r[campo] for r in cur.fetchall()]))
            if contexto_ambiente():
                dados = load_data()
                permitidos = {"pasta_id": {p["id"] for p in dados["pastas"]},
                              "subpasta_id": {p["id"] for p in dados["subpastas"]},
                              "dashboard_id": {p["id"] for p in dados["dashboards"]}}
                permissoes_iniciais = [(t, c, [i for i in ids if i in permitidos[c]])
                                       for t, c, ids in permissoes_iniciais]
            for u in usuarios:
                cur.execute(
                    "INSERT INTO usuarios (id, nome, usuario, senha_hash, papel, email, troca_senha_obrigatoria) "
                    "VALUES (%s, %s, %s, %s, %s, %s, 1)",
                    (u["id"], u["nome"], u["usuario"], u["senha_hash"], u["papel"], u.get("email")),
                )
                if contexto_ambiente():
                    cur.execute("INSERT INTO ambiente_usuarios (ambiente_id, usuario_id) VALUES (%s, %s)",
                                (contexto_ambiente(), u["id"]))
                if u["papel"] == "viewer":
                    for tabela, campo, ids in permissoes_iniciais:
                        for valor in ids:
                            cur.execute(f"INSERT INTO {tabela} (usuario_id, {campo}) VALUES (%s, %s)",
                                        (u["id"], valor))
                cur.execute("INSERT INTO usuario_permissoes_estado (usuario_id, inicializado) VALUES (%s, 1)",
                            (u["id"],))
                perfil = {"admin": "Administrador", "viewer": "Visualizador"}[u["papel"]]
                cur.execute(
                    "INSERT INTO usuario_eventos "
                    "(id, data_hora, ator_id, ator_nome, tipo, usuario_id, usuario_nome, detalhe, ambiente_id) "
                    "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)",
                    (uuid.uuid4().hex, datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                     ator["id"], ator["nome"], "usuario_criado", u["id"], u["nome"],
                     f"{origem}. Perfil: {perfil}. Login: {u['usuario']}"[:500], contexto_ambiente() or "__global__"),
                )
    _cache_clear("_usuarios_cache")


def save_users(users, master_id=None, ator_id=None):
    """Substitui todo o conteudo de usuarios (e suas permissoes) pelo que
    estiver em 'users', no mesmo espirito do antigo save_data com JSON.
    Preserva a data de criacao original de cada usuario quando ela ja
    existir, para a ordem de exibicao nao embaralhar a cada edicao.
    Cadastro ou promocao para admin exige ator_id de um Master persistido.
    Regravar Administradores ja existentes nao cria novos privilegios."""
    with conexao() as conn:
        with conn.cursor() as cur:
            # O controle tambem serializa a criacao local do unico Master.
            cur.execute("SELECT usuario_id FROM portal_master_controle WHERE id = 1 FOR UPDATE")
            _validar_snapshot(users, _ler_usuarios(cur), "_usuarios_cache")
            cur.execute("SELECT id, papel FROM usuarios")
            papeis_atuais = {u["id"]: u["papel"] for u in cur.fetchall()}
            if any(u.get("papel") == "admin" and papeis_atuais.get(u["id"]) != u.get("papel") for u in users):
                _exigir_master_no_banco(cur, ator_id)
            cur.execute("SELECT * FROM usuarios WHERE papel = 'master'")
            masters = {u["id"]: u for u in cur.fetchall()}
            # Preserva os favoritos ANTES do delete+reinsert de usuarios --
            # a chave estrangeira em cascata apagaria os favoritos tambem,
            # mesmo para usuarios que continuam existindo com o mesmo id
            # (o DELETE FROM usuarios dispara o ON DELETE CASCADE).
            cur.execute("SELECT usuario_id, dashboard_id FROM favoritos")
            favoritos_preservados = list(cur.fetchall())

            cur.execute("DELETE FROM usuario_pastas")
            cur.execute("DELETE FROM usuario_subpastas")
            cur.execute("DELETE FROM usuario_dashboards")
            cur.execute("DELETE FROM usuarios WHERE papel <> 'master'")
            for u in users:
                if u["id"] in masters or u.get("papel") == "master":
                    # Somente fluxos autenticados de alteracao da propria conta
                    # passam master_id; nenhuma operacao administrativa o utiliza.
                    if u["id"] in masters and u["id"] == master_id:
                        cur.execute("""UPDATE usuarios SET senha_hash = %s, email = %s
                                       WHERE id = %s AND papel = 'master'""",
                                    (u["senha_hash"], u.get("email"), u["id"]))
                    continue
                if u.get("criado_em"):
                    cur.execute(
                        "INSERT INTO usuarios "
                        "(id, nome, usuario, senha_hash, papel, criado_em, troca_senha_obrigatoria, email) "
                        "VALUES (%s, %s, %s, %s, %s, %s, %s, %s)",
                        (
                            u["id"], u["nome"], u["usuario"], u["senha_hash"], u["papel"],
                            u["criado_em"],
                            int(bool(u.get("troca_senha_obrigatoria", False))), u.get("email"),
                        ),
                    )
                else:
                    cur.execute(
                        "INSERT INTO usuarios (id, nome, usuario, senha_hash, papel, troca_senha_obrigatoria, email) "
                        "VALUES (%s, %s, %s, %s, %s, %s, %s)",
                        (
                            u["id"], u["nome"], u["usuario"], u["senha_hash"], u["papel"],
                            int(bool(u.get("troca_senha_obrigatoria", False))), u.get("email"),
                        ),
                    )
                for pasta_id in u.get("pastas", []):
                    cur.execute(
                        "INSERT INTO usuario_pastas (usuario_id, pasta_id) VALUES (%s, %s)",
                        (u["id"], pasta_id),
                    )
                for subpasta_id in u.get("subpastas", []):
                    cur.execute(
                        "INSERT INTO usuario_subpastas (usuario_id, subpasta_id) VALUES (%s, %s)",
                        (u["id"], subpasta_id),
                    )
                for dash_id in u.get("dashboards", []):
                    cur.execute(
                        "INSERT INTO usuario_dashboards (usuario_id, dashboard_id) VALUES (%s, %s)",
                        (u["id"], dash_id),
                    )

            # Restaura os favoritos preservados -- apenas para usuarios que
            # continuam existindo apos este save (se um usuario foi de fato
            # excluido, como esperado, seus favoritos somem tambem).
            ids_atuais = {u["id"] for u in users} | set(masters)
            for fav in favoritos_preservados:
                if fav["usuario_id"] in ids_atuais and fav["usuario_id"] not in masters:
                    cur.execute(
                        "INSERT INTO favoritos (usuario_id, dashboard_id) VALUES (%s, %s)",
                        (fav["usuario_id"], fav["dashboard_id"]),
                    )
            cur.execute("DELETE FROM usuario_guias WHERE usuario_id NOT IN (SELECT id FROM usuarios)")
            cur.execute("DELETE FROM ambiente_usuarios WHERE usuario_id NOT IN (SELECT id FROM usuarios)")
            cur.execute("DELETE FROM ambiente_sessoes WHERE usuario_id NOT IN (SELECT id FROM usuarios)")
    _cache_clear("_usuarios_cache")


def atualizar_usuario_pontual(usuario_id, campos, versao_esperada=None, ator_id=None, permitir_master=False):
    """Atualiza somente uma conta e avança sua versão de concorrência."""
    permitidos = {"nome", "usuario", "email", "senha_hash", "papel", "troca_senha_obrigatoria"}
    campos = {campo: valor for campo, valor in (campos or {}).items() if campo in permitidos}
    if not campos:
        return
    if "papel" in campos and campos["papel"] not in {"master", "admin", "viewer"}:
        raise ValueError("Perfil não permitido.")
    with conexao() as conn, conn.cursor() as cur:
        cur.execute("SELECT id, papel, versao FROM usuarios WHERE id = %s FOR UPDATE", (usuario_id,))
        atual = cur.fetchone()
        if not atual:
            raise ValueError("Usuário não encontrado.")
        if atual["papel"] == "master" and not permitir_master:
            raise PermissionError("A conta Master não pode ser alterada por esta operação.")
        if versao_esperada is not None and int(atual.get("versao") or 1) != int(versao_esperada):
            raise ConflitoGravacao("A conta foi alterada em outra sessão. Recarregue a página antes de salvar.")
        if campos.get("papel") == "admin" and atual["papel"] != "admin":
            _exigir_master_no_banco(cur, ator_id)
        if atual["papel"] == "admin" and campos.get("papel") not in (None, "admin"):
            cur.execute("SELECT id FROM usuarios WHERE papel = 'admin' FOR UPDATE")
            if len(cur.fetchall()) <= 1:
                raise ValueError("Não é possível rebaixar o último administrador.")
        colunas = list(campos)
        valores = [campos[coluna] for coluna in colunas]
        cur.execute(
            "UPDATE usuarios SET " + ", ".join(f"{coluna} = %s" for coluna in colunas) +
            ", versao = versao + 1 WHERE id = %s",
            tuple(valores) + (usuario_id,),
        )
    _cache_clear("_usuarios_cache")


def salvar_permissoes_usuario_pontual(usuario_id, pastas, subpastas, dashboards,
                                      dashboards_bloqueados, subpastas_bloqueadas,
                                      versao_esperada=None, ator_id=None):
    """Substitui somente as permissões de uma conta em uma transação curta."""
    conjuntos = (
        ("usuario_pastas", "pasta_id", pastas),
        ("usuario_subpastas", "subpasta_id", subpastas),
        ("usuario_dashboards", "dashboard_id", dashboards),
        ("usuario_dashboard_bloqueios", "dashboard_id", dashboards_bloqueados),
        ("usuario_subpasta_bloqueios", "subpasta_id", subpastas_bloqueadas),
    )
    with conexao() as conn, conn.cursor() as cur:
        cur.execute("SELECT id, papel, versao FROM usuarios WHERE id = %s FOR UPDATE", (usuario_id,))
        atual = cur.fetchone()
        if not atual:
            raise ValueError("Usuário não encontrado.")
        if versao_esperada is not None and int(atual.get("versao") or 1) != int(versao_esperada):
            raise ConflitoGravacao("As permissões foram alteradas em outra sessão. Recarregue a página antes de salvar.")
        for tabela, coluna, ids in conjuntos:
            cur.execute(f"DELETE FROM {tabela} WHERE usuario_id = %s", (usuario_id,))
            valores = sorted({str(item) for item in (ids or []) if item})
            if valores:
                cur.executemany(
                    f"INSERT INTO {tabela} (usuario_id, {coluna}) VALUES (%s, %s)",
                    [(usuario_id, item) for item in valores],
                )
        cur.execute("""INSERT INTO usuario_permissoes_estado (usuario_id, inicializado)
                       VALUES (%s, 1) ON DUPLICATE KEY UPDATE inicializado = 1""", (usuario_id,))
        cur.execute("UPDATE usuarios SET versao = versao + 1 WHERE id = %s", (usuario_id,))
    _cache_clear("_usuarios_cache")


def remover_usuario_pontual(usuario_id, versao_esperada=None):
    """Remove uma conta sem tocar nas permissões ou favoritos de terceiros."""
    with conexao() as conn, conn.cursor() as cur:
        cur.execute("SELECT id, papel, versao FROM usuarios WHERE id = %s FOR UPDATE", (usuario_id,))
        atual = cur.fetchone()
        if not atual:
            return False
        if atual["papel"] == "master":
            raise PermissionError("A conta Master não pode ser removida.")
        if versao_esperada is not None and int(atual.get("versao") or 1) != int(versao_esperada):
            raise ConflitoGravacao("A conta foi alterada em outra sessão. Recarregue a página antes de excluir.")
        if atual["papel"] == "admin":
            cur.execute("SELECT id FROM usuarios WHERE papel = 'admin' FOR UPDATE")
            if len(cur.fetchall()) <= 1:
                raise ValueError("Não é possível excluir o último administrador.")
        for tabela in ("usuario_dashboard_bloqueios", "usuario_subpasta_bloqueios",
                       "usuario_permissoes_estado", "usuario_guias", "ambiente_usuarios",
                       "ambiente_sessoes"):
            cur.execute(f"DELETE FROM {tabela} WHERE usuario_id = %s", (usuario_id,))
        cur.execute("DELETE FROM usuarios WHERE id = %s", (usuario_id,))
    _cache_clear("_usuarios_cache")
    return True


# ===========================================================================
# Acessos (auditoria) -- cada evento usa INSERT, preservando o historico
# completo, sem exclusao automatica por tempo de armazenamento.
# ===========================================================================
def load_acessos():
    with conexao() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT * FROM acessos" + (" WHERE ambiente_id = %s" if contexto_ambiente() else ""),
                        (contexto_ambiente(),) if contexto_ambiente() else ())
            return list(cur.fetchall())


def _filtro_sql_acessos(filtros=None, dashboard_ids=None):
    """Monta filtros parametrizados compartilhados pela paginação de acessos.

    A autorização do Administrador continua sendo resolvida pela aplicação;
    aqui apenas a transformamos em ``dashboard_id IN (...)`` para que o banco
    nunca devolva registros fora do escopo já calculado.
    """
    filtros = filtros or {}
    clausulas, parametros = [], []
    ambiente_id = contexto_ambiente()
    if ambiente_id:
        clausulas.append("ambiente_id = %s")
        parametros.append(ambiente_id)
    if dashboard_ids is not None:
        ids = sorted({str(item) for item in dashboard_ids if item})
        if not ids:
            return " WHERE 1 = 0", []
        clausulas.append("dashboard_id IN (" + ", ".join(["%s"] * len(ids)) + ")")
        parametros.extend(ids)
    if filtros.get("q"):
        clausulas.append("LOWER(CONCAT_WS(' ', usuario_nome, usuario_login, dashboard_nome, pasta_nome)) LIKE %s")
        parametros.append("%" + str(filtros["q"]).strip().lower() + "%")
    if filtros.get("de"):
        clausulas.append("data_hora >= %s")
        parametros.append(str(filtros["de"]).strip()[:10] + " 00:00:00")
    if filtros.get("ate"):
        clausulas.append("data_hora <= %s")
        parametros.append(str(filtros["ate"]).strip()[:10] + " 23:59:59")
    for campo, coluna in (("usuario", "usuario_login"), ("ambiente", "ambiente_id"),
                          ("dashboard", "dashboard_nome"), ("status", "status")):
        if filtros.get(campo):
            clausulas.append(f"{coluna} = %s")
            parametros.append(str(filtros[campo]).strip())
    return (" WHERE " + " AND ".join(clausulas)) if clausulas else "", parametros


def pagina_acessos(filtros=None, dashboard_ids=None, pagina=1, tamanho=50):
    """Retorna somente uma página do histórico e sua quantidade total."""
    pagina = max(1, int(pagina or 1))
    tamanho = min(100, max(10, int(tamanho or 50)))
    where_sql, parametros = _filtro_sql_acessos(filtros, dashboard_ids)
    with conexao() as conn, conn.cursor() as cur:
        cur.execute("SELECT COUNT(*) AS total FROM acessos" + where_sql, tuple(parametros))
        total = cur.fetchone()["total"]
        deslocamento = (pagina - 1) * tamanho
        cur.execute(
            """SELECT a.*, COALESCE(amb.nome, a.ambiente_id, 'Ambiente inicial') AS ambiente_nome
               FROM acessos a LEFT JOIN ambientes amb ON amb.id = a.ambiente_id""" + where_sql.replace("ambiente_id", "a.ambiente_id") +
            " ORDER BY a.data_hora DESC, a.id DESC LIMIT %s OFFSET %s",
            tuple(parametros) + (tamanho, deslocamento),
        )
        return list(cur.fetchall()), total


def opcoes_acessos(dashboard_ids=None, ambientes_disponiveis=None):
    """Carrega opções de filtro sem transferir o histórico inteiro ao Flask.

    A lista de ambientes pode ser fornecida pela aplicação e, nesse caso,
    vem do cadastro de ambientes — não do histórico de acessos. Assim, um
    ambiente continua aparecendo no filtro mesmo sem registros de auditoria.
    Os usuários associados a cada opção continuam sendo derivados do histórico
    apenas para o filtro dependente no navegador.
    """
    where_sql, parametros = _filtro_sql_acessos({}, dashboard_ids)
    where_sql_alias = where_sql.replace("ambiente_id", "a.ambiente_id")
    with conexao() as conn, conn.cursor() as cur:
        cur.execute(
            "SELECT DISTINCT usuario_login, usuario_nome FROM acessos" + where_sql +
            " ORDER BY usuario_nome ASC, usuario_login ASC", tuple(parametros),
        )
        usuarios = [(row["usuario_login"], row["usuario_nome"]) for row in cur.fetchall()]

        cur.execute(
            """SELECT DISTINCT a.ambiente_id,
                      COALESCE(amb.nome, a.ambiente_id, 'Ambiente inicial') AS ambiente_nome,
                      a.usuario_login
               FROM acessos a LEFT JOIN ambientes amb ON amb.id = a.ambiente_id""" + where_sql_alias +
            " ORDER BY ambiente_nome ASC, a.ambiente_id ASC, a.usuario_login ASC", tuple(parametros),
        )
        ambientes_por_id = {}
        for row in cur.fetchall():
            ambiente_id = row.get("ambiente_id") or ""
            if not ambiente_id:
                continue
            item = ambientes_por_id.setdefault(ambiente_id, {
                "id": ambiente_id,
                "nome": row.get("ambiente_nome") or ambiente_id,
                "usuarios": set(),
            })
            if row.get("usuario_login"):
                item["usuarios"].add(row["usuario_login"])
        ambientes = []
        if ambientes_disponiveis is not None:
            # O seletor deve refletir o cadastro de ambientes, mesmo quando a
            # tabela de acessos foi limpa ou um ambiente ainda não teve acesso.
            for ambiente in ambientes_disponiveis:
                ambiente_id = str(ambiente.get("id") or "").strip()
                if not ambiente_id:
                    continue
                historico = ambientes_por_id.get(ambiente_id, {})
                ambientes.append({
                    "id": ambiente_id,
                    "nome": ambiente.get("nome") or historico.get("nome") or ambiente_id,
                    "usuarios": sorted(historico.get("usuarios", set())),
                })
            ambientes.sort(key=lambda x: ((x.get("nome") or "").casefold(), x.get("id") or ""))
        else:
            for item in sorted(ambientes_por_id.values(), key=lambda x: ((x.get("nome") or "").casefold(), x.get("id") or "")):
                item = dict(item)
                item["usuarios"] = sorted(item["usuarios"])
                ambientes.append(item)

        cur.execute(
            """SELECT DISTINCT a.dashboard_nome, a.ambiente_id,
                      COALESCE(amb.nome, a.ambiente_id, 'Ambiente inicial') AS ambiente_nome,
                      a.usuario_login
               FROM acessos a LEFT JOIN ambientes amb ON amb.id = a.ambiente_id""" + where_sql_alias +
            " ORDER BY ambiente_nome ASC, a.dashboard_nome ASC, a.usuario_login ASC", tuple(parametros),
        )
        dashboards_por_chave = {}
        for row in cur.fetchall():
            nome = row.get("dashboard_nome") or ""
            if not nome:
                continue
            ambiente_id = row.get("ambiente_id") or ""
            chave = (nome, ambiente_id)
            item = dashboards_por_chave.setdefault(chave, {
                "nome": nome,
                "ambiente_id": ambiente_id,
                "ambiente_nome": row.get("ambiente_nome") or "",
                "usuarios": set(),
            })
            if row.get("usuario_login"):
                item["usuarios"].add(row["usuario_login"])
        dashboards = []
        for item in sorted(dashboards_por_chave.values(), key=lambda x: ((x.get("ambiente_nome") or "").casefold(), (x.get("nome") or "").casefold())):
            item = dict(item)
            item["usuarios"] = sorted(item["usuarios"])
            dashboards.append(item)
    return usuarios, ambientes, dashboards


def iterar_acessos(filtros=None, dashboard_ids=None, tamanho_lote=1000):
    """Entrega o histórico filtrado em sequência, sem carregá-lo inteiro.

    A exportação usa um cursor sem buffer do PyMySQL. A paginação por chave
    (data/hora + id) evita o custo crescente de ``OFFSET`` quando a tabela já
    tiver muitos eventos e mantém a memória do processo limitada ao lote atual.
    """
    tamanho_lote = min(5000, max(100, int(tamanho_lote or 1000)))
    where_sql, parametros_base = _filtro_sql_acessos(filtros, dashboard_ids)
    conn = get_connection(pymysql.cursors.SSDictCursor)
    ultimo_data_hora = ultimo_id = None
    try:
        with conn.cursor() as cur:
            while True:
                cursor_sql = ""
                parametros = list(parametros_base)
                if ultimo_data_hora is not None:
                    cursor_sql = (
                        " AND (data_hora < %s OR (data_hora = %s AND id < %s))"
                        if where_sql else
                        " WHERE (data_hora < %s OR (data_hora = %s AND id < %s))"
                    )
                    parametros.extend((ultimo_data_hora, ultimo_data_hora, ultimo_id))
                cur.execute(
                    """SELECT a.*, COALESCE(amb.nome, a.ambiente_id, 'Ambiente inicial') AS ambiente_nome
                       FROM acessos a LEFT JOIN ambientes amb ON amb.id = a.ambiente_id""" + where_sql.replace("ambiente_id", "a.ambiente_id") + cursor_sql.replace("data_hora", "a.data_hora").replace("id <", "a.id <") +
                    " ORDER BY a.data_hora DESC, a.id DESC LIMIT %s",
                    tuple(parametros) + (tamanho_lote,),
                )
                lote = cur.fetchmany(tamanho_lote)
                if not lote:
                    break
                for acesso in lote:
                    yield acesso
                ultimo_data_hora = lote[-1]["data_hora"]
                ultimo_id = lote[-1]["id"]
    finally:
        conn.close()


def resumo_acessos(filtros=None, dashboard_ids=None, hoje=None, semana=None):
    """Agrega os indicadores do recorte diretamente no MySQL."""
    where_sql, parametros = _filtro_sql_acessos(filtros, dashboard_ids)
    hoje = hoje or datetime.now().strftime("%Y-%m-%d")
    semana = semana or (datetime.now() - timedelta(days=7)).strftime("%Y-%m-%d")
    with conexao() as conn, conn.cursor() as cur:
        cur.execute(
            """SELECT
                 COALESCE(SUM(status = 'sucesso'), 0) AS total,
                 COUNT(DISTINCT CASE WHEN status = 'sucesso' THEN usuario_login END) AS usuarios_unicos,
                 COALESCE(SUM(status = 'negado'), 0) AS total_negados,
                 COALESCE(SUM(status = 'sucesso' AND data_hora >= %s AND data_hora <= %s), 0) AS acessos_hoje,
                 COALESCE(SUM(status = 'sucesso' AND data_hora >= %s), 0) AS acessos_semana
               FROM acessos""" + where_sql,
            (hoje + " 00:00:00", hoje + " 23:59:59", semana + " 00:00:00") + tuple(parametros),
        )
        return cur.fetchone()


def ranking_acessos(filtros=None, dashboard_ids=None, limite=10):
    """Retorna os dashboards mais acessados no recorte selecionado."""
    where_sql, parametros = _filtro_sql_acessos(filtros, dashboard_ids)
    complemento = " AND status = 'sucesso'" if where_sql else " WHERE status = 'sucesso'"
    with conexao() as conn, conn.cursor() as cur:
        cur.execute(
            """SELECT dashboard_id, dashboard_nome, pasta_nome, COUNT(*) AS quantidade
               FROM acessos""" + where_sql + complemento +
            " GROUP BY dashboard_id, dashboard_nome, pasta_nome"
            " ORDER BY quantidade DESC, dashboard_nome ASC LIMIT %s",
            tuple(parametros) + (max(1, min(int(limite), 100)),),
        )
        return list(cur.fetchall())


def grafico_acessos(filtros=None, dashboard_ids=None, inicio=None, fim=None):
    """Agrupa os acessos válidos por dia, sem transferir eventos individuais."""
    filtros_grafico = dict(filtros or {})
    if inicio:
        filtros_grafico["de"] = inicio
    if fim:
        filtros_grafico["ate"] = fim
    where_sql, parametros = _filtro_sql_acessos(filtros_grafico, dashboard_ids)
    complemento = " AND status = 'sucesso'" if where_sql else " WHERE status = 'sucesso'"
    with conexao() as conn, conn.cursor() as cur:
        cur.execute(
            "SELECT LEFT(data_hora, 10) AS dia, COUNT(*) AS quantidade FROM acessos" +
            where_sql + complemento + " GROUP BY LEFT(data_hora, 10) ORDER BY dia ASC",
            tuple(parametros),
        )
        return list(cur.fetchall())


def visao_global_acessos(dashboard_ids=None):
    """Dados históricos independentes do filtro: uso por dashboard e último usuário."""
    where_sql, parametros = _filtro_sql_acessos({}, dashboard_ids)
    sucesso_where = where_sql + (" AND status = 'sucesso'" if where_sql else " WHERE status = 'sucesso'")
    with conexao() as conn, conn.cursor() as cur:
        cur.execute("SELECT DISTINCT dashboard_id FROM acessos" + sucesso_where, tuple(parametros))
        dashboards_acessados = {row["dashboard_id"] for row in cur.fetchall() if row.get("dashboard_id")}
        # Os campos de identidade não mudam dentro da conta. MAX evita trazer
        # todo o histórico e MAX(data_hora) preserva a última atividade.
        cur.execute(
            """SELECT usuario_id, MAX(usuario_nome) AS usuario_nome,
                      MAX(usuario_login) AS usuario_login, MAX(data_hora) AS data_hora
               FROM acessos""" + where_sql +
            " GROUP BY usuario_id ORDER BY data_hora DESC, usuario_id DESC",
            tuple(parametros),
        )
        ultimos = list(cur.fetchall())
    return dashboards_acessados, ultimos


def resumo_integridade_dashboards(dashboard_ids=None, inicio_30d=None):
    """Último acesso e volume recente por dashboard, sem trazer o histórico."""
    where_sql, parametros = _filtro_sql_acessos({}, dashboard_ids)
    complemento = " AND status = 'sucesso'" if where_sql else " WHERE status = 'sucesso'"
    inicio_30d = inicio_30d or (datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d 00:00:00")
    with conexao() as conn, conn.cursor() as cur:
        cur.execute(
            """SELECT dashboard_id, COUNT(*) AS acessos_total, MAX(data_hora) AS ultimo_acesso,
                      COALESCE(SUM(data_hora >= %s), 0) AS acessos_30d
               FROM acessos""" + where_sql + complemento + " GROUP BY dashboard_id",
            (inicio_30d,) + tuple(parametros),
        )
        return {row["dashboard_id"]: row for row in cur.fetchall() if row.get("dashboard_id")}


def resumo_usuarios_acessos(dashboard_ids=None, usuario_ids=None, inicio_30d=None):
    """Agrega a visão de usuários para evitar leitura integral da auditoria."""
    where_sql, parametros = _filtro_sql_acessos({}, dashboard_ids)
    clausula_usuario, parametros_usuario = "", []
    if usuario_ids is not None:
        ids = sorted({str(item) for item in usuario_ids if item})
        if not ids:
            return {"ativos": set(), "ultimos": [], "top_dashboards": []}
        clausula_usuario = " AND usuario_id IN (" + ", ".join(["%s"] * len(ids)) + ")" if where_sql else " WHERE usuario_id IN (" + ", ".join(["%s"] * len(ids)) + ")"
        parametros_usuario = ids
    sucesso = " AND status = 'sucesso'" if (where_sql or clausula_usuario) else " WHERE status = 'sucesso'"
    base = where_sql + clausula_usuario + sucesso
    inicio_30d = inicio_30d or (datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d 00:00:00")
    params = tuple(parametros) + tuple(parametros_usuario)
    with conexao() as conn, conn.cursor() as cur:
        cur.execute("SELECT DISTINCT usuario_id FROM acessos" + base + " AND data_hora >= %s", params + (inicio_30d,))
        ativos = {row["usuario_id"] for row in cur.fetchall() if row.get("usuario_id")}
        cur.execute(
            """SELECT usuario_id, MAX(usuario_nome) AS usuario_nome,
                      MAX(usuario_login) AS usuario_login, MAX(dashboard_nome) AS dashboard_nome,
                      MAX(pasta_nome) AS pasta_nome, MAX(data_hora) AS data_hora
               FROM acessos""" + base + " GROUP BY usuario_id ORDER BY data_hora DESC LIMIT 6",
            params,
        )
        ultimos = list(cur.fetchall())
        cur.execute(
            """SELECT dashboard_id, MAX(dashboard_nome) AS dashboard_nome,
                      MAX(pasta_nome) AS pasta_nome, COUNT(*) AS acessos
               FROM acessos""" + base +
            " AND data_hora >= %s GROUP BY dashboard_id ORDER BY acessos DESC, dashboard_nome ASC LIMIT 5",
            params + (inicio_30d,),
        )
        top_dashboards = list(cur.fetchall())
    return {"ativos": ativos, "ultimos": ultimos, "top_dashboards": top_dashboards}


def inserir_acesso(registro):
    with conexao() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "INSERT INTO acessos "
                "(id, data_hora, usuario_id, usuario_nome, usuario_login, usuario_papel, "
                " dashboard_id, dashboard_nome, pasta_nome, status, ip, ambiente_id) "
                "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
                (
                    registro["id"], registro["data_hora"], registro["usuario_id"],
                    registro["usuario_nome"], registro["usuario_login"], registro["usuario_papel"],
                    registro["dashboard_id"], registro["dashboard_nome"], registro["pasta_nome"],
                    registro["status"], registro["ip"], _ambiente_do_dashboard(cur, registro.get("dashboard_id")),
                ),
            )


# ===========================================================================
# Auditoria de usuarios
# ===========================================================================
def load_user_events(limit=8):
    with conexao() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT * FROM usuario_eventos" + (" WHERE ambiente_id = %s" if contexto_ambiente() else "") +
                " ORDER BY data_hora DESC, id DESC LIMIT %s",
                ((contexto_ambiente(),) if contexto_ambiente() else ()) + (int(limit),),
            )
            return list(cur.fetchall())


def inserir_user_evento(registro):
    with conexao() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "INSERT INTO usuario_eventos "
                "(id, data_hora, ator_id, ator_nome, tipo, usuario_id, usuario_nome, detalhe, ambiente_id) "
                "VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)",
                (
                    registro["id"], registro["data_hora"], registro.get("ator_id"),
                    registro.get("ator_nome"), registro["tipo"], registro.get("usuario_id"),
                    registro.get("usuario_nome"), registro.get("detalhe"), contexto_ambiente() or "__global__",
                ),
            )


# ===========================================================================
# Favoritos
# ===========================================================================
def carregar_favoritos(usuario_id):
    """Retorna um conjunto (set) com os ids dos dashboards que o usuario
    marcou como favorito."""
    with conexao() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT dashboard_id FROM favoritos WHERE usuario_id = %s",
                (usuario_id,),
            )
            return {row["dashboard_id"] for row in list(cur.fetchall())}


def alternar_favorito(usuario_id, dashboard_id):
    """Marca/desmarca um dashboard como favorito para o usuario. Retorna
    True se ficou favoritado, False se foi desfavoritado."""
    with conexao() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT 1 FROM favoritos WHERE usuario_id = %s AND dashboard_id = %s",
                (usuario_id, dashboard_id),
            )
            ja_favoritado = cur.fetchone() is not None
            if ja_favoritado:
                cur.execute(
                    "DELETE FROM favoritos WHERE usuario_id = %s AND dashboard_id = %s",
                    (usuario_id, dashboard_id),
                )
                return False
            else:
                cur.execute(
                    "INSERT INTO favoritos (usuario_id, dashboard_id) VALUES (%s, %s)",
                    (usuario_id, dashboard_id),
                )
                return True



# ===========================================================================
# Aviso fixado (mensagem do admin exibida no topo para todos os usuarios)
# ===========================================================================
def _encerrar_avisos_expirados(cur):
    """Retira o ponteiro ativo de avisos que completaram 24 horas.

    A publicação e seus eventos permanecem no histórico. Executar esta rotina
    nas leituras e ações do aviso dispensa um agendador externo e mantém o
    status consistente assim que qualquer pessoa voltar ao portal.
    """
    cur.execute("""
        UPDATE ambiente_avisos e
        JOIN avisos_publicacoes p ON p.id = e.aviso_id
        SET e.aviso_id = NULL
        WHERE e.aviso_id IS NOT NULL
          AND COALESCE(p.expira_em, DATE_ADD(p.publicado_em, INTERVAL 24 HOUR)) <= CURRENT_TIMESTAMP
    """)


def encerrar_avisos_expirados():
    """Aplica a expiração de 24h sem apagar publicações nem auditoria."""
    with conexao() as conn, conn.cursor() as cur:
        _encerrar_avisos_expirados(cur)


def carregar_aviso():
    """Retorna o texto do aviso fixado, ou None se nao houver nenhum."""
    with conexao() as conn, conn.cursor() as cur:
        _encerrar_avisos_expirados(cur)
        cur.execute("""SELECT p.texto FROM ambiente_avisos e JOIN avisos_publicacoes p ON p.id = e.aviso_id
            WHERE e.ambiente_id = %s AND COALESCE(p.inicio_em, p.publicado_em) <= CURRENT_TIMESTAMP""", (contexto_ambiente() or INICIAL,))
        linha = cur.fetchone()
        return linha["texto"] if linha else None


def carregar_aviso_atual():
    """Retorna os dados completos do aviso ativo no ambiente atual.

    ``carregar_aviso`` continua retornando somente o texto para preservar a
    compatibilidade com os cartões antigos. A tela administrativa precisa do
    assunto, identificador e data de publicação para renderizar uma prévia e
    apontar a exclusão para o ambiente correto.
    """
    with conexao() as conn, conn.cursor() as cur:
        _encerrar_avisos_expirados(cur)
        cur.execute("""
            SELECT p.id, p.assunto, p.texto, p.publicado_em, p.expira_em
            FROM ambiente_avisos e
            JOIN avisos_publicacoes p ON p.id = e.aviso_id
            WHERE e.ambiente_id = %s
        """, (contexto_ambiente() or INICIAL,))
        return cur.fetchone()


def _normalizar_ids_ambientes(ambiente_ids):
    if ambiente_ids is None:
        return None
    return list(dict.fromkeys(str(item).strip() for item in ambiente_ids if str(item).strip()))


def _filtro_ids_ambientes(coluna, ambiente_ids, parametros):
    ids = _normalizar_ids_ambientes(ambiente_ids)
    if ids is None:
        return ""
    if not ids:
        return " AND 1 = 0"
    parametros.extend(ids)
    return " AND " + coluna + " IN (" + ",".join(["%s"] * len(ids)) + ")"


def carregar_avisos_ativos(ambiente_ids=None):
    """Lista todos os avisos atualmente instalados, sem depender da sessão.

    A consulta é usada pelo Master para visualizar e excluir avisos sem
    precisar selecionar um ambiente. Avisos antigos permanecem no histórico,
    mas só o ponteiro em ``ambiente_avisos`` é considerado ativo. Ambientes
    inativos continuam visíveis para que o aviso possa ser retirado
    individualmente; a operação em massa permanece restrita aos ambientes
    ativos.
    """
    with conexao() as conn, conn.cursor() as cur:
        _encerrar_avisos_expirados(cur)
        parametros = []
        consulta = """
            SELECT a.id AS ambiente_id, a.nome AS ambiente_nome, a.ativo AS ambiente_ativo,
                   p.id, p.assunto, p.texto, p.publicado_em, p.expira_em
            FROM ambiente_avisos e
            JOIN ambientes a ON a.id = e.ambiente_id
            JOIN avisos_publicacoes p ON p.id = e.aviso_id
            WHERE e.aviso_id IS NOT NULL
        """
        consulta += _filtro_ids_ambientes("a.id", ambiente_ids, parametros)
        consulta += " ORDER BY a.ativo DESC, a.nome, a.id"
        cur.execute(consulta, parametros)
        return list(cur.fetchall())


def _escopo_avisos_leitura(coluna):
    """Restringe avisos ao ambiente atualmente selecionado."""
    return coluna + " = %s", [contexto_ambiente() or INICIAL]


def carregar_aviso_dashboard():
    """Aviso no intervalo de início/fim, independentemente dos aceites."""
    with conexao() as conn:
        with conn.cursor() as cur:
            _encerrar_avisos_expirados(cur)
            filtro, parametros = _escopo_avisos_leitura("e.ambiente_id")
            cur.execute(f"""
                SELECT p.id, p.assunto, p.texto, p.publicado_em, a.nome AS ambiente_nome,
                       COALESCE(p.inicio_em, p.publicado_em) AS inicio_em,
                       COALESCE(p.expira_em, DATE_ADD(p.publicado_em, INTERVAL 24 HOUR)) AS expira_em,
                       CURRENT_TIMESTAMP AS agora
                FROM ambiente_avisos e JOIN avisos_publicacoes p ON p.id = e.aviso_id
                JOIN ambientes a ON a.id = e.ambiente_id
                WHERE {filtro} AND a.ativo = 1
                  AND COALESCE(p.inicio_em, p.publicado_em) <= CURRENT_TIMESTAMP
                ORDER BY p.publicado_em DESC, p.id LIMIT 1
            """, parametros)
            linha = cur.fetchone()
    if not linha:
        return None
    segundos_restantes = (linha["expira_em"] - linha["agora"]).total_seconds()
    if segundos_restantes <= 0 or linha["inicio_em"] > linha["agora"]:
        return None
    return {
        "id": linha["id"], "assunto": linha["assunto"] or "Comunicado do portal",
        "texto": linha["texto"],
        "ambiente_nome": linha["ambiente_nome"],
        "publicado_em": linha["publicado_em"].strftime("%d/%m/%Y %H:%M"),
        "expira_em": linha["expira_em"].strftime("%d/%m/%Y %H:%M"),
        "inicio_em": linha["inicio_em"].strftime("%d/%m/%Y %H:%M"),
        "duracao": _duracao_aviso_texto(linha["inicio_em"], linha["expira_em"]),
        "segundos_restantes": segundos_restantes,
    }


def _incluir_destinatarios_aviso(cur, aviso_id):
    cur.execute("""
        INSERT IGNORE INTO avisos_destinatarios (aviso_id, usuario_id, nome, usuario, papel)
        SELECT %s, id, nome, usuario, papel FROM usuarios
    """, (aviso_id,))


def _nome_publicador(cur, ator_id):
    if not ator_id:
        return None
    cur.execute("SELECT nome FROM usuarios WHERE id = %s", (ator_id,))
    linha = cur.fetchone()
    return linha["nome"] if linha else None


def _periodo_aviso(cur, inicio, fim, duracao):
    cur.execute("SELECT CURRENT_TIMESTAMP AS agora")
    agora = cur.fetchone()["agora"]
    if inicio is None and fim is None:
        return agora, agora + timedelta(hours=_duracao_aviso_horas(duracao))
    try:
        inicio = datetime.strptime(inicio, "%Y-%m-%dT%H:%M")
        fim = datetime.strptime(fim, "%Y-%m-%dT%H:%M")
    except (TypeError, ValueError) as erro:
        raise ValueError("Informe a data e hora de início e fim.") from erro
    if fim <= inicio:
        raise ValueError("O fim deve ser posterior ao início.")
    if fim <= agora:
        raise ValueError("O fim do aviso deve estar no futuro.")
    return inicio, fim


def _duracao_aviso_texto(inicio, fim):
    minutos = max(0, int((fim - inicio).total_seconds() // 60))
    dias, resto = divmod(minutos, 1440)
    horas, minutos = divmod(resto, 60)
    partes = [f"{n} {singular if n == 1 else plural}" for n, singular, plural in
              ((dias, "dia", "dias"), (horas, "hora", "horas"), (minutos, "minuto", "minutos")) if n]
    return " e ".join(partes) or "0 minutos"


def _duracao_aviso_horas(valor):
    """Valida a vigência escolhida para uma publicação (1 hora a 30 dias)."""
    try:
        horas = int(valor)
    except (TypeError, ValueError) as erro:
        raise ValueError("Informe uma duração válida para o aviso.") from erro
    if not 1 <= horas <= 24 * 30:
        raise ValueError("A duração do aviso deve ficar entre 1 hora e 30 dias.")
    return horas


def salvar_aviso(texto, assunto="Sem assunto", ator_id=None, duracao_horas=24, inicio_em=None, fim_em=None):
    """Publica uma nova versao; nunca reutiliza aceites de outra mensagem."""
    with conexao() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT aviso_id FROM ambiente_avisos WHERE ambiente_id = %s FOR UPDATE", (contexto_ambiente() or INICIAL,))
            aviso_id = uuid.uuid4().hex
            inicio_em, expira_em = _periodo_aviso(cur, inicio_em, fim_em, duracao_horas)
            cur.execute("""
                INSERT INTO avisos_publicacoes
                    (id, assunto, texto, ambiente_id, inicio_em, expira_em, publicado_por, publicado_por_nome)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
            """, (aviso_id, assunto, texto, contexto_ambiente() or INICIAL,
                   inicio_em, expira_em, ator_id, _nome_publicador(cur, ator_id)))
            cur.execute("""INSERT INTO avisos_destinatarios (aviso_id, usuario_id, nome, usuario, papel)
                SELECT %s, u.id, u.nome, u.usuario, u.papel FROM usuarios u
                JOIN ambiente_usuarios au ON au.usuario_id = u.id
                WHERE au.ambiente_id = %s AND u.papel <> 'master'""", (aviso_id, contexto_ambiente() or INICIAL))
            cur.execute("UPDATE ambiente_avisos SET aviso_id = %s WHERE ambiente_id = %s", (aviso_id, contexto_ambiente() or INICIAL))
            return aviso_id


def salvar_aviso_todos(ator_id, texto, assunto="Sem assunto", duracao_horas=24, inicio_em=None, fim_em=None):
    """Publica a mesma mensagem em todos os ambientes ativos.

    Cada ambiente recebe uma publicação própria para que visualizações,
    aceites e o histórico continuem isolados. A operação é atômica: se uma
    publicação não puder ser criada, nenhuma das anteriores é confirmada.
    A conferência do papel Master acontece novamente dentro da transação.
    """
    with conexao() as conn:
        with conn.cursor() as cur:
            _exigir_master_no_banco(cur, ator_id)
            publicador_nome = _nome_publicador(cur, ator_id)
            cur.execute("SELECT id FROM ambientes WHERE ativo = 1 ORDER BY nome, id FOR UPDATE")
            ambientes = [row["id"] for row in cur.fetchall()]
            if not ambientes:
                raise ValueError("Não há ambientes ativos disponíveis para receber o aviso.")

            aviso_ids = []
            inicio_em, expira_em = _periodo_aviso(cur, inicio_em, fim_em, duracao_horas)
            for ambiente_id in ambientes:
                aviso_id = uuid.uuid4().hex
                cur.execute(
                    """INSERT INTO avisos_publicacoes
                        (id, assunto, texto, ambiente_id, inicio_em, expira_em, publicado_por, publicado_por_nome)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)""",
                    (aviso_id, assunto, texto, ambiente_id, inicio_em, expira_em, ator_id, publicador_nome),
                )
                cur.execute("""
                    INSERT INTO avisos_destinatarios (aviso_id, usuario_id, nome, usuario, papel)
                    SELECT %s, u.id, u.nome, u.usuario, u.papel FROM usuarios u
                    JOIN ambiente_usuarios au ON au.usuario_id = u.id
                    WHERE au.ambiente_id = %s AND u.papel <> 'master'
                """, (aviso_id, ambiente_id))
                # Instalações antigas podem não ter criado a linha de estado
                # para um ambiente já existente; o upsert mantém a operação
                # compatível sem abrir uma segunda transação.
                cur.execute("""
                    INSERT INTO ambiente_avisos (ambiente_id, aviso_id) VALUES (%s, %s)
                    ON DUPLICATE KEY UPDATE aviso_id = VALUES(aviso_id)
                """, (ambiente_id, aviso_id))
                aviso_ids.append(aviso_id)
            return aviso_ids


def remover_aviso():
    with conexao() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT aviso_id FROM ambiente_avisos WHERE ambiente_id = %s FOR UPDATE", (contexto_ambiente() or INICIAL,))
            cur.execute("UPDATE ambiente_avisos SET aviso_id = NULL WHERE ambiente_id = %s", (contexto_ambiente() or INICIAL,))


def remover_avisos_todos(ator_id):
    """Retira os avisos ativos de todos os ambientes ativos.

    A exclusão em massa remove apenas os ponteiros atuais em
    ``ambiente_avisos``. Publicações, visualizações e aceites continuam no
    histórico para auditoria. A identidade do Master é conferida dentro da
    mesma transação para impedir chamadas diretas de outros perfis.
    """
    with conexao() as conn:
        with conn.cursor() as cur:
            _exigir_master_no_banco(cur, ator_id)
            cur.execute("""
                SELECT e.ambiente_id
                FROM ambiente_avisos e
                JOIN ambientes a ON a.id = e.ambiente_id
                WHERE a.ativo = 1 AND e.aviso_id IS NOT NULL
                ORDER BY a.nome, a.id
                FOR UPDATE
            """)
            ids = [row["ambiente_id"] for row in cur.fetchall()]
            if not ids:
                return 0
            marcadores = ",".join(["%s"] * len(ids))
            cur.execute(
                f"UPDATE ambiente_avisos SET aviso_id = NULL "
                f"WHERE ambiente_id IN ({marcadores}) AND aviso_id IS NOT NULL",
                tuple(ids),
            )
            return cur.rowcount


def aviso_pendente(usuario_id):
    with conexao() as conn:
        with conn.cursor() as cur:
            _encerrar_avisos_expirados(cur)
            filtro, parametros = _escopo_avisos_leitura("e.ambiente_id")
            cur.execute(f"""
                SELECT p.id, p.assunto, p.texto, a.nome AS ambiente_nome FROM ambiente_avisos e
                JOIN ambientes a ON a.id = e.ambiente_id
                JOIN avisos_publicacoes p ON p.id = e.aviso_id
                LEFT JOIN avisos_destinatarios d ON d.aviso_id = p.id AND d.usuario_id = %s
                WHERE {filtro} AND COALESCE(p.inicio_em, p.publicado_em) <= CURRENT_TIMESTAMP AND d.aceito_em IS NULL AND d.recusado_em IS NULL
                  AND EXISTS (SELECT 1 FROM ambiente_usuarios au JOIN ambientes a ON a.id = au.ambiente_id
                              WHERE au.ambiente_id = e.ambiente_id AND au.usuario_id = %s AND a.ativo = 1)
            ORDER BY p.publicado_em, p.id LIMIT 1
            """, [usuario_id] + parametros + [usuario_id])
            return cur.fetchone()


def registrar_aviso(aviso_id, usuario_id, evento_id, aceitar=False, recusar=False):
    """Uma linha por abertura, com resposta imutavel e repeticoes de rede idempotentes."""
    if aceitar and recusar:
        return False
    with conexao() as conn:
        with conn.cursor() as cur:
            _encerrar_avisos_expirados(cur)
            ambiente_aviso = contexto_ambiente() or INICIAL
            cur.execute("SELECT aviso_id FROM ambiente_avisos WHERE ambiente_id = %s FOR UPDATE", (ambiente_aviso,))
            estado = cur.fetchone()
            if not estado or estado["aviso_id"] != aviso_id:
                return False
            cur.execute("""SELECT 1 FROM ambiente_usuarios au JOIN ambientes a ON a.id = au.ambiente_id
                WHERE au.usuario_id = %s AND au.ambiente_id = %s AND a.ativo = 1""", (usuario_id, ambiente_aviso))
            if not cur.fetchone():
                return False
            cur.execute("""SELECT id FROM avisos_publicacoes WHERE id = %s
                AND COALESCE(inicio_em, publicado_em) <= CURRENT_TIMESTAMP
                AND COALESCE(expira_em, DATE_ADD(publicado_em, INTERVAL 24 HOUR)) > CURRENT_TIMESTAMP""", (aviso_id,))
            if not cur.fetchone():
                return False
            chave = (aviso_id, usuario_id, evento_id)
            cur.execute("SELECT * FROM avisos_eventos WHERE aviso_id = %s AND usuario_id = %s AND evento_id = %s", chave)
            evento = cur.fetchone()
            if evento and (evento["aceito_em"] or evento["recusado_em"]):
                if aceitar:
                    return bool(evento["aceito_em"])
                if recusar:
                    return bool(evento["recusado_em"])
                return True
            if aceitar and not evento:
                return False
            cur.execute("SELECT aceito_em FROM avisos_destinatarios WHERE aviso_id = %s AND usuario_id = %s",
                        (aviso_id, usuario_id))
            destinatario = cur.fetchone()
            if destinatario and destinatario["aceito_em"]:
                return False
            if not evento:
                # Clicar em Agora nao tambem confirma que o modal foi visto.
                cur.execute("""
                    INSERT INTO avisos_eventos (aviso_id, usuario_id, evento_id, nome, usuario, papel)
                    SELECT %s, id, %s, nome, usuario, papel FROM usuarios WHERE id = %s
                """, (aviso_id, evento_id, usuario_id))
                if not cur.rowcount:
                    return False
            cur.execute("""
                INSERT IGNORE INTO avisos_destinatarios (aviso_id, usuario_id, nome, usuario, papel)
                SELECT %s, id, nome, usuario, papel FROM usuarios WHERE id = %s
            """, (aviso_id, usuario_id))
            cur.execute("""UPDATE avisos_destinatarios SET visualizado_em = COALESCE(visualizado_em, CURRENT_TIMESTAMP)
                           WHERE aviso_id = %s AND usuario_id = %s""", (aviso_id, usuario_id))
            if aceitar:
                cur.execute("UPDATE avisos_eventos SET aceito_em = CURRENT_TIMESTAMP WHERE aviso_id = %s AND usuario_id = %s AND evento_id = %s", chave)
                cur.execute("""UPDATE avisos_destinatarios SET aceito_em = COALESCE(aceito_em, CURRENT_TIMESTAMP)
                               WHERE aviso_id = %s AND usuario_id = %s""", (aviso_id, usuario_id))
            elif recusar:
                cur.execute("UPDATE avisos_eventos SET recusado_em = CURRENT_TIMESTAMP WHERE aviso_id = %s AND usuario_id = %s AND evento_id = %s", chave)
                cur.execute("""UPDATE avisos_destinatarios SET recusado_em = COALESCE(recusado_em, CURRENT_TIMESTAMP)
                               WHERE aviso_id = %s AND usuario_id = %s""", (aviso_id, usuario_id))
            return True


def acompanhamento_avisos(aviso_id=None, assunto="", periodo_inicio=None, periodo_fim=None):
    with conexao() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT aviso_id FROM ambiente_avisos WHERE ambiente_id = %s FOR UPDATE", (contexto_ambiente() or INICIAL,))
            ativo_id = cur.fetchone()["aviso_id"]
            cur.execute("SELECT id, assunto, texto, publicado_em FROM avisos_publicacoes WHERE ambiente_id = %s ORDER BY publicado_em DESC, id DESC", (contexto_ambiente() or INICIAL,))
            publicacoes = cur.fetchall()
            if assunto:
                termo = assunto.strip().casefold()
                publicacoes = [p for p in publicacoes if termo in p["assunto"].casefold()]
            ids = {p["id"] for p in publicacoes}
            # Ao filtrar, uma selecao anterior fora do resultado nao bloqueia a consulta.
            if assunto and aviso_id not in ids:
                aviso_id = None
            escolhido = aviso_id or (ativo_id if ativo_id in ids else None) or (publicacoes[0]["id"] if publicacoes else None)
            publicacao = next((p for p in publicacoes if p["id"] == escolhido), None)
            registros = []
            if publicacao:
                filtros = ["aviso_id = %s"]
                parametros = [escolhido]
                coluna_periodo = "COALESCE(visualizado_em, aceito_em, recusado_em)"
                if periodo_inicio:
                    filtros.append(f"{coluna_periodo} >= %s")
                    parametros.append(periodo_inicio)
                if periodo_fim:
                    filtros.append(f"{coluna_periodo} < %s")
                    parametros.append(periodo_fim + timedelta(days=1))
                consulta = (
                    "SELECT * FROM avisos_eventos WHERE "
                    + " AND ".join(filtros)
                    + " ORDER BY visualizado_em DESC, evento_id DESC, usuario_id"
                )
                cur.execute(consulta, parametros)
                registros = cur.fetchall()
            return publicacoes, publicacao, registros, ativo_id


def acompanhamento_avisos_todos(assunto="", periodo_inicio=None, periodo_fim=None,
                                aviso_id=None, ambiente_ids=None):
    """Retorna o acompanhamento consolidado de todos os ambientes.

    A tela de Avisos do Master pode permanecer visível sem escolher um
    ambiente específico. Cada evento continua vinculado à sua publicação e
    a publicação ao ambiente de origem, portanto a consulta não mistura
    aceites entre contextos e também preserva o histórico de ambientes que
    já ficaram inativos ou tiveram o aviso retirado.
    """
    with conexao() as conn, conn.cursor() as cur:
        consulta = """
            SELECT a.id AS ambiente_id, a.nome AS ambiente_nome, a.ativo AS ambiente_ativo,
                   p.id AS aviso_id, p.assunto, p.texto, p.publicado_em,
                   e.evento_id, e.usuario_id, e.nome, e.usuario, e.papel,
                   e.visualizado_em, e.aceito_em, e.recusado_em
            FROM avisos_eventos e
            JOIN avisos_publicacoes p ON p.id = e.aviso_id
            JOIN ambientes a ON a.id = p.ambiente_id
        """
        filtros = []
        parametros = []
        coluna_periodo = "COALESCE(e.visualizado_em, e.aceito_em, e.recusado_em)"
        if periodo_inicio:
            filtros.append(f"{coluna_periodo} >= %s")
            parametros.append(periodo_inicio)
        if periodo_fim:
            filtros.append(f"{coluna_periodo} < %s")
            parametros.append(periodo_fim + timedelta(days=1))
        if aviso_id:
            filtros.append("p.id = %s")
            parametros.append(aviso_id)
        ids = _normalizar_ids_ambientes(ambiente_ids)
        if ids is not None:
            if not ids:
                filtros.append("1 = 0")
            else:
                filtros.append("p.ambiente_id IN (" + ",".join(["%s"] * len(ids)) + ")")
                parametros.extend(ids)
        if filtros:
            consulta += " WHERE " + " AND ".join(filtros)
        consulta += """
            ORDER BY p.publicado_em DESC, a.nome, a.id,
                     e.visualizado_em DESC, e.evento_id DESC, e.usuario_id
        """
        cur.execute(consulta, parametros)
        registros = list(cur.fetchall())
    if assunto:
        termo = assunto.strip().casefold()
        registros = [
            item for item in registros
            if termo in (item.get("assunto") or "Sem assunto").casefold()
        ]
    return registros


def resumo_avisos(ambiente_ids=None):
    """Monta os indicadores e o resumo por ambiente da guia remodelada."""
    ids = _normalizar_ids_ambientes(ambiente_ids)
    with conexao() as conn, conn.cursor() as cur:
        _encerrar_avisos_expirados(cur)
        parametros = []
        consulta_ambientes = """
            SELECT a.id AS ambiente_id, a.nome AS ambiente_nome, a.ativo AS ambiente_ativo,
                   e.aviso_id AS ativo_id, p.assunto AS ativo_assunto,
                   p.publicado_em AS ativo_publicado_em
            FROM ambientes a
            LEFT JOIN ambiente_avisos e ON e.ambiente_id = a.id
            LEFT JOIN avisos_publicacoes p ON p.id = e.aviso_id
            WHERE 1 = 1
        """
        consulta_ambientes += _filtro_ids_ambientes("a.id", ids, parametros)
        consulta_ambientes += " ORDER BY a.ativo DESC, a.nome, a.id"
        cur.execute(consulta_ambientes, parametros)
        ambientes = list(cur.fetchall())

        parametros = []
        consulta_totais = """
            SELECT p.ambiente_id,
                   COUNT(DISTINCT p.id) AS publicacoes,
                   COUNT(ev.evento_id) AS visualizacoes,
                   COALESCE(SUM(ev.aceito_em IS NOT NULL), 0) AS aceites,
                   COALESCE(SUM(ev.recusado_em IS NOT NULL), 0) AS recusas
            FROM avisos_publicacoes p
            LEFT JOIN avisos_eventos ev ON ev.aviso_id = p.id
            WHERE 1 = 1
        """
        consulta_totais += _filtro_ids_ambientes("p.ambiente_id", ids, parametros)
        consulta_totais += " GROUP BY p.ambiente_id"
        cur.execute(consulta_totais, parametros)
        totais_por_ambiente = {row["ambiente_id"]: row for row in cur.fetchall()}

    resultado_ambientes = []
    indicadores = {
        "ativos": 0,
        "publicacoes": 0,
        "visualizacoes": 0,
        "aceites": 0,
        "recusas": 0,
        "pendentes": 0,
    }
    for ambiente in ambientes:
        totais = totais_por_ambiente.get(ambiente["ambiente_id"], {})
        item = dict(ambiente)
        item.update({
            "publicacoes": int(totais.get("publicacoes") or 0),
            "visualizacoes": int(totais.get("visualizacoes") or 0),
            "aceites": int(totais.get("aceites") or 0),
            "recusas": int(totais.get("recusas") or 0),
        })
        item["pendentes"] = max(0, item["visualizacoes"] - item["aceites"] - item["recusas"])
        item["aviso_ativo"] = bool(item.get("ativo_id"))
        resultado_ambientes.append(item)
        indicadores["ativos"] += int(item["aviso_ativo"])
        for chave in ("publicacoes", "visualizacoes", "aceites", "recusas", "pendentes"):
            indicadores[chave] += item[chave]
    return {"indicadores": indicadores, "ambientes": resultado_ambientes}


def historico_avisos(assunto="", periodo_inicio=None, periodo_fim=None, ambiente_ids=None):
    """Retorna uma linha por publicação para a aba Histórico.

    O período desta consulta é aplicado à data de publicação. Os eventos
    detalhados continuam disponíveis na aba Aceites e no export correspondente.
    """
    with conexao() as conn, conn.cursor() as cur:
        _encerrar_avisos_expirados(cur)
        consulta = """
            SELECT p.id AS aviso_id, p.ambiente_id, a.nome AS ambiente_nome,
                   a.ativo AS ambiente_ativo, p.assunto, p.texto, p.publicado_em,
                   COALESCE(p.inicio_em, p.publicado_em) AS inicio_em,
                   COALESCE(p.expira_em, DATE_ADD(p.publicado_em, INTERVAL 24 HOUR)) AS expira_em,
                   COALESCE(NULLIF(p.publicado_por_nome, ''), u.nome, 'Não informado') AS responsavel,
                   CASE WHEN estado.aviso_id IS NULL THEN 0 ELSE 1 END AS aviso_ativo,
                   COUNT(ev.evento_id) AS visualizacoes,
                   COALESCE(SUM(ev.aceito_em IS NOT NULL), 0) AS aceites,
                   COALESCE(SUM(ev.recusado_em IS NOT NULL), 0) AS recusas,
                   MAX(GREATEST(ev.visualizado_em,
                                COALESCE(ev.aceito_em, ev.visualizado_em),
                                COALESCE(ev.recusado_em, ev.visualizado_em))) AS ultimo_evento
            FROM avisos_publicacoes p
            JOIN ambientes a ON a.id = p.ambiente_id
            LEFT JOIN usuarios u ON u.id = p.publicado_por
            LEFT JOIN ambiente_avisos estado
                   ON estado.ambiente_id = p.ambiente_id AND estado.aviso_id = p.id
            LEFT JOIN avisos_eventos ev ON ev.aviso_id = p.id
            WHERE 1 = 1
        """
        parametros = []
        consulta += _filtro_ids_ambientes("p.ambiente_id", ambiente_ids, parametros)
        if assunto:
            consulta += " AND LOWER(p.assunto) LIKE LOWER(%s)"
            parametros.append("%" + assunto.strip() + "%")
        if periodo_inicio:
            consulta += " AND p.publicado_em >= %s"
            parametros.append(periodo_inicio)
        if periodo_fim:
            consulta += " AND p.publicado_em < %s"
            parametros.append(periodo_fim + timedelta(days=1))
        consulta += """
            GROUP BY p.id, p.ambiente_id, a.id, a.nome, a.ativo,
                     p.assunto, p.texto, p.publicado_em, p.inicio_em, p.expira_em, p.publicado_por_nome,
                     u.nome, estado.aviso_id
            ORDER BY p.publicado_em DESC, p.id DESC
        """
        cur.execute(consulta, parametros)
        registros = list(cur.fetchall())
    for item in registros:
        item["duracao"] = _duracao_aviso_texto(item["inicio_em"], item["expira_em"])
        item["visualizacoes"] = int(item.get("visualizacoes") or 0)
        item["aceites"] = int(item.get("aceites") or 0)
        item["recusas"] = int(item.get("recusas") or 0)
        item["pendentes"] = max(0, item["visualizacoes"] - item["aceites"] - item["recusas"])
        item["aviso_ativo"] = bool(item.get("aviso_ativo"))
    return registros


def criar_master_local(nome, login, senha_hash, email):
    """Provisionamento local exclusivo. Nunca chamado por uma rota HTTP."""
    from cadastro_usuarios import validar_email
    email = validar_email(email, obrigatorio=True)
    with conexao() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT usuario_id FROM portal_master_controle WHERE id = 1 FOR UPDATE")
            cur.execute("SELECT id FROM usuarios WHERE papel = 'master'")
            if cur.fetchone():
                raise ValueError("Já existe uma conta Master. Nenhuma conta foi alterada.")
            cur.execute("SELECT id FROM usuarios WHERE LOWER(usuario) = LOWER(%s)", (login,))
            if cur.fetchone():
                raise ValueError("Esse login já existe. Escolha um login exclusivo para o Master.")
            cur.execute("SELECT id FROM usuarios WHERE LOWER(email) = LOWER(%s)", (email,))
            if cur.fetchone():
                raise ValueError("Esse e-mail já está associado a outro usuário.")
            uid = uuid.uuid4().hex
            cur.execute("""INSERT INTO usuarios (id, nome, usuario, email, senha_hash, papel, troca_senha_obrigatoria)
                           VALUES (%s, %s, %s, %s, %s, 'master', 0)""", (uid, nome, login, email, senha_hash))
            cur.execute("UPDATE portal_master_controle SET usuario_id = %s WHERE id = 1", (uid,))
    _cache_clear("_usuarios_cache")
    return uid


def salvar_guias_usuario(ator_id, usuario_id, guias):
    """A identidade Master e conferida novamente dentro da transacao."""
    from permissoes_guias import IDS_GUIAS
    if not isinstance(guias, list) or not all(isinstance(g, str) and g in IDS_GUIAS for g in guias):
        raise ValueError("Guia inválida.")
    with conexao() as conn:
        with conn.cursor() as cur:
            cur.execute("SELECT usuario_id FROM portal_master_controle WHERE id = 1 FOR UPDATE")
            cur.execute("SELECT papel FROM usuarios WHERE id = %s", (ator_id,))
            ator = cur.fetchone()
            if not ator or ator["papel"] != "master":
                raise PermissionError("Somente o Master pode alterar as guias.")
            cur.execute("SELECT papel FROM usuarios WHERE id = %s", (usuario_id,))
            alvo = cur.fetchone()
            if not alvo or alvo["papel"] == "master":
                raise ValueError("As guias da conta Master são fixas.")
            cur.execute("DELETE FROM usuario_guias WHERE usuario_id = %s", (usuario_id,))
            cur.execute("INSERT INTO usuario_guias (usuario_id, guias_json) VALUES (%s, %s)",
                        (usuario_id, json.dumps(sorted(set(guias)))))
    _cache_clear("_usuarios_cache")
