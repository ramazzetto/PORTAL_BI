from pathlib import Path



# -*- coding: utf-8 -*-

"""

ETL PONTO MAIS -> ft_ponto_shope_validacao

VERSÃO DE VALIDAÇÃO + ENRIQUECIMENTO DIRETO VIA ft_controle_shopee

"""



# =====================================================================================

# CONTROLE DO REPROCESSAMENTO

#

# MODO_EXECUCAO = "AUTO"

# - Modo normal de produção.

# - Se a tabela ft_ponto_shope estiver vazia, o script faz BOOTSTRAP completo

#   desde DATA_INICIAL_BOOTSTRAP até a data atual.

# - Se a tabela já tiver dados, o script reprocessa automaticamente apenas

#   o mês atual e o mês anterior.

#

# MODO_EXECUCAO = "REBUILD_FROM"

# - Usar quando for necessário reprocessar tudo novamente ou reconstruir a base-

#   a partir de uma competência específica.

# - Nesse modo, o script apaga da ft_ponto_shope todos os registros cuja

#   CompetenciaRaw seja maior ou igual à competência informada em

#   REBUILD_FROM_COMPETENCIA, e depois recria tudo dali em diante.

#

# EXEMPLOS:

# - REBUILD_FROM_COMPETENCIA = "202601"

#   => reprocessa tudo desde janeiro/2026 até hoje.

#

# - REBUILD_FROM_COMPETENCIA = "202603"

#   => reprocessa tudo desde março/2026 até hoje.

#

# COMO REPROCESSAR TUDO:

# 1) alterar MODO_EXECUCAO para "REBUILD_FROM"

# 2) definir REBUILD_FROM_COMPETENCIA = "202601"

# 3) executar o script

# 4) após finalizar, voltar MODO_EXECUCAO para "AUTO"

#

# IMPORTANTE:

# - Não deixar "REBUILD_FROM" fixo em produção.

# - Após o reprocessamento completo, o correto é voltar para "AUTO", para que

#   as próximas execuções sigam apenas a regra normal de mês atual + mês anterior.

# =====================================================================================



import hashlib

import os

import re

import smtplib

import time

import traceback

import unicodedata

from calendar import monthrange

from datetime import date, datetime, timedelta

from email.message import EmailMessage

from typing import Any, Dict, List, Tuple



import mysql.connector

from mysql.connector import errors as mysql_errors

import requests



PROCESSO = "FT_PONTO_SHOPEE_FALTAS_VALIDACAO"

# Esta cópia é exclusiva para validação. Ela grava somente nas tabelas com
# sufixo _validacao e não utiliza as tabelas de produção como destino.
#
# REBUILD_FROM é usado por padrão para que a primeira execução não dependa da
# regra de bootstrap da tabela vazia. Altere a competência abaixo conforme o
# período que deseja validar, por exemplo: "202601".
MODO_EXECUCAO = "REBUILD_FROM"  # REBUILD_FROM ou AUTO



DATA_INICIAL_BOOTSTRAP = "2026-01-01"

REBUILD_FROM_COMPETENCIA = "202601"



BASE_URL = "https://api.pontomais.com.br/external_api/v1"

# Credencial da API usada na validação.
ACCESS_TOKEN = "$2a$12$1oIPGXy1eV0W.33stZ4vgOlslwrqOIOEJ.kX.fA6QE8L.k69Aosii"



FILTRO_CENTRO = "SHOPEE"



INCLUIR_COLABORADORES_INATIVOS = True

INCLUIR_COLABORADORES_QUE_NAO_REGISTRAM_PONTO = False

EXCLUIR_REGISTROS_SEM_MATRICULA = False



CONNECT_TIMEOUT = 20

READ_TIMEOUT = 180

REQUEST_RETRIES = 2

REQUEST_RETRY_SLEEP = 3



API_WINDOW_DAYS = 1



# Senha do MySQL usada na validação.
MYSQL_PASSWORD = "0P_SH)077&_)(*&¨%"



MYSQL_CFG = {

    "host": "gnxgroup.tech",

    "port": 3306,

    "user": "gnxtech_op_shopee",

    "password": MYSQL_PASSWORD,

    "database": "gnxtech_processos_op_shopee",

    "autocommit": False,

    "connection_timeout": 60,

}

BATCH_INSERT_SIZE = 4000



# Tabelas de produção, mantidas somente como referência de segurança.
PRODUCTION_FT_TABLE = "ft_ponto_shope"
PRODUCTION_CTL_TABLE = "ctl_ft_ponto_shope_carga"

# Tabelas exclusivas desta cópia de validação.
VALIDATION_FT_TABLE = "ft_ponto_shope_validacao"
VALIDATION_CTL_TABLE = "ctl_ft_ponto_shope_carga_validacao"

FT_TABLE = VALIDATION_FT_TABLE
CTL_TABLE = VALIDATION_CTL_TABLE

# A tabela de controle original é apenas lida para o enriquecimento.
CONTROLE_TABLE = "ft_controle_shopee"



SMTP_HOST = "smtp.office365.com"

SMTP_PORT = 587

EMAIL_SENDER = "tecnologia@gnxgroup.com.br"

EMAIL_APP_PASSWORD = os.getenv("PONTO_MAIS_SMTP_APP_PASSWORD", "")

EMAIL_TO = [

    "aslan.araujo@gnxgroup.com.br",

    "felipy.pinheiro@gnxgroup.com.br",

    "anderson.silva@gnxgroup.com.br",

    "jardel.braz@gnxgroup.com.br",

    "jeziel.mendes@gnxgroup.com.br",

    "pedro.garcia@gnxgroup.com.br",

]

SEND_EMAIL_ON_SUCCESS = False

SEND_EMAIL_ON_ERROR = False

SUBJECT_PREFIX = "[SYNC API P+ SHOPEE]"



BASE_DIR = os.path.dirname(os.path.abspath(__file__))

LOG_DIR = os.path.join(BASE_DIR, "logs")

LOG_FILE = os.path.join(LOG_DIR, "sync_api_pmais_shopee_validacao.log")



MOTIVOS_ABONO_JUSTIFICADO = {

    "BAIXA VOLUMETRIA", "COMPENSA BANCO", "DSR SEMANAL", "FOLGA",

    "FOLGA COMPENSATORIA", "FOLGA DSR", "ONBOARDING", "TREINAMENTO",

    "INTEGRACAO", "ABONO RESCISAO", "DESLIGAMENTO",

    "PARALISACAO HUB (PROBLEMAS ESTRUTURAIS)", "DESCANSO INTERJORNADA", "ABONO",

}



MAPA_DIA_SEMANA = {

    0: "SEGUNDA-FEIRA",

    1: "TERÇA-FEIRA",

    2: "QUARTA-FEIRA",

    3: "QUINTA-FEIRA",

    4: "SEXTA-FEIRA",

    5: "SÁBADO",

    6: "DOMINGO",

}



MAPA_MES = {

    1: "JANEIRO", 2: "FEVEREIRO", 3: "MARÇO", 4: "ABRIL",

    5: "MAIO", 6: "JUNHO", 7: "JULHO", 8: "AGOSTO",

    9: "SETEMBRO", 10: "OUTUBRO", 11: "NOVEMBRO", 12: "DEZEMBRO",

}



STAGES: List[str] = []

LOG_BUFFER: List[str] = []

LOG_BUFFER_MAX = 1200

RUN_START = datetime.now()

LAST_STAGE = "Início"



DDL_FT = f"""

CREATE TABLE IF NOT EXISTS `{FT_TABLE}` (

    `id` BIGINT NOT NULL AUTO_INCREMENT,

    `Matricula` VARCHAR(30) NULL,

    `Nome` VARCHAR(255) NOT NULL,

    `Cargo` VARCHAR(255) NULL,

    `Equipe` VARCHAR(255) NULL,

    `Data` VARCHAR(20) NOT NULL,

    `Abono` VARCHAR(10) NULL,

    `Motivo` VARCHAR(255) NULL,

    `Eh_folga` VARCHAR(10) NULL,

    `CONCATENAR` VARCHAR(350) NULL,

    `VALIDADOR` VARCHAR(40) NULL,

    `FALTA_OK` INT NOT NULL DEFAULT 0,

    `ABONO_OK` INT NOT NULL DEFAULT 0,

    `PRESENCA_OK` INT NOT NULL DEFAULT 0,

    `ABONO_JUSTIFICADO_OK` INT NOT NULL DEFAULT 0,

    `MOTIVO_AJUSTADO` VARCHAR(255) NULL,

    `RESUMO_DO_MOTIVO` VARCHAR(255) NULL,

    `Atestado_Medico` VARCHAR(50) NULL,

    `DIA_DA_SEMANA` VARCHAR(20) NULL,

    `Mes_Texto` VARCHAR(20) NULL,

    `POR_SEMANA` VARCHAR(10) NULL,

    `Mes` TINYINT NOT NULL,

    `Ano` SMALLINT NOT NULL,

    `cost_center_id` BIGINT NULL,

    `cost_center_name` VARCHAR(255) NULL,

    `DataISO` DATE NOT NULL,

    `CompetenciaRaw` CHAR(6) NOT NULL,

    `Competencia` CHAR(7) NOT NULL,

    `SITUACAO` VARCHAR(100) NULL,

    `DATA_ADMISSAO` DATE NULL,

    `SEXO` VARCHAR(50) NULL,

    `IDADE` VARCHAR(50) NULL,

    `ESTADO_CIVIL` VARCHAR(100) NULL,

    `TEMPO_DE_CASA` VARCHAR(100) NULL,

    `SIGLA_LOCAL` VARCHAR(100) NULL,

    `LOCAL_DE_TRABALHO` VARCHAR(255) NULL,

    `TIPO_DE_CONTRATO` VARCHAR(100) NULL,

    `ON_SITE` VARCHAR(255) NULL,

    `HORARIO` VARCHAR(100) NULL,

    `REGIONAL` VARCHAR(100) NULL,

    `OPERACAO` VARCHAR(100) NULL,

    `UF_DE_PARA` VARCHAR(50) NULL,

    `dt_enriquecimento` DATETIME NULL,

    `OrigemRelatorio` VARCHAR(50) NOT NULL DEFAULT 'work_days+missing_days+controle',

    `dt_upload` DATETIME NOT NULL,

    `dt_processamento` DATETIME NOT NULL,

    `lote_carga` VARCHAR(30) NOT NULL,

    `dt_carga` DATETIME NOT NULL,

    `HashLinha` CHAR(32) NOT NULL,

    PRIMARY KEY (`id`),

    UNIQUE KEY `uq_ft_ponto_shope_hash` (`HashLinha`),

    KEY `idx_ft_ponto_shope_comp_raw` (`CompetenciaRaw`),

    KEY `idx_ft_ponto_shope_dataiso` (`DataISO`),

    KEY `idx_ft_ponto_shope_matricula_data` (`Matricula`, `DataISO`),

    KEY `idx_ft_ponto_shope_cc` (`cost_center_id`)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

"""



DDL_CTL = f"""

CREATE TABLE IF NOT EXISTS `{CTL_TABLE}` (

    `id` BIGINT NOT NULL AUTO_INCREMENT,

    `processo` VARCHAR(100) NOT NULL,

    `competencia` CHAR(6) NOT NULL,

    `status_carga` VARCHAR(30) NOT NULL,

    `modo_execucao` VARCHAR(30) NOT NULL,

    `periodo_inicio` DATE NOT NULL,

    `periodo_fim` DATE NOT NULL,

    `linhas_inseridas` BIGINT NOT NULL DEFAULT 0,

    `dt_inicio` DATETIME NOT NULL,

    `dt_fim` DATETIME NULL,

    `observacao` VARCHAR(500) NULL,

    PRIMARY KEY (`id`),

    UNIQUE KEY `uq_ctl_ft_ponto_shope_comp` (`processo`, `competencia`, `periodo_inicio`, `periodo_fim`),

    KEY `idx_ctl_ft_ponto_shope_status` (`status_carga`),

    KEY `idx_ctl_ft_ponto_shope_comp` (`competencia`)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

"""



INSERT_SQL = f"""

INSERT INTO `{FT_TABLE}` (

    `Matricula`, `Nome`, `Cargo`, `Equipe`, `Data`, `Abono`, `Motivo`, `Eh_folga`,

    `CONCATENAR`, `VALIDADOR`, `FALTA_OK`, `ABONO_OK`, `PRESENCA_OK`, `ABONO_JUSTIFICADO_OK`,

    `MOTIVO_AJUSTADO`, `RESUMO_DO_MOTIVO`, `Atestado_Medico`, `DIA_DA_SEMANA`, `Mes_Texto`,

    `POR_SEMANA`, `Mes`, `Ano`,

    `cost_center_id`, `cost_center_name`,

    `DataISO`, `CompetenciaRaw`, `Competencia`,

    `SITUACAO`, `DATA_ADMISSAO`, `SEXO`, `IDADE`, `ESTADO_CIVIL`, `TEMPO_DE_CASA`, `SIGLA_LOCAL`,

    `LOCAL_DE_TRABALHO`, `TIPO_DE_CONTRATO`, `ON_SITE`, `HORARIO`, `REGIONAL`, `OPERACAO`,

    `UF_DE_PARA`, `dt_enriquecimento`,

    `OrigemRelatorio`, `dt_upload`, `dt_processamento`, `lote_carga`, `dt_carga`, `HashLinha`

) VALUES (

    %s, %s, %s, %s, %s, %s, %s, %s,

    %s, %s, %s, %s, %s, %s,

    %s, %s, %s, %s, %s,

    %s, %s, %s,

    %s, %s,

    %s, %s, %s,

    %s, %s, %s, %s, %s, %s, %s,

    %s, %s, %s, %s, %s, %s,

    %s, %s,

    %s, %s, %s, %s, %s, %s

)

"""



def _escape_html(s: str) -> str:

    return (s or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")



def human_duration(seconds: float) -> str:

    total = int(seconds)

    h = total // 3600

    m = (total % 3600) // 60

    s = total % 60

    if h > 0:

        return f"{h}h {m}m {s}s"

    if m > 0:

        return f"{m}m {s}s"

    return f"{s}s"



def stage(msg: str, icon: str = "✅") -> None:

    global LAST_STAGE

    LAST_STAGE = msg

    STAGES.append(f"{icon} {msg}")



def log(msg: str) -> None:

    line = f"[{datetime.now().strftime('%d/%m/%Y %H:%M:%S')}] {msg}"

    print(line, flush=True)

    LOG_BUFFER.append(line)

    if len(LOG_BUFFER) > LOG_BUFFER_MAX:

        del LOG_BUFFER[: len(LOG_BUFFER) - LOG_BUFFER_MAX]

    try:

        os.makedirs(LOG_DIR, exist_ok=True)

        with open(LOG_FILE, "a", encoding="utf-8") as f:

            f.write(line + "\n")

    except Exception:

        pass



def progress_bar(current: int, total: int, width: int = 30) -> str:

    if total <= 0:

        total = 1

    ratio = max(0.0, min(1.0, current / total))

    filled = int(width * ratio)

    empty = width - filled

    return f"[{'█' * filled}{'░' * empty}] {ratio * 100:6.2f}% ({current}/{total})"



def send_email(subject: str, text_body: str, html_body: str, to_list: List[str], attach_log: bool = True):

    msg = EmailMessage()

    msg["From"] = EMAIL_SENDER

    msg["To"] = ", ".join(to_list)

    msg["Subject"] = subject

    msg.set_content(text_body)

    msg.add_alternative(html_body, subtype="html")

    if attach_log:

        try:

            if os.path.exists(LOG_FILE):

                with open(LOG_FILE, "r", encoding="utf-8", errors="ignore") as f:

                    content = f.read()

            else:

                content = "\n".join(LOG_BUFFER[-300:])

            msg.add_attachment(

                content.encode("utf-8", errors="ignore"),

                maintype="text",

                subtype="plain",

                filename=os.path.basename(LOG_FILE),

            )

        except Exception:

            pass

    with smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=60) as smtp:

        smtp.ehlo()

        smtp.starttls()

        smtp.ehlo()

        smtp.login(EMAIL_SENDER, EMAIL_APP_PASSWORD)

        smtp.send_message(msg)



def build_email_bodies(status_label: str, summary: Dict[str, str], error_short: str = "", traceback_text: str = "") -> Tuple[str, str]:

    end = datetime.now()

    dur = human_duration((end - RUN_START).total_seconds())

    lines: List[str] = [

        f"Status: {status_label}",

        f"Início: {RUN_START:%d/%m/%Y %H:%M:%S}",

        f"Fim:    {end:%d/%m/%Y %H:%M:%S}",

        f"Duração: {dur}",

        "",

        "Resumo:",

    ]

    for k, v in summary.items():

        lines.append(f"- {k}: {v}")

    if error_short:

        lines += ["", f"Erro: {error_short}", f"Última etapa: {LAST_STAGE}"]

    lines += ["", "Etapas:"]

    for s in STAGES:

        lines.append(f"- {s}")

    lines += ["", "Log (últimas linhas):"]

    lines.extend(LOG_BUFFER[-120:])

    if traceback_text:

        lines += ["", "Traceback:", traceback_text]

    text_body = "\n".join(lines)

    html_body = f"<html><body><pre>{_escape_html(text_body)}</pre></body></html>"

    return text_body, html_body



def headers_json() -> Dict[str, str]:

    return {"Content-Type": "application/json", "access-token": ACCESS_TOKEN}



def montar_row_filters() -> str:

    filtros: List[str] = []

    if INCLUIR_COLABORADORES_INATIVOS:

        filtros.append("with_inactives")

    if INCLUIR_COLABORADORES_QUE_NAO_REGISTRAM_PONTO:

        filtros.append("has_time_cards")

    return ",".join(filtros)



def request_api_json(method: str, endpoint: str, **kwargs) -> Dict[str, Any]:

    url = f"{BASE_URL}{endpoint}"

    last_err = None

    for attempt in range(1, REQUEST_RETRIES + 1):

        try:

            resp = requests.request(method, url, timeout=(CONNECT_TIMEOUT, READ_TIMEOUT), **kwargs)

            try:

                body = resp.json()

            except Exception:

                body = {"raw_text": resp.text}

            return {"url": url, "status_code": resp.status_code, "headers": dict(resp.headers), "body": body}

        except requests.exceptions.ReadTimeout as e:

            last_err = e

            log(f"Timeout na API em {endpoint} | tentativa {attempt}/{REQUEST_RETRIES}")

            if attempt < REQUEST_RETRIES:

                time.sleep(REQUEST_RETRY_SLEEP)

        except requests.exceptions.RequestException as e:

            last_err = e

            log(f"Erro request em {endpoint} | tentativa {attempt}/{REQUEST_RETRIES} | {e}")

            if attempt < REQUEST_RETRIES:

                time.sleep(REQUEST_RETRY_SLEEP)

    raise last_err



def month_first_day(dt: date) -> date:

    return dt.replace(day=1)



def month_last_day(dt: date) -> date:

    return dt.replace(day=monthrange(dt.year, dt.month)[1])



def previous_month_first_day(dt: date) -> date:

    first = month_first_day(dt)

    prev_last = first - timedelta(days=1)

    return prev_last.replace(day=1)



def competencia_to_periodo(competencia: str) -> Tuple[date, date]:

    ano = int(competencia[:4])

    mes = int(competencia[4:6])

    dt_ini = date(ano, mes, 1)

    dt_fim = month_last_day(dt_ini)

    return dt_ini, dt_fim



def listar_competencias_entre(dt_ini: date, dt_fim: date) -> List[str]:

    comps = []

    cursor = date(dt_ini.year, dt_ini.month, 1)

    end_ref = date(dt_fim.year, dt_fim.month, 1)

    while cursor <= end_ref:

        comps.append(cursor.strftime("%Y%m"))

        if cursor.month == 12:

            cursor = date(cursor.year + 1, 1, 1)

        else:

            cursor = date(cursor.year, cursor.month + 1, 1)

    return comps



def gerar_janelas_datas(dt_ini: date, dt_fim: date, dias_janela: int) -> List[Tuple[date, date]]:

    janelas = []

    cursor = dt_ini

    while cursor <= dt_fim:

        fim_janela = min(cursor + timedelta(days=dias_janela - 1), dt_fim)

        janelas.append((cursor, fim_janela))

        cursor = fim_janela + timedelta(days=1)

    return janelas



def parse_data_api(texto: Any) -> Tuple[str, date, str, str, int, int]:

    txt = str(texto or "").strip()

    m = re.search(r"(\d{2})/(\d{2})/(\d{4})", txt)

    if not m:

        raise ValueError(f"Data inválida no retorno da API: {txt}")

    dia = int(m.group(1))

    mes = int(m.group(2))

    ano = int(m.group(3))

    data_iso = date(ano, mes, dia)

    competencia_raw = f"{ano:04d}{mes:02d}"

    competencia = f"{mes:02d}/{ano:04d}"

    return txt, data_iso, competencia_raw, competencia, ano, mes



def normalizar_texto(valor: Any) -> str:

    txt = "" if valor is None else str(valor)

    txt = txt.replace("\xa0", " ")

    txt = re.sub(r"\s+", " ", txt).strip()

    return txt



def remover_acentos(txt: str) -> str:

    return "".join(c for c in unicodedata.normalize("NFKD", txt) if not unicodedata.combining(c))



def normalizar_chave(txt: Any) -> str:

    s = normalizar_texto(txt).upper()

    s = remover_acentos(s)

    s = re.sub(r"\s+", " ", s).strip()

    return s



def title_case_texto(txt: Any) -> str:

    s = normalizar_texto(txt)

    return s.title() if s else ""



def nome_upper(valor: Any) -> str:

    return normalizar_texto(valor).upper()



def calcular_eh_folga(abono: str, motivo: str) -> str:

    ab = normalizar_texto(abono).upper()

    mt = normalizar_chave(motivo)

    if not ab and not mt:

        return ""

    if "FOLGA" in mt or "DSR" in mt:

        return "Sim"

    if ab == "NÃO":

        return "Não"

    if ab == "SIM":

        return "Não"

    return ""



def classificar_validador(abono: str, motivo: str) -> str:

    ab = normalizar_texto(abono)

    motivo_norm = normalizar_chave(motivo)

    if ab == "Sim":

        return "ABONO JUSTIFICADO" if motivo_norm in MOTIVOS_ABONO_JUSTIFICADO else "ABONO"

    if ab == "Não":

        return "FALTA"

    return "PRESENÇA"



def motivo_ajustado(abono: str, motivo: str, validador: str) -> str:

    mot = normalizar_texto(motivo)

    if mot:

        return title_case_texto(mot)

    return {

        "FALTA": "Falta",

        "PRESENÇA": "Presença",

        "ABONO": "Abono",

        "ABONO JUSTIFICADO": "Abono Justificado",

    }.get(validador, "")



def resumo_motivo(motivo_adj: str, validador: str) -> str:

    if motivo_adj:

        return motivo_adj

    return {

        "PRESENÇA": "Presença",

        "FALTA": "Falta",

        "ABONO": "Abono",

        "ABONO JUSTIFICADO": "Abono Justificado",

    }.get(validador, "")



def por_semana_excel(data_iso: date) -> str:

    return f"W{int(data_iso.strftime('%U')) + 1:02d}"



def hash_row(values: List[Any]) -> str:

    txt = "¦".join("" if v is None else str(v) for v in values)

    return hashlib.md5(txt.encode("utf-8")).hexdigest()



def matricula_key(v: Any) -> str:

    return normalizar_texto(v)



def data_key(v: Any) -> str:

    txt, *_ = parse_data_api(v)

    return txt



def connect_mysql():

    return mysql.connector.connect(**MYSQL_CFG)



def validar_isolamento_validacao() -> None:

    """Impede que esta cópia seja executada apontando para produção."""

    if FT_TABLE != VALIDATION_FT_TABLE:

        raise RuntimeError(
            f"Tabela FT inválida para validação: {FT_TABLE}. "
            f"Esperado: {VALIDATION_FT_TABLE}."
        )

    if CTL_TABLE != VALIDATION_CTL_TABLE:

        raise RuntimeError(
            f"Tabela de controle inválida para validação: {CTL_TABLE}. "
            f"Esperado: {VALIDATION_CTL_TABLE}."
        )

    if FT_TABLE in {PRODUCTION_FT_TABLE, PRODUCTION_CTL_TABLE}:

        raise RuntimeError(
            "A tabela de destino da validação aponta para uma tabela de produção."
        )

    if CTL_TABLE in {PRODUCTION_FT_TABLE, PRODUCTION_CTL_TABLE}:

        raise RuntimeError(
            "A tabela de controle da validação aponta para uma tabela de produção."
        )

    if CONTROLE_TABLE in {FT_TABLE, CTL_TABLE}:

        raise RuntimeError(
            "A tabela auxiliar de controle não pode ser igual a uma tabela de destino."
        )


def ensure_tables(cur) -> None:

    cur.execute(DDL_FT)

    cur.execute(DDL_CTL)



def tabela_ft_vazia(cur) -> bool:

    cur.execute(f"SELECT COUNT(*) FROM `{FT_TABLE}`")

    total = cur.fetchone()[0]

    return int(total or 0) == 0



def definir_janela_execucao_auto(cur) -> Tuple[str, date, date, List[str]]:

    hoje = date.today()

    if MODO_EXECUCAO == "REBUILD_FROM":

        dt_ini, _ = competencia_to_periodo(REBUILD_FROM_COMPETENCIA)

        dt_fim = hoje

        modo_efetivo = "REBUILD_FROM"

    else:

        if tabela_ft_vazia(cur):

            dt_ini = datetime.strptime(DATA_INICIAL_BOOTSTRAP, "%Y-%m-%d").date()

            dt_fim = hoje

            modo_efetivo = "BOOTSTRAP"

        else:

            dt_ini = previous_month_first_day(hoje)

            dt_fim = hoje

            modo_efetivo = "JANELA_MOVEL"

    competencias = listar_competencias_entre(dt_ini, dt_fim)

    return modo_efetivo, dt_ini, dt_fim, competencias



def upsert_ctl(cur, competencia: str, periodo_inicio: date, periodo_fim: date, status_carga: str, modo_execucao: str, linhas_inseridas: int, dt_inicio: datetime, dt_fim: datetime | None, observacao: str | None) -> None:

    sql = f"""

    INSERT INTO `{CTL_TABLE}` (

        `processo`, `competencia`, `status_carga`, `modo_execucao`,

        `periodo_inicio`, `periodo_fim`, `linhas_inseridas`,

        `dt_inicio`, `dt_fim`, `observacao`

    ) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)

    ON DUPLICATE KEY UPDATE

        `status_carga` = VALUES(`status_carga`),

        `modo_execucao` = VALUES(`modo_execucao`),

        `linhas_inseridas` = VALUES(`linhas_inseridas`),

        `dt_inicio` = VALUES(`dt_inicio`),

        `dt_fim` = VALUES(`dt_fim`),

        `observacao` = VALUES(`observacao`)

    """

    cur.execute(

        sql,

        (

            PROCESSO,

            competencia,

            status_carga,

            modo_execucao,

            periodo_inicio,

            periodo_fim,

            linhas_inseridas,

            dt_inicio,

            dt_fim,

            observacao,

        ),

    )



def gravar_ctl_inicio(cur, conn, competencias: List[str], dt_ini: date, dt_fim: date, modo_efetivo: str, dt_inicio_exec: datetime) -> None:

    for comp in competencias:

        comp_ini, comp_fim = competencia_to_periodo(comp)

        upsert_ctl(

            cur,

            comp,

            max(comp_ini, dt_ini),

            min(comp_fim, dt_fim),

            "EM_PROCESSAMENTO",

            modo_efetivo,

            0,

            dt_inicio_exec,

            None,

            "Execução iniciada",

        )

    conn.commit()



def atualizar_ctl_progresso(cur, conn, competencias: List[str], dt_ini: date, dt_fim: date, modo_efetivo: str, dt_inicio_exec: datetime, linhas_inseridas: int, observacao: str) -> None:

    for comp in competencias:

        comp_ini, comp_fim = competencia_to_periodo(comp)

        upsert_ctl(

            cur,

            comp,

            max(comp_ini, dt_ini),

            min(comp_fim, dt_fim),

            "EM_PROCESSAMENTO",

            modo_efetivo,

            linhas_inseridas,

            dt_inicio_exec,

            None,

            observacao[:500],

        )

    conn.commit()



def purge_competencias(cur, competencias: List[str]) -> None:

    if not competencias:

        return

    placeholders = ", ".join(["%s"] * len(competencias))

    cur.execute(f"DELETE FROM `{FT_TABLE}` WHERE `CompetenciaRaw` IN ({placeholders})", competencias)



def purge_from_competencia(cur, competencia_inicial: str) -> None:

    cur.execute(f"DELETE FROM `{FT_TABLE}` WHERE `CompetenciaRaw` >= %s", (competencia_inicial,))

    cur.execute(f"DELETE FROM `{CTL_TABLE}` WHERE `processo` = %s AND `competencia` >= %s", (PROCESSO, competencia_inicial))



def flush_batch_to_mysql(cur, conn, batch: List[Tuple[Any, ...]], batch_label: str) -> int:

    if not batch:

        return 0

    try:

        cur.executemany(INSERT_SQL, batch)

        conn.commit()

        inseridos = cur.rowcount if cur.rowcount is not None and cur.rowcount >= 0 else len(batch)

    except mysql_errors.IntegrityError:

        insert_ignore_sql = INSERT_SQL.replace("INSERT INTO", "INSERT IGNORE INTO", 1)

        cur.executemany(insert_ignore_sql, batch)

        conn.commit()

        inseridos = cur.rowcount if cur.rowcount is not None and cur.rowcount >= 0 else 0

    log(f"    -> lote gravado [{batch_label}] | tamanho={len(batch)} | inseridos={inseridos}")

    return inseridos



def parse_data_controle(valor: Any):

    if valor is None:

        return None

    if isinstance(valor, date):

        return valor

    txt = normalizar_texto(valor)

    if not txt:

        return None

    for fmt in ("%d/%m/%Y", "%Y-%m-%d", "%d-%m-%Y"):

        try:

            return datetime.strptime(txt, fmt).date()

        except ValueError:

            pass

    return None



def load_controle_lookup(cur) -> Dict[str, Dict[str, Any]]:

    sql = f"""

    SELECT

        x.`codigo`, x.`nome`, x.`situacao`, x.`data_de_admissao`, x.`sexo`,

        x.`idade_de_para`, x.`estado_civil`, x.`intervalo_de_tempo_de_contrato`, x.`codigo_do_hub_soc`,

        x.`local_de_trabalho_2`, x.`vinculo_de_para`, x.`on_site_responsavel`,

        x.`horario_de_para`, x.`regional`, x.`operacao`, x.`uf_de_para`

    FROM `{CONTROLE_TABLE}` x

    INNER JOIN (

        SELECT MAX(`id`) AS max_id

        FROM `{CONTROLE_TABLE}`

        GROUP BY CONCAT(TRIM(COALESCE(`codigo`, '')), UPPER(TRIM(COALESCE(`nome`, ''))))

    ) m ON m.max_id = x.id

    """

    cur.execute(sql)

    rows = cur.fetchall()

    lookup: Dict[str, Dict[str, Any]] = {}

    for row in rows:

        (

            codigo, nome, situacao, data_de_admissao, sexo, idade_de_para, estado_civil,

            intervalo_de_tempo_de_contrato, codigo_do_hub_soc, local_de_trabalho_2,

            vinculo_de_para, on_site_responsavel, horario_de_para, regional,

            operacao, uf_de_para,

        ) = row

        key = f"{normalizar_texto(codigo)}{nome_upper(nome)}"

        lookup[key] = {

            "SITUACAO": normalizar_texto(situacao),

            "DATA_ADMISSAO": parse_data_controle(data_de_admissao),

            "SEXO": normalizar_texto(sexo),

            "IDADE": normalizar_texto(idade_de_para),

            "ESTADO_CIVIL": normalizar_texto(estado_civil),

            "TEMPO_DE_CASA": normalizar_texto(intervalo_de_tempo_de_contrato),

            "SIGLA_LOCAL": normalizar_texto(codigo_do_hub_soc),

            "LOCAL_DE_TRABALHO": normalizar_texto(local_de_trabalho_2),

            "TIPO_DE_CONTRATO": normalizar_texto(vinculo_de_para),

            "ON_SITE": normalizar_texto(on_site_responsavel),

            "HORARIO": normalizar_texto(horario_de_para),

            "REGIONAL": normalizar_texto(regional),

            "OPERACAO": normalizar_texto(operacao),

            "UF_DE_PARA": normalizar_texto(uf_de_para),

        }

    return lookup



def listar_centros() -> List[Dict[str, Any]]:

    resp = request_api_json("GET", "/cost_centers", headers=headers_json())

    if resp["status_code"] >= 400:

        raise RuntimeError(f"Erro ao consultar cost_centers: HTTP {resp['status_code']} | {resp['body']}")

    body = resp["body"]

    if isinstance(body, dict) and isinstance(body.get("cost_centers"), list):

        return body["cost_centers"]

    if isinstance(body, list):

        return body

    return []



def filtrar_centros(centros: List[Dict[str, Any]], termo: str) -> List[Dict[str, Any]]:

    termo = (termo or "").strip().upper()

    return [c for c in centros if termo in str(c.get("name") or "").upper() or termo in str(c.get("code") or "").upper()]



def body_work_days(cost_center_id: int, dt_ini: date, dt_fim: date) -> Dict[str, Any]:

    return {

        "report": {

            "start_date": dt_ini.strftime("%Y-%m-%d"),

            "end_date": dt_fim.strftime("%Y-%m-%d"),

            "group_by": "employee",

            "row_filters": montar_row_filters(),

            "columns": "date,registration_number,employee_name,job_title_name,team_name",

            "format": "json",

            "cost_center_id": int(cost_center_id),

        }

    }



def body_missing_days(cost_center_id: int, dt_ini: date, dt_fim: date) -> Dict[str, Any]:

    return {

        "report": {

            "start_date": dt_ini.strftime("%Y-%m-%d"),

            "end_date": dt_fim.strftime("%Y-%m-%d"),

            "group_by": "employee",

            "row_filters": montar_row_filters(),

            "columns": "name,registration_number,job_title,team,shift,date,missing_type,missing_motive",

            "format": "json",

            "cost_center_id": int(cost_center_id),

        }

    }



def _flatten_blocks(payload: Dict[str, Any]) -> List[Dict[str, Any]]:

    linhas_finais: List[Dict[str, Any]] = []

    data_outer = payload.get("data", [])

    if not isinstance(data_outer, list):

        return linhas_finais

    for camada1 in data_outer:

        if not isinstance(camada1, list):

            continue

        for bloco in camada1:

            if not isinstance(bloco, dict):

                continue

            linhas = bloco.get("data", [])

            if not isinstance(linhas, list):

                continue

            for linha in linhas:

                if isinstance(linha, dict):

                    linhas_finais.append(linha)

    return linhas_finais



def extrair_work_days(payload: Dict[str, Any]) -> List[Dict[str, Any]]:

    rows = []

    for linha in _flatten_blocks(payload):

        rows.append(

            {

                "registration_number": linha.get("registration_number") or linha.get("employee_registration_number"),

                "name": linha.get("employee_name") or linha.get("name"),

                "job_title": linha.get("job_title_name") or linha.get("job_title"),

                "team": linha.get("team_name") or linha.get("team"),

                "date": linha.get("date"),

            }

        )

    return rows



def extrair_missing_days(payload: Dict[str, Any]) -> List[Dict[str, Any]]:

    rows = []

    for linha in _flatten_blocks(payload):

        rows.append(

            {

                "registration_number": linha.get("registration_number"),

                "date": linha.get("date"),

                "missing_type": linha.get("missing_type"),

                "missing_motive": linha.get("missing_motive"),

            }

        )

    return rows



def consultar_work_days_uma_janela(cost_center_id: int, cost_center_name: str, dt_ini: date, dt_fim: date) -> List[Dict[str, Any]]:

    resp = request_api_json("POST", "/reports/work_days", headers=headers_json(), json=body_work_days(cost_center_id, dt_ini, dt_fim))

    if resp["status_code"] >= 400:

        raise RuntimeError(

            f"Erro ao consultar work_days para centro {cost_center_id} - {cost_center_name}: "

            f"HTTP {resp['status_code']} | {resp['body']}"

        )

    return extrair_work_days(resp.get("body", {}))



def consultar_missing_days_uma_janela(cost_center_id: int, cost_center_name: str, dt_ini: date, dt_fim: date) -> List[Dict[str, Any]]:

    resp = request_api_json("POST", "/reports/missing_days", headers=headers_json(), json=body_missing_days(cost_center_id, dt_ini, dt_fim))

    if resp["status_code"] >= 400:

        raise RuntimeError(

            f"Erro ao consultar missing_days para centro {cost_center_id} - {cost_center_name}: "

            f"HTTP {resp['status_code']} | {resp['body']}"

        )

    return extrair_missing_days(resp.get("body", {}))



def combinar_diario(work_rows: List[Dict[str, Any]], missing_rows: List[Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], int]:

    missing_map: Dict[Tuple[str, str], Dict[str, Any]] = {}

    for m in missing_rows:

        reg = matricula_key(m.get("registration_number"))

        if EXCLUIR_REGISTROS_SEM_MATRICULA and not reg:

            continue

        key = (reg, data_key(m.get("date")))

        missing_map[key] = m

    saida: List[Dict[str, Any]] = []

    removidos_sem_matricula = 0

    for w in work_rows:

        reg = matricula_key(w.get("registration_number"))

        if EXCLUIR_REGISTROS_SEM_MATRICULA and not reg:

            removidos_sem_matricula += 1

            continue

        key = (reg, data_key(w.get("date")))

        miss = missing_map.get(key, {})

        saida.append(

            {

                "registration_number": w.get("registration_number"),

                "name": w.get("name"),

                "job_title": w.get("job_title"),

                "team": w.get("team"),

                "date": w.get("date"),

                "missing_type": miss.get("missing_type", ""),

                "missing_motive": miss.get("missing_motive", ""),

            }

        )

    return saida, removidos_sem_matricula



def transformar_rows(rows: List[Dict[str, Any]], controle_lookup: Dict[str, Dict[str, Any]], cost_center_id: int, cost_center_name: str, lote_carga: str, now_dt: datetime) -> Tuple[List[Tuple[Any, ...]], int, int]:

    saida: List[Tuple[Any, ...]] = []

    match_ctrl = 0

    sem_match = 0

    for row in rows:

        data_txt, data_iso, competencia_raw, competencia, ano, mes = parse_data_api(row.get("date"))

        matricula = normalizar_texto(row.get("registration_number"))

        nome = nome_upper(row.get("name"))

        cargo = normalizar_texto(row.get("job_title"))

        equipe = normalizar_texto(row.get("team"))

        abono = normalizar_texto(row.get("missing_type"))

        motivo = normalizar_texto(row.get("missing_motive"))

        eh_folga = calcular_eh_folga(abono, motivo)

        concatenar = f"{matricula}{nome}"

        ctrl = controle_lookup.get(concatenar, {})

        if ctrl:

            match_ctrl += 1

        else:

            sem_match += 1



        validador = classificar_validador(abono, motivo)

        falta_ok = 1 if validador == "FALTA" else 0

        abono_ok = 1 if validador == "ABONO" else 0

        presenca_ok = 1 if validador == "PRESENÇA" else 0

        abono_just_ok = 1 if validador == "ABONO JUSTIFICADO" else 0

        mot_ajustado = motivo_ajustado(abono, motivo, validador)

        resumo_do_motivo = resumo_motivo(mot_ajustado, validador)

        atestado_medico = "Atestado Médico" if normalizar_chave(mot_ajustado) == "ATESTADO MEDICO" else ""



        dia_semana = MAPA_DIA_SEMANA[data_iso.weekday()]

        mes_texto = MAPA_MES[data_iso.month]

        por_semana = por_semana_excel(data_iso)



        situacao = ctrl.get("SITUACAO")

        data_admissao = ctrl.get("DATA_ADMISSAO")

        sexo = ctrl.get("SEXO")

        idade = ctrl.get("IDADE")

        estado_civil = ctrl.get("ESTADO_CIVIL")

        tempo_de_casa = ctrl.get("TEMPO_DE_CASA")

        sigla_local = ctrl.get("SIGLA_LOCAL")

        local_de_trabalho = ctrl.get("LOCAL_DE_TRABALHO")

        tipo_de_contrato = ctrl.get("TIPO_DE_CONTRATO")

        on_site = ctrl.get("ON_SITE")

        horario = ctrl.get("HORARIO")

        regional = ctrl.get("REGIONAL")

        operacao = ctrl.get("OPERACAO")

        uf_de_para = ctrl.get("UF_DE_PARA")

        dt_enriquecimento = now_dt if ctrl else None



        hash_linha = hash_row(

            [

                matricula, nome, cargo, equipe, data_txt, abono, motivo, eh_folga,

                concatenar, validador, falta_ok, abono_ok, presenca_ok, abono_just_ok,

                mot_ajustado, resumo_do_motivo, atestado_medico, dia_semana, mes_texto,

                por_semana, cost_center_id, cost_center_name, competencia_raw,

                situacao, data_admissao, sexo, idade, estado_civil, tempo_de_casa, sigla_local,

                local_de_trabalho, tipo_de_contrato, on_site, horario, regional,

                operacao, uf_de_para,

            ]

        )



        saida.append(

            (

                matricula, nome, cargo, equipe, data_txt, abono, motivo, eh_folga,

                concatenar, validador, falta_ok, abono_ok, presenca_ok, abono_just_ok,

                mot_ajustado, resumo_do_motivo, atestado_medico, dia_semana, mes_texto,

                por_semana, mes, ano, cost_center_id, cost_center_name,

                data_iso, competencia_raw, competencia,

                situacao, data_admissao, sexo, idade, estado_civil, tempo_de_casa, sigla_local,

                local_de_trabalho, tipo_de_contrato, on_site, horario, regional, operacao,

                uf_de_para, dt_enriquecimento,

                "work_days+missing_days+controle", now_dt, now_dt, lote_carga, now_dt, hash_linha,

            )

        )

    return saida, match_ctrl, sem_match



def main():

    global RUN_START

    RUN_START = datetime.now()

    STAGES.clear()

    LOG_BUFFER.clear()

    validar_isolamento_validacao()



    if not ACCESS_TOKEN:

        raise RuntimeError(
            "Informe o token na variável PONTOMAIS_ACCESS_TOKEN antes de executar."
        )

    if not MYSQL_PASSWORD:

        raise RuntimeError(
            "Informe a senha do MySQL na variável PONTO_MAIS_MYSQL_PASSWORD."
        )



    os.makedirs(LOG_DIR, exist_ok=True)

    with open(LOG_FILE, "w", encoding="utf-8") as f:

        f.write("")



    stage("Início da execução", "✅")

    dt_inicio_exec = datetime.now()

    lote_carga = dt_inicio_exec.strftime("%Y%m%d%H%M%S")



    conn = None

    cur = None



    total_work = total_missing = total_transformado = total_inserido = 0

    total_removidos_sem_matricula = total_match_controle = total_sem_match_controle = 0



    competencias_janela: List[str] = []

    dt_ini = None

    dt_fim = None

    modo_efetivo = None



    try:

        conn = connect_mysql()

        cur = conn.cursor()



        stage("Conectado no MySQL", "✅")

        log("Conectado no MySQL")



        ensure_tables(cur)

        conn.commit()



        stage("Estrutura garantida", "✅")

        log("Estrutura garantida")



        modo_efetivo, dt_ini, dt_fim, competencias_janela = definir_janela_execucao_auto(cur)

        janelas_api = gerar_janelas_datas(dt_ini, dt_fim, API_WINDOW_DAYS)



        gravar_ctl_inicio(cur, conn, competencias_janela, dt_ini, dt_fim, modo_efetivo, dt_inicio_exec)



        log("=" * 100)

        log(f"Processo: {PROCESSO}")
        log(f"Banco: {MYSQL_CFG['database']}")
        log(f"Tabela destino de validação: {FT_TABLE}")
        log(f"Tabela controle de validação: {CTL_TABLE}")
        log(f"Tabela auxiliar consultada: {CONTROLE_TABLE}")

        log(f"Modo configurado: {MODO_EXECUCAO}")

        log(f"Modo efetivo: {modo_efetivo}")

        log(f"Período geral: {dt_ini} até {dt_fim}")

        log(f"Competências: {', '.join(competencias_janela)}")

        log(f"Janelas API (dias): {len(janelas_api)}")

        log(f"Filtro centro: {FILTRO_CENTRO}")

        log(f"Row filters API: {montar_row_filters() or '(vazio)'}")

        log(f"Excluir sem matrícula: {EXCLUIR_REGISTROS_SEM_MATRICULA}")

        log(f"Lote insert MySQL: {BATCH_INSERT_SIZE}")

        log("=" * 100)



        if modo_efetivo == "REBUILD_FROM":

            log(f"Removendo dados a partir da competência {REBUILD_FROM_COMPETENCIA}")

            purge_from_competencia(cur, REBUILD_FROM_COMPETENCIA)

        else:

            log(f"Removendo dados das competências: {', '.join(competencias_janela)}")

            purge_competencias(cur, competencias_janela)

        conn.commit()



        stage("Limpeza concluída", "✅")

        log("Limpeza concluída")



        stage("Carregando base de apoio ft_controle_shopee", "✅")

        controle_lookup = load_controle_lookup(cur)

        log(f"Base de apoio carregada: {len(controle_lookup)} chaves CONCATENAR")



        centros = listar_centros()

        centros_filtrados = filtrar_centros(centros, FILTRO_CENTRO)

        if not centros_filtrados:

            raise RuntimeError(f"Nenhum centro de custo encontrado contendo '{FILTRO_CENTRO}'.")



        stage(f"Centros filtrados: {len(centros_filtrados)}", "✅")

        log(f"Centros filtrados: {len(centros_filtrados)}")



        total_janelas = len(janelas_api) * len(centros_filtrados)

        janela_global = 0

        batch_mysql: List[Tuple[Any, ...]] = []



        for idx_centro, centro in enumerate(centros_filtrados, start=1):

            cost_center_id = int(centro.get("id"))

            cost_center_name = str(centro.get("name") or "")



            log("-" * 100)

            log(f"Centro {idx_centro}/{len(centros_filtrados)} -> {cost_center_id} - {cost_center_name}")



            for idx_janela, (jan_ini, jan_fim) in enumerate(janelas_api, start=1):

                janela_global += 1

                barra = progress_bar(janela_global, total_janelas)

                log(f"{barra} | janela {idx_janela}/{len(janelas_api)} | período {jan_ini} até {jan_fim}")



                work_rows = consultar_work_days_uma_janela(cost_center_id, cost_center_name, jan_ini, jan_fim)

                missing_rows = consultar_missing_days_uma_janela(cost_center_id, cost_center_name, jan_ini, jan_fim)



                total_work += len(work_rows)

                total_missing += len(missing_rows)



                combinados, removidos_sem_matricula = combinar_diario(work_rows, missing_rows)

                total_removidos_sem_matricula += removidos_sem_matricula



                registros, match_ctrl, sem_match_ctrl = transformar_rows(

                    combinados,

                    controle_lookup,

                    cost_center_id,

                    cost_center_name,

                    lote_carga,

                    dt_inicio_exec,

                )



                total_match_controle += match_ctrl

                total_sem_match_controle += sem_match_ctrl

                total_transformado += len(registros)

                batch_mysql.extend(registros)



                log(

                    f"   work_days={len(work_rows)} | missing_days={len(missing_rows)} | "

                    f"removidos_sem_matricula={removidos_sem_matricula} | match_controle={match_ctrl} | "

                    f"sem_match_controle={sem_match_ctrl} | transformado_total={total_transformado} | "

                    f"buffer_mysql={len(batch_mysql)}"

                )



                while len(batch_mysql) >= BATCH_INSERT_SIZE:

                    lote = batch_mysql[:BATCH_INSERT_SIZE]

                    label = f"cc={cost_center_id}|{jan_ini}"

                    inseridos = flush_batch_to_mysql(cur, conn, lote, label)

                    total_inserido += inseridos

                    batch_mysql = batch_mysql[BATCH_INSERT_SIZE:]

                    log(f"   total inserido até agora: {total_inserido}")



                atualizar_ctl_progresso(

                    cur,

                    conn,

                    competencias_janela,

                    dt_ini,

                    dt_fim,

                    modo_efetivo,

                    dt_inicio_exec,

                    total_inserido,

                    (

                        f"Janela {janela_global}/{total_janelas} | work={total_work} | missing={total_missing} | "

                        f"sem_matricula={total_removidos_sem_matricula} | match_controle={total_match_controle} | "

                        f"sem_match_controle={total_sem_match_controle} | inserido={total_inserido}"

                    ),

                )



            log(

                f"Fim do centro {cost_center_id} | work_total={total_work} | missing_total={total_missing} | "

                f"removidos_sem_matricula={total_removidos_sem_matricula} | match_controle={total_match_controle} | "

                f"sem_match_controle={total_sem_match_controle} | inserido_total={total_inserido}"

            )



        if batch_mysql:

            log(f"Flush final do restante em memória: {len(batch_mysql)}")

            inseridos = flush_batch_to_mysql(cur, conn, batch_mysql, "flush_final")

            total_inserido += inseridos

            batch_mysql = []



        if total_transformado == 0:

            raise RuntimeError("Nenhuma linha foi transformada para inserção.")



        for comp in competencias_janela:

            comp_ini, comp_fim = competencia_to_periodo(comp)

            upsert_ctl(

                cur,

                comp,

                max(comp_ini, dt_ini),

                min(comp_fim, dt_fim),

                "SUCESSO",

                modo_efetivo,

                total_inserido,

                dt_inicio_exec,

                datetime.now(),

                (

                    f"Lote {lote_carga} | work={total_work} | missing={total_missing} | "

                    f"sem_matricula={total_removidos_sem_matricula} | match_controle={total_match_controle} | "

                    f"sem_match_controle={total_sem_match_controle} | transformado={total_transformado} | "

                    f"inserido={total_inserido}"

                ),

            )



        conn.commit()



        summary = {

            "Processo": PROCESSO,

            "Modo efetivo": modo_efetivo,

            "Período": f"{dt_ini} até {dt_fim}",

            "Competências": ", ".join(competencias_janela),

            "Linhas work_days": str(total_work),

            "Linhas missing_days": str(total_missing),

            "Linhas removidas sem matrícula": str(total_removidos_sem_matricula),

            "Match controle": str(total_match_controle),

            "Sem match controle": str(total_sem_match_controle),

            "Linhas transformadas": str(total_transformado),

            "Linhas inseridas": str(total_inserido),

            "Lote carga": lote_carga,

        }



        stage("Finalizado com sucesso", "✅")

        log("=" * 100)

        log("FINALIZADO COM SUCESSO")

        log(f"Linhas work_days: {total_work}")

        log(f"Linhas missing_days: {total_missing}")

        log(f"Linhas removidas sem matrícula: {total_removidos_sem_matricula}")

        log(f"Match controle: {total_match_controle}")

        log(f"Sem match controle: {total_sem_match_controle}")

        log(f"Linhas transformadas: {total_transformado}")

        log(f"Linhas inseridas: {total_inserido}")

        log(f"Lote carga: {lote_carga}")

        log("=" * 100)



        if SEND_EMAIL_ON_SUCCESS:

            subject = f"{SUBJECT_PREFIX} ✅ SUCESSO - {datetime.now():%d/%m/%Y %H:%M}"

            text_body, html_body = build_email_bodies("SUCESSO", summary)

            send_email(subject, text_body, html_body, EMAIL_TO, attach_log=True)



    except Exception as e:

        if conn:

            conn.rollback()



        dt_fim_erro = datetime.now()

        try:

            if cur and competencias_janela:

                for comp in competencias_janela:

                    comp_ini, comp_fim = competencia_to_periodo(comp)

                    upsert_ctl(

                        cur,

                        comp,

                        max(comp_ini, dt_ini),

                        min(comp_fim, dt_fim),

                        "ERRO",

                        modo_efetivo or MODO_EXECUCAO,

                        0,

                        dt_inicio_exec,

                        dt_fim_erro,

                        str(e)[:500],

                    )

                conn.commit()

        except Exception:

            pass



        stage("Falha na execução", "❌")

        log("ERRO NA EXECUÇÃO")

        log(str(e))

        tb = traceback.format_exc()

        log(tb)



        summary = {

            "Processo": PROCESSO,

            "Modo efetivo": str(modo_efetivo or MODO_EXECUCAO),

            "Período": f"{dt_ini} até {dt_fim}",

            "Competências": ", ".join(competencias_janela),

            "Linhas work_days": str(total_work),

            "Linhas missing_days": str(total_missing),

            "Linhas removidas sem matrícula": str(total_removidos_sem_matricula),

            "Match controle": str(total_match_controle),

            "Sem match controle": str(total_sem_match_controle),

            "Linhas transformadas": str(total_transformado),

            "Linhas inseridas": str(total_inserido),

            "Lote carga": lote_carga,

        }



        if SEND_EMAIL_ON_ERROR:

            try:

                subject = f"{SUBJECT_PREFIX} ❌ ERRO - {datetime.now():%d/%m/%Y %H:%M}"

                text_body, html_body = build_email_bodies(

                    "ERRO",

                    summary,

                    error_short=f"{type(e).__name__}: {e}",

                    traceback_text=tb,

                )

                send_email(subject, text_body, html_body, EMAIL_TO, attach_log=True)

            except Exception as mail_ex:

                log(f"Falha ao enviar e-mail de erro: {type(mail_ex).__name__}: {mail_ex}")

        raise



    finally:

        try:

            if cur:

                cur.close()

        except Exception:

            pass

        try:

            if conn:

                conn.close()

        except Exception:

            pass



if __name__ == "__main__":

    main()
