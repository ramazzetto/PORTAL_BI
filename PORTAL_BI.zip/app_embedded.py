"""
Portal de Dashboards Power BI — modelo "App owns data" (Power BI Embedded)
--------------------------------------------------------------------------
O SERVIDOR se autentica no Power BI com um service principal (Azure AD),
gera um EMBED TOKEN temporário e o entrega ao front. O visualizador:
  - NÃO precisa de licença Power BI Pro
  - NÃO precisa de conta Microsoft
  - NUNCA recebe uma URL pública

Isso atende internos E externos pela mesma arquitetura.

------------------------------------------------------------------
PRÉ-REQUISITOS (feitos uma vez, no ambiente da empresa):
1. Capacidade Fabric (F-SKU, ex.: F2) atribuída ao workspace.
2. Registro de aplicativo no Azure AD (Entra ID) => gera:
     TENANT_ID, CLIENT_ID, CLIENT_SECRET
3. Criar um grupo de segurança no Entra, colocar o app nele, e habilitar
   no admin portal do Power BI:
     "Service principals can use Fabric APIs" (para esse grupo).
4. Adicionar o service principal como Membro/Admin do workspace.
5. Publicar os relatórios nesse workspace (com a conta Pro).
6. Anotar WORKSPACE_ID (groupId) e o report_id de cada relatório.
------------------------------------------------------------------

Instale: pip install flask msal requests
Config via variáveis de ambiente (não deixe segredos no código):
  export TENANT_ID=...
  export CLIENT_ID=...
  export CLIENT_SECRET=...
  export PBI_WORKSPACE_ID=...
  export SECRET_KEY=...
"""

import os
from functools import wraps
import requests
import msal
from flask import (
    Flask, render_template, request, redirect,
    url_for, session, abort, flash, jsonify
)

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "troque-esta-chave-em-producao")

# ---------------------------------------------------------------------------
# Config do Azure AD / Power BI (venha por variável de ambiente!)
# ---------------------------------------------------------------------------
TENANT_ID = os.environ.get("TENANT_ID", "")
CLIENT_ID = os.environ.get("CLIENT_ID", "")
CLIENT_SECRET = os.environ.get("CLIENT_SECRET", "")
WORKSPACE_ID = os.environ.get("PBI_WORKSPACE_ID", "")

AUTHORITY = f"https://login.microsoftonline.com/{TENANT_ID}"
SCOPE = ["https://analysis.windows.net/powerbi/api/.default"]
PBI_API = "https://api.powerbi.com/v1.0/myorg"

# ---------------------------------------------------------------------------
# Usuários do portal (exemplo). Troque por SSO/banco com hash em produção.
# ---------------------------------------------------------------------------
USERS = {
    "admin": "senha123",
    "cliente_externo": "acesso@2026",
}

# ---------------------------------------------------------------------------
# Dashboards. Agora usamos report_id (do workspace), não URL pública.
# "rls_roles" (opcional): papéis de Row-Level Security a aplicar para
# este usuário/relatório — essencial para clientes externos verem só o
# que é deles.
# ---------------------------------------------------------------------------
DASHBOARDS = [
    {
        "id": "vendas",
        "nome": "Vendas",
        "descricao": "Faturamento, metas e ranking de produtos.",
        "categoria": "Comercial",
        "report_id": "COLE_O_REPORT_ID_AQUI",
    },
    {
        "id": "financeiro",
        "nome": "Financeiro",
        "descricao": "Fluxo de caixa, DRE e contas.",
        "categoria": "Financeiro",
        "report_id": "COLE_O_REPORT_ID_AQUI",
    },
]


def get_dashboard(dash_id):
    return next((d for d in DASHBOARDS if d["id"] == dash_id), None)


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("user"):
            return redirect(url_for("login", next=request.path))
        return view(*args, **kwargs)
    return wrapped


# ---------------------------------------------------------------------------
# Autenticação no Power BI (service principal / client credentials)
# ---------------------------------------------------------------------------
def get_aad_token():
    msal_app = msal.ConfidentialClientApplication(
        CLIENT_ID, authority=AUTHORITY, client_credential=CLIENT_SECRET
    )
    result = msal_app.acquire_token_for_client(scopes=SCOPE)
    if "access_token" not in result:
        raise RuntimeError(
            f"Falha ao autenticar no Azure AD: {result.get('error_description')}"
        )
    return result["access_token"]


def pbi_headers():
    return {
        "Authorization": f"Bearer {get_aad_token()}",
        "Content-Type": "application/json",
    }


def get_report_info(report_id):
    """Busca embedUrl e datasetId do relatório."""
    url = f"{PBI_API}/groups/{WORKSPACE_ID}/reports/{report_id}"
    r = requests.get(url, headers=pbi_headers(), timeout=30)
    r.raise_for_status()
    data = r.json()
    return {"embed_url": data["embedUrl"], "dataset_id": data["datasetId"]}


def generate_embed_token(report_id, dataset_id, rls=None):
    """
    Gera embed token. Se 'rls' for informado, aplica Row-Level Security
    (username + roles) — indispensável para isolar dados de clientes externos.
    """
    url = f"{PBI_API}/GenerateToken"
    body = {
        "reports": [{"id": report_id}],
        "datasets": [{"id": dataset_id}],
        "targetWorkspaces": [{"id": WORKSPACE_ID}],
    }
    if rls:
        body["identities"] = [{
            "username": rls["username"],
            "roles": rls["roles"],
            "datasets": [dataset_id],
        }]
    r = requests.post(url, headers=pbi_headers(), json=body, timeout=30)
    r.raise_for_status()
    return r.json()["token"]


# ---------------------------------------------------------------------------
# Rotas
# ---------------------------------------------------------------------------
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        usuario = request.form.get("usuario", "").strip()
        senha = request.form.get("senha", "")
        if USERS.get(usuario) == senha:
            session["user"] = usuario
            return redirect(request.args.get("next") or url_for("index"))
        flash("Usuário ou senha inválidos.", "erro")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/")
@login_required
def index():
    return render_template("index.html", dashboards=DASHBOARDS, usuario=session["user"])


@app.route("/dashboard/<dash_id>")
@login_required
def dashboard(dash_id):
    dash = get_dashboard(dash_id)
    if not dash:
        abort(404)
    return render_template("embed.html", dash=dash, usuario=session["user"])


@app.route("/api/embed-token/<dash_id>")
@login_required
def embed_token(dash_id):
    """Endpoint chamado pelo front (powerbi-client) para renderizar o relatório."""
    dash = get_dashboard(dash_id)
    if not dash:
        abort(404)
    try:
        info = get_report_info(dash["report_id"])
        # Exemplo de RLS por usuário — ajuste conforme sua modelagem.
        # rls = {"username": session["user"], "roles": ["ClienteExterno"]}
        rls = None
        token = generate_embed_token(dash["report_id"], info["dataset_id"], rls=rls)
        return jsonify({
            "reportId": dash["report_id"],
            "embedUrl": info["embed_url"],
            "accessToken": token,
        })
    except Exception as e:
        return jsonify({"erro": str(e)}), 500


if __name__ == "__main__":
    app.run(debug=True, port=5000)
