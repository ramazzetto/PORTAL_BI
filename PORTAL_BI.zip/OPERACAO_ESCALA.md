# Operação e escala do Portal BI

## Antes de publicar

1. Configure o banco remoto no `.env`; não há alteração de código entre banco
   local e servidor. Use um usuário MySQL exclusivo do Portal BI e conexão TLS
   quando o banco não estiver na mesma máquina.
2. Mantenha `PORTAL_THREADS` e `DB_POOL_MAX_CONEXOES` compatíveis. Cada
   processo pode abrir no máximo o tamanho do pool; a soma dos processos deve
   permanecer abaixo de `max_connections` do MySQL/MariaDB, reservando espaço
   para backup e administração.
3. Em mais de um processo, configure `RATE_LIMIT_STORAGE_URI` com Redis. A
   sessão de autenticação já é assinada e funciona entre processos desde que a
   `SECRET_KEY` seja a mesma.
4. Configure HTTPS, `HTTPS_ATIVO=true`, `PROXY_CONFIAVEL=true` e
   `FLASK_DEBUG=false`.

## Monitoramento

- Monitore `GET /saude` pelo proxy ou por rede interna.
- Acompanhe logs do Waitress/Apache, respostas 429/5xx e consultas lentas do
  MySQL. Investigue consultas lentas antes de criar novos índices.
- Acompanhe conexões abertas, uso de CPU/RAM e espaço em disco do banco.

## Backup e retenção

- Faça backup diário com `mysqldump` ou a rotina corporativa e teste a
  restauração em outro banco periodicamente.
- Os históricos de acessos e avisos crescem continuamente. Defina com a área
  responsável o prazo de retenção antes de arquivar ou excluir qualquer dado.

## Teste de carga

Execute primeiro em ambiente de homologação com dados anonimizados. Comece com
login, abertura de dashboards, filtros de acessos e gravação de permissões.
Eleve a concorrência gradualmente, registre tempo p95 e erros, e só então
ajuste `PORTAL_THREADS`, o pool e `max_connections`. Não execute teste de
carga no banco local usado para trabalho diário.
