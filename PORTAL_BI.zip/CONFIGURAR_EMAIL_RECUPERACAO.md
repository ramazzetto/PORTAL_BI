# Recuperação de senha por e-mail

O Portal BI envia links de redefinição por SMTP. Antes de usar a função, edite
o arquivo `.env` do servidor (não o `.env.exemplo`) e informe os dados do seu
provedor de e-mail:

```env
# Endereço público que os usuários conseguem abrir.
# Em desenvolvimento local, use apenas para testes na mesma máquina.
PORTAL_URL=https://portal.suaempresa.com.br

SMTP_HOST=smtp.suaempresa.com.br
SMTP_PORT=587
SMTP_USUARIO=no-reply@suaempresa.com.br
SMTP_SENHA=senha-ou-app-password-do-remetente
SMTP_REMETENTE=Portal BI <no-reply@suaempresa.com.br>
SMTP_USAR_TLS=true
SMTP_USAR_SSL=false

# Validade do link (entre 5 e 120 minutos).
RECUPERACAO_SENHA_MINUTOS=30
```

Para SMTP na porta 465, normalmente use `SMTP_USAR_SSL=true` e
`SMTP_USAR_TLS=false`. Para a porta 587, use TLS como no exemplo acima.

Depois de salvar o `.env`, reinicie o Portal BI. Nunca envie esse arquivo para
o GitHub e não compartilhe a senha SMTP. Em contas Microsoft 365, Gmail ou
outro provedor com MFA, use uma senha de aplicativo quando o provedor exigir.

O e-mail é obrigatório para novos usuários. Para contas antigas sem e-mail ou
com e-mail incorreto, o **Master** deve atualizá-lo em **Administração de
Usuários**. E-mails duplicados não recebem link até que sejam corrigidos pela
administração.

Não é necessário configurar pergunta ou resposta de segurança: o Portal BI
utiliza exclusivamente o e-mail cadastrado. Ao iniciar esta versão, os campos
legados de pergunta e resposta são removidos automaticamente da tabela de
usuários.
