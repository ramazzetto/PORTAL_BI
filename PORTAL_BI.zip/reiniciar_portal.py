"""
Reinicia o Portal BI de forma rapida e completa: encerra somente os
processos Python deste projeto que possam ter sobrado rodando (a causa
mais comum de "mudei o arquivo mas nao aconteceu nada"), confirma que
realmente nao sobrou nenhum, e so entao inicia o app.py com o
interpretador correto -- sem interferir em outros projetos Python.

Uso:
    python reiniciar_portal.py

Se a pasta do seu Python for diferente da configurada abaixo, ajuste a
variavel CAMINHO_PYTHON.
"""

import os
import json
import subprocess
import sys
import time

# --- Ajuste aqui se o caminho do seu Python for diferente ---
CAMINHO_PYTHON = sys.executable

MEU_PID = os.getpid()  # para nao encerrar este proprio script sem querer
PASTA_PROJETO = os.path.dirname(os.path.abspath(__file__))
APP = os.path.join(PASTA_PROJETO, "app.py")

SERVIDOR_PRODUCAO = os.path.join(PASTA_PROJETO, "serve.py")


def listar_processos_portal():
    """Retorna apenas processos Python iniciados por este Portal BI.

    ``tasklist`` não informa a linha de comando e, por isso, não permite
    diferenciar projetos. O CIM do Windows entrega o comando completo, que
    validamos contra os caminhos absolutos de app.py e serve.py desta pasta.
    """
    comando = (
        "Get-CimInstance Win32_Process -Filter \"Name = 'python.exe' OR Name = 'pythonw.exe'\" | "
        "Select-Object ProcessId, CommandLine | ConvertTo-Json -Compress"
    )
    try:
        resultado = subprocess.run(
            ["powershell", "-NoProfile", "-Command", comando],
            capture_output=True, text=True,
        )
    except FileNotFoundError:
        print("Aviso: nao foi possivel checar processos (PowerShell nao encontrado).")
        return []
    if resultado.returncode != 0 or not resultado.stdout.strip():
        return []
    try:
        processos = json.loads(resultado.stdout)
    except json.JSONDecodeError:
        print("Aviso: nao foi possivel interpretar a lista de processos Python.")
        return []
    if isinstance(processos, dict):
        processos = [processos]
    caminhos_portal = {
        os.path.normcase(os.path.abspath(APP)),
        os.path.normcase(os.path.abspath(SERVIDOR_PRODUCAO)),
    }
    encontrados = []
    for processo in processos if isinstance(processos, list) else []:
        pid = processo.get("ProcessId")
        linha_comando = os.path.normcase(processo.get("CommandLine") or "")
        if pid != MEU_PID and any(caminho in linha_comando for caminho in caminhos_portal):
            encontrados.append(int(pid))
    return encontrados


def matar_processos_antigos():
    print("Procurando processos antigos deste Portal BI...")
    pids = listar_processos_portal()
    if not pids:
        print("Nenhum processo antigo do Portal BI encontrado. Tudo limpo.")
        return

    for pid in pids:
        print(f"  Encerrando Portal BI (PID {pid})...")
        # /T tambem encerra o filho criado pelo recarregamento automatico do Flask.
        resultado = subprocess.run(
            ["taskkill", "/PID", str(pid), "/T", "/F"],
            capture_output=True, text=True,
        )
        if resultado.returncode != 0:
            print(f"    Aviso: nao consegui encerrar o PID {pid} -> {resultado.stderr.strip()}")

    time.sleep(1.5)  # da um instante para o Windows liberar a porta 5000

    # Verificacao: confirma que realmente nao sobrou nada, tenta de novo se sobrou
    restantes = listar_processos_portal()

    if restantes:
        print(f"Ainda restaram {len(restantes)} processo(s) ({restantes}). Tentando encerrar de novo...")
        for pid in restantes:
            subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"], capture_output=True)
        time.sleep(1)
        restantes_final = listar_processos_portal()
        if restantes_final:
            print(f"AVISO: {len(restantes_final)} processo(s) continuam rodando ({restantes_final}).")
            print("Pode ser necessario encerrar manualmente pelo Gerenciador de Tarefas.")
        else:
            print("Confirmado: todos os processos antigos foram encerrados.")
    else:
        print("Confirmado: todos os processos antigos foram encerrados.")


def iniciar_servidor():
    if not os.path.exists(CAMINHO_PYTHON):
        print(f"\nERRO: nao encontrei o Python em:\n  {CAMINHO_PYTHON}")
        print("Edite a variavel CAMINHO_PYTHON no topo deste arquivo com o caminho correto.")
        sys.exit(1)

    print("\n" + "=" * 55)
    print("  Iniciando o Portal BI...")
    print("=" * 55 + "\n")
    subprocess.run([CAMINHO_PYTHON, APP], cwd=PASTA_PROJETO)


if __name__ == "__main__":
    matar_processos_antigos()
    iniciar_servidor()
