# Portal BI

Portal em Flask (Python) para organizar, proteger e exibir dashboards do
Power BI, com login, controle de acesso por pasta/dashboard, guia de
cadastro, guia de usuários e guia de auditoria de acessos (com
exportação em .xlsx).

## Armazenamento

Os dados ficam num banco **MySQL/MariaDB** (veja `db.py`). Não é mais
usado JSON como armazenamento principal.

## Rodar localmente (desenvolvimento)

1. Tenha um MySQL ou MariaDB rodando (local ou de testes) e crie o
   banco e o usuário:
   ```sql
   CREATE DATABASE portal_bi CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   CREATE USER 'portal_bi'@'localhost' IDENTIFIED BY 'sua-senha-aqui';
   GRANT ALL PRIVILEGES ON portal_bi.* TO 'portal_bi'@'localhost';
   FLUSH PRIVILEGES;
   ```
2. Copie `.env.exemplo` para `.env` e preencha com os dados reais do
   banco (host, usuário, senha) e uma `SECRET_KEY` aleatória.
3. Instale as dependências e rode:
   ```
   python -m venv venv
   venv\Scripts\activate        (Linux/Mac: source venv/bin/activate)
   pip install -r requirements.txt
   python app.py
   ```
4. Acesse http://localhost:5000 — usuário `admin`, senha `admin123`.
   **Troque essa senha assim que entrar** (Minha conta).

As tabelas são criadas automaticamente na primeira execução. Se você
já tinha usado a versão antiga (com `data.json`/`users.json`/
`acessos.json`), rode `python migrar_json_para_mysql.py` uma vez para
importar esses dados para o banco.

## Guias do portal

- **Dashboards** — o que cada usuário vê, agrupado por pasta.
- **Cadastro de Dashboard** *(admin)* — criar pastas e cadastrar dashboards.
- **Usuários** *(admin)* — criar contas, definir papel (admin/visualizador)
  e liberar pastas/dashboards específicos por pessoa.
- **Acessos** *(admin)* — histórico de quem acessou o quê e quando,
  com filtros, gráfico e exportação em .xlsx.

## Deploy em produção

Veja **`DEPLOY_APACHE_WINDOWS.md`** para o passo a passo de colocar o
portal no ar atrás do Apache, num Windows Server.

## Segurança — antes de expor na rede

- Troque a senha padrão do `admin`.
- Defina uma `SECRET_KEY` forte no `.env` (nunca deixe a do código).
- Desligue `debug=True` em `app.py` antes de ir para produção.
- Configure HTTPS no servidor (Apache).
- O `.env` nunca deve ser compartilhado nem versionado.

## Versão alternativa: Power BI Embedded

Existe também `app_embedded.py`, um modelo alternativo usando **Power BI
Embedded** (App owns data), para quando o público for majoritariamente
**externo** (sem licença Pro nem conta Microsoft). Ele não usa banco de
dados ainda — veja os comentários no próprio arquivo para os
pré-requisitos (capacidade Fabric, registro de app no Azure AD, etc.).
