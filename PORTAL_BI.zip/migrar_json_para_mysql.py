"""
Migracao unica: importa os dados dos antigos arquivos JSON
(data.json, users.json, acessos.json) para o banco MySQL/MariaDB.

So precisa rodar isso SE voce ja tinha usado a versao antiga do portal
(com arquivos JSON) e quer levar esses dados para o banco novo.
Se voce esta comecando do zero, NAO precisa rodar este script -- o
portal ja cria as tabelas e o admin padrao sozinho.

Como rodar (com as variaveis de ambiente do banco ja configuradas,
via .env ou exportadas no terminal):
  python migrar_json_para_mysql.py
"""

import os
import json

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

from db import criar_tabelas, save_data, save_users, inserir_acesso

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def _ler_json(nome_arquivo):
    caminho = os.path.join(BASE_DIR, nome_arquivo)
    if not os.path.exists(caminho):
        return None
    with open(caminho, "r", encoding="utf-8") as f:
        return json.load(f)


def main():
    print("Criando as tabelas no banco (se ainda nao existirem)...")
    criar_tabelas()

    data = _ler_json("data.json")
    if data:
        print(f"Importando {len(data.get('pastas', []))} pastas e "
              f"{len(data.get('dashboards', []))} dashboards...")
        save_data(data)
    else:
        print("Nenhum data.json encontrado -- pulando pastas/dashboards.")

    users = _ler_json("users.json")
    if users:
        print(f"Importando {len(users)} usuarios...")
        save_users(users)
    else:
        print("Nenhum users.json encontrado -- pulando usuarios.")

    acessos = _ler_json("acessos.json")
    if acessos:
        print(f"Importando {len(acessos)} registros de acesso...")
        for a in acessos:
            inserir_acesso(a)
    else:
        print("Nenhum acessos.json encontrado -- pulando historico de acessos.")

    print("Migracao concluida!")


if __name__ == "__main__":
    main()
