# Continuidade — Remodelação completa da guia Avisos

## Como usar este arquivo

Importe este arquivo no Codex junto com o pacote `Portal_BI_avisos_remodelado_v3.zip` e peça:

> Leia o arquivo de continuidade e continue a implementação no pacote indicado. Preserve as decisões aprovadas e valide a guia Avisos no projeto real antes de fazer novos ajustes.

Não voltar ao layout antigo de painel único. A remodelação abaixo é o estado aprovado e implementado.

## Projeto

Portal BI / Sirus — aplicação Flask com MySQL/MariaDB para dashboards Power BI, usuários, ambientes, permissões, acessos e avisos.

Conversas de referência:

- Conversa principal: `https://chatgpt.com/g/g-p-6a96fd3756948191a7881ebe8bbc8ab2/c/6a96fd4f-da6c-83e9-921e-87550a301042`
- Conversa compartilhada com a proposta aprovada: `https://chatgpt.com/share/6aa2f194-9b00-83e9-aae9-b778a783d1d2`

## Objetivo aprovado pelo usuário

Remodelar completamente a guia **Avisos**, mantendo as regras de segurança, o histórico persistente, a publicação para ambientes e o acompanhamento em tempo real.

A proposta aprovada possui cinco áreas:

1. **Visão geral** — indicadores e resumo dos avisos por ambiente.
2. **Novo aviso** — seleção do destino, envio global, prévia do modal e confirmação.
3. **Avisos ativos** — editar, excluir individualmente ou em massa.
4. **Aceites** — tabela consolidada com ambiente, publicação, usuário, perfil, visualização e aceite.
5. **Histórico** — publicações anteriores, responsável, status e auditoria completa.

Decisões adicionais aprovadas:

- O Master pode consultar a tabela consolidada sem selecionar/trocar ambiente.
- Administradores continuam limitados aos ambientes autorizados.
- As áreas **Aceites** e **Histórico** possuem o botão **Consultar período**.
- O botão abre um modal reutilizável com calendário e os atalhos:
  - Hoje
  - Últimos 7 dias
  - Este mês
  - Personalizado
- O período é inclusivo; a data final também entra na consulta.
- A tabela de Aceites filtra pela data/hora do evento de visualização.
- O Histórico filtra pela data de publicação.
- O histórico antigo nunca deve ser apagado ao retirar ou editar um aviso.

## Estado atual implementado

Pacote final:

- Arquivo local: `/workspace/scratch/ff2ee2b62804/Portal_BI_avisos_remodelado_v3.zip`
- O ZIP contém 17 arquivos na raiz do pacote.
- O pacote foi salvo como versão persistente do projeto.

Fonte de trabalho nesta sessão:

- `/workspace/scratch/ff2ee2b62804/portal_src`

Arquivos principais alterados:

- `aviso.html` — substituído pelo layout completo com cinco áreas, navegação por abas, prévia do modal, filtros e SSE.
- `style.css` — estilos da remodelação, cards, indicadores, tabelas, modal, responsividade e estados.
- `app.py` — dados da nova tela, filtros independentes, exportação do Histórico, integração SSE e permissões.
- `db.py` — indicadores por ambiente, histórico de publicações, responsável da publicação e migração automática.
- `permissoes_guias.py` — registro das novas rotas da guia Avisos no controle de permissões.

## Funcionalidades já implementadas

### Visão geral

- Cards de Avisos ativos, Publicações, Visualizações, Aceites e Pendentes.
- Tabela por ambiente com aviso atual, quantidade de publicações, visualizações e aceites.
- Indicadores consolidados para o Master.
- Indicadores limitados ao escopo autorizado para os demais administradores.

### Novo aviso

- Seleção do ambiente de destino para o Master.
- Opção de enviar para todos os ambientes ativos.
- Prévia visual do modal enquanto o assunto e a mensagem são digitados.
- Modal separado de prévia.
- Confirmação antes da publicação.
- Limite de 120 caracteres no assunto e 300 na mensagem.
- Edição funciona como publicação de uma nova versão, preservando os eventos da versão anterior.
- Retirada do aviso atual preserva a auditoria.

### Avisos ativos

- Cards dos avisos atualmente instalados.
- Edição individual.
- Exclusão individual.
- Exclusão em massa dos avisos ativos pelo Master.
- Ambientes inativos continuam visíveis para permitir a retirada do aviso.

### Aceites

- Tabela consolidada do Master com todos os ambientes.
- Tabela individual para o administrador no ambiente selecionado.
- Filtro por assunto.
- Filtro de período em modal com calendário.
- Atualização em tempo real por Server-Sent Events.
- Exportação XLSX.
- Filtro opcional por publicação através dos links do Histórico.

### Histórico

- Uma linha por publicação.
- Ambiente, assunto, data, responsável e status.
- Status Ativo ou Encerrado.
- Total de visualizações, aceites, recusas e pendentes.
- Último evento registrado.
- Expansão da mensagem original.
- Link para consultar os aceites da publicação.
- Link para editar uma publicação ativa.
- Filtro por assunto e período.
- Exportação XLSX própria do Histórico.

## Banco de dados

A inicialização do portal aplica migração aditiva automaticamente. Não criar script destrutivo e não apagar dados existentes.

Novas colunas adicionadas em `avisos_publicacoes`:

- `publicado_por VARCHAR(32) NULL`
- `publicado_por_nome VARCHAR(255) NULL`

Publicações novas gravam o responsável. Publicações antigas permanecem válidas e aparecem como `Não informado` quando não houver responsável registrado.

As tabelas existentes de eventos continuam sendo usadas:

- `avisos_publicacoes`
- `ambiente_avisos`
- `avisos_destinatarios`
- `avisos_eventos`

## Rotas relevantes

- `/aviso`
- `/aviso/salvar`
- `/aviso/remover`
- `/aviso/<aviso_id>/fluxo`
- `/aviso/<aviso_id>/eventos`
- `/aviso/<aviso_id>/exportar.xlsx`
- `/avisos/fluxo`
- `/avisos/exportar.xlsx`
- `/avisos/historico.xlsx`

Parâmetros de período novos:

- Aceites: `aceites_inicio` e `aceites_fim`
- Histórico: `historico_inicio` e `historico_fim`

Os parâmetros antigos `periodo_inicio` e `periodo_fim` continuam sendo aceitos para compatibilidade com links existentes.

## Decisões de segurança e comportamento

- O Master não recebe modal de aviso.
- A tabela consolidada só é disponibilizada para o Master.
- Administradores continuam sujeitos ao escopo de ambientes permitido.
- A exclusão em massa só pode ser executada pelo Master.
- O destino da publicação é validado novamente no servidor; não confiar apenas no campo HTML ou no JavaScript.
- A operação de editar não altera a publicação antiga: cria uma nova publicação para preservar auditoria.
- A data final dos filtros é tratada como inclusiva usando o limite do dia seguinte no SQL.

## Validações realizadas

Passaram:

- Compilação Python de `app.py`, `db.py`, `ambientes.py` e `permissoes_guias.py`.
- Verificação dos blocos de controle Jinja do novo `aviso.html`.
- Verificação de sintaxe dos 3 blocos JavaScript do template.
- Verificação de balanceamento das chaves CSS.
- Teste de integridade do ZIP com `unzip -t`.
- Conferência de que o pacote contém o novo template, as novas consultas, as rotas de exportação e a migração do responsável.

Limitação da sessão de edição:

- O ambiente temporário não possuía Flask/Jinja2/PyMySQL instalados, portanto não foi possível executar o portal conectado ao MySQL nem fazer uma validação visual real no navegador nesta sessão. A validação de sintaxe e estrutura foi concluída; a próxima etapa recomendada é testar no ambiente Windows do projeto.

## Próximos passos recomendados no outro Codex

1. Importar este arquivo e `Portal_BI_avisos_remodelado_v3.zip`.
2. Extrair o ZIP sobre a pasta do projeto, preservando o `.env`, banco, scripts de reinicialização e demais arquivos locais que não estejam no pacote.
3. Instalar/confirmar as dependências do projeto no ambiente Python usado pelo Portal.
4. Reiniciar o Flask; a migração aditiva das colunas do responsável ocorrerá na inicialização.
5. Limpar o cache do navegador com `Ctrl+F5`.
6. Testar com o usuário Master:
   - abrir as cinco abas;
   - publicar para um ambiente;
   - publicar para todos os ambientes ativos;
   - editar e retirar um aviso;
   - usar o filtro Hoje, Últimos 7 dias, Este mês e Personalizado;
   - consultar Aceites sem trocar o ambiente;
   - validar SSE e os dois tipos de exportação XLSX.
7. Testar com um Administrador associado a um único ambiente e a múltiplos ambientes, garantindo que ele não veja nem consiga alterar ambientes fora do escopo.
8. Se houver erro, investigar primeiro o traceback do Flask e o schema real de `avisos_publicacoes`, sem remover dados históricos.

## Instrução de continuidade

Continue a partir do pacote final. Preserve o layout das cinco abas e as regras descritas neste documento. Antes de fazer novas alterações, execute uma inspeção do projeto real e confirme se o problema observado é visual, de permissão, de sessão, de banco ou de compatibilidade com a instalação Windows.

## Convenção visual aprovada — abas do Portal BI

Para este projeto, toda nova navegação por abas deve reutilizar o padrão da guia **Acessos**: um cartão com borda e raio de 14px, espaçamento interno de 7px, itens distribuídos em colunas com intervalo de 8px, ícone e subtítulo, e estado ativo com gradiente azul translúcido, borda azul e ícone azul. Deve haver um respiro vertical de 18px entre as abas e os demais cartões de conteúdo. Não utilizar o antigo grupo compacto de botões para novas abas.

### Cores dos estados primários

O amarelo não é mais a cor primária do Portal BI. Em ambos os temas, botões, abas e itens selecionados usam azul translúcido em gradiente:

- Tema dark: gradiente azul mais profundo e translúcido (`rgba(24, 74, 162, .68)` → `rgba(31, 95, 202, .44)` → `rgba(76, 157, 255, .23)`).
- Tema light: gradiente azul translúcido mais leve (`rgba(31, 85, 186, .32)` → `rgba(47, 111, 237, .22)` → `rgba(75, 145, 245, .12)`).

Alertas e estados de risco mantêm suas cores próprias; azul é exclusivamente a identidade dos controles e seleções principais.

## Convenção visual aprovada — login

A tela de login utiliza o conceito de **ciência de dados em movimento**: fundo analítico em tela cheia com grade discreta, duas séries temporais, pontos pulsantes, varredura vertical e brilhos suaves em azul. O formulário permanece à direita, translúcido e legível, sem mudar sua estrutura de autenticação, CSRF ou recuperação de senha. A animação respeita `prefers-reduced-motion` e deve continuar sendo apenas decorativa; não iniciar nem bloquear o acesso.
