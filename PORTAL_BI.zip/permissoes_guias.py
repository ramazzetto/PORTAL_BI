"""Catalogo de guias e autorizacao por funcao. Sem acesso ao banco neste modulo."""
GUIAS = (
    ('dashboards', 'Dashboards', 'index'),
    ('cadastro', 'Cadastro de Dashboard', 'cadastro'),
    ('dashboards_administracao', 'Administração de Dashboard', 'dashboards_administracao'),
    ('usuarios', 'Visão geral de Usuários', 'usuarios'),
    ('usuarios_cadastro', 'Cadastro de Usuários', 'usuarios_cadastro'),
    ('usuarios_administracao', 'Administração de Usuários', 'usuarios_administracao'),
    ('acessos', 'Acessos', 'acessos'),
    ('aviso', 'Avisos', 'aviso'),
    ('minha_conta', 'Minha conta', 'minha_conta'),
)
IDS_GUIAS = frozenset(g[0] for g in GUIAS)
GUIAS_ENDPOINT = {
    'index': ('dashboards',), 'dashboard': ('dashboards',), 'favoritos_alternar': ('dashboards',),
    'cadastro': ('cadastro',), 'cadastrar': ('cadastro',),
    'dashboards_administracao': ('dashboards_administracao',),
    # O cadastro também exibe a árvore de estrutura. Administradores com essa
    # guia liberada podem excluir dashboards diretamente por ela, sempre
    # sujeitos à validação de escopo no servidor.
    'editar': ('dashboards_administracao',), 'excluir': ('cadastro', 'dashboards_administracao'),
    'usuarios': ('usuarios',), 'usuarios_cadastro': ('usuarios_cadastro',),
    'criar_usuario': ('usuarios_cadastro',), 'usuarios_administracao': ('usuarios_administracao',),
    'modelo_importacao_usuarios': ('usuarios_cadastro',),
    'importar_usuarios': ('usuarios_cadastro',),
    'exportar_usuarios_importados': ('usuarios_cadastro',),
    'editar_usuario': ('usuarios_administracao',), 'excluir_usuario': ('usuarios_administracao',),
    'salvar_permissoes_usuario': ('usuarios_administracao',),
    'acessos': ('acessos',), 'exportar_acessos': ('acessos',),
    'aviso': ('aviso',), 'aviso_salvar': ('aviso',), 'aviso_remover': ('aviso',),
    'aviso_eventos_online': ('aviso',), 'aviso_eventos_fluxo': ('aviso',),
    'avisos_eventos_fluxo': ('aviso',), 'exportar_avisos': ('aviso',),
    'exportar_avisos_todos': ('aviso',), 'exportar_avisos_historico': ('aviso',),
    'minha_conta': ('minha_conta',), 'trocar_senha': ('minha_conta',),
    'permissoes_ambiente': ('permissoes_ambiente',), 'ambiente_salvar': ('permissoes_ambiente',),
    'ambiente_status': ('permissoes_ambiente',), 'ambiente_excluir': ('permissoes_ambiente',),
    'ambiente_associacoes': ('permissoes_ambiente',),
    'administracao_master': ('administracao_master',), 'salvar_guias_master': ('administracao_master',),
}
for _endpoint in ('criar_pasta', 'renomear_pasta', 'excluir_pasta', 'criar_subpasta',
                  'renomear_subpasta', 'editar_estrutura_subpasta', 'excluir_subpasta'):
    GUIAS_ENDPOINT[_endpoint] = ('cadastro', 'dashboards_administracao')


def eh_master(usuario):
    return bool(usuario and usuario.get('papel') == 'master')


def guias_efetivas(usuario):
    if not usuario:
        return set()
    if eh_master(usuario):
        return set(IDS_GUIAS) | {'administracao_master', 'permissoes_ambiente'}
    if usuario.get('guias') is not None:
        # Minha conta é pessoal e necessária para que Administradores e
        # Visualizadores possam trocar senha e gerir
        # a própria foto. Não pode ser removida pelas permissões de guias.
        return (set(usuario['guias']) & IDS_GUIAS) | ({'permissoes_ambiente'} if usuario.get('papel') == 'admin' else set()) | {'minha_conta'}
    if usuario.get('papel') == 'admin':
        return set(IDS_GUIAS) | {'permissoes_ambiente'}
    return {'dashboards', 'minha_conta'} if usuario.get('papel') == 'viewer' else set()


def pode_guia(usuario, guia):
    return guia in guias_efetivas(usuario)


def pode_endpoint(usuario, endpoint):
    return any(pode_guia(usuario, guia) for guia in GUIAS_ENDPOINT.get(endpoint, ()))


def pode_gerenciar_usuario(ator, alvo):
    if not ator or not alvo or eh_master(alvo):
        return False
    if eh_master(ator):
        return True
    return pode_guia(ator, 'usuarios_administracao') and alvo.get('papel') == 'viewer' and alvo.get('id') != ator.get('id')


def nome_perfil(papel):
    # "gestor" é aceito somente como valor legado durante a migração; em
    # históricos antigos, ele deve aparecer como Visualizador.
    return {'master': 'Master', 'admin': 'Administrador', 'viewer': 'Visualizador', 'gestor': 'Visualizador'}.get(papel, papel)
