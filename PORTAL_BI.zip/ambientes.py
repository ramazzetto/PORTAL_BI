"""Ambientes, associações e contexto da requisição. Contas continuam globais."""
import uuid
from flask import g, has_request_context

INICIAL = "inicial"
IMAGEM_AMBIENTE_MAX_BYTES = 2 * 1024 * 1024
IMAGEM_AMBIENTE_MIMES = frozenset({"image/png", "image/jpeg", "image/webp"})


def contexto_ambiente():
    return getattr(g, "_portal_ambiente_id", None) if has_request_context() else None


def preparar_ambientes(conn):
    """Prepara as tabelas de ambientes e elimina a estrutura legada inicial."""
    from db import DB_NAME
    with conn.cursor() as cur:
        cur.execute("""CREATE TABLE IF NOT EXISTS ambientes (
            id VARCHAR(32) PRIMARY KEY, nome VARCHAR(120) NOT NULL,
            ativo TINYINT NOT NULL DEFAULT 1,
            criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uq_ambiente_nome (nome)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""")
        # A imagem fica no próprio banco para acompanhar o ambiente em
        # backups e permitir que a mesma instalação funcione em qualquer
        # computador sem depender de uma pasta de uploads local.
        for coluna, definicao in (
            ("imagem_dados", "MEDIUMBLOB NULL"),
            ("imagem_mime", "VARCHAR(50) NULL"),
            ("imagem_nome", "VARCHAR(255) NULL"),
            ("imagem_atualizada_em", "TIMESTAMP NULL DEFAULT NULL"),
        ):
            cur.execute("""SELECT COUNT(*) AS qtd FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_SCHEMA = %s AND TABLE_NAME = 'ambientes' AND COLUMN_NAME = %s""",
                (DB_NAME, coluna))
            if cur.fetchone()["qtd"] == 0:
                cur.execute(f"ALTER TABLE ambientes ADD COLUMN {coluna} {definicao}")
        # Sem FK de usuário: o armazenamento legado regrava contas em save_users.
        cur.execute("""CREATE TABLE IF NOT EXISTS ambiente_usuarios (
            ambiente_id VARCHAR(32) NOT NULL, usuario_id VARCHAR(32) NOT NULL,
            associado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (ambiente_id, usuario_id), INDEX idx_ambiente_usuario (usuario_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""")
        cur.execute("""CREATE TABLE IF NOT EXISTS ambiente_migracoes (
            id VARCHAR(50) PRIMARY KEY
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""")
        cur.execute("""CREATE TABLE IF NOT EXISTS ambiente_avisos (
            ambiente_id VARCHAR(32) PRIMARY KEY, aviso_id VARCHAR(32) NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""")
        cur.execute("""CREATE TABLE IF NOT EXISTS ambiente_sessoes (
            sessao VARCHAR(32) PRIMARY KEY, usuario_id VARCHAR(32) NOT NULL,
            ambiente_id VARCHAR(32) NOT NULL,
            atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_ambiente_sessao_usuario (usuario_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4""")
        for tabela in ("pastas", "acessos", "usuario_eventos", "avisos_publicacoes"):
            cur.execute("""SELECT COUNT(*) AS qtd FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s AND COLUMN_NAME = 'ambiente_id'""",
                (DB_NAME, tabela))
            if not cur.fetchone()["qtd"]:
                cur.execute(f"ALTER TABLE {tabela} ADD COLUMN ambiente_id VARCHAR(32) NOT NULL DEFAULT 'inicial', ADD INDEX idx_ambiente (ambiente_id)")
        # O Ambiente inicial era um contêiner técnico da primeira versão.
        # Esta instalação já usa ambientes explícitos; a migração remove seus
        # dados locais e impede que ele volte a aparecer nas telas.
        cur.execute("SELECT id FROM ambiente_migracoes WHERE id = 'remover-ambiente-inicial-v1'")
        if not cur.fetchone():
            cur.execute("SELECT id FROM pastas WHERE ambiente_id = %s FOR UPDATE", (INICIAL,))
            pasta_ids = [linha["id"] for linha in cur.fetchall()]
            placeholders = ",".join(["%s"] * len(pasta_ids))
            sub_ids, dash_ids = [], []
            if pasta_ids:
                cur.execute(f"SELECT id FROM subpastas WHERE pasta_id IN ({placeholders}) FOR UPDATE", tuple(pasta_ids))
                sub_ids = [linha["id"] for linha in cur.fetchall()]
                cur.execute(f"SELECT id FROM dashboards WHERE pasta_id IN ({placeholders}) FOR UPDATE", tuple(pasta_ids))
                dash_ids = [linha["id"] for linha in cur.fetchall()]
            # Dashboards sem pasta pertenciam exclusivamente ao antigo padrão.
            cur.execute("SELECT id FROM dashboards WHERE pasta_id IS NULL FOR UPDATE")
            dash_ids.extend(linha["id"] for linha in cur.fetchall())

            def excluir_ids(tabela, coluna, ids):
                ids = sorted(set(ids))
                cur.execute("""SELECT COUNT(*) AS qtd FROM INFORMATION_SCHEMA.TABLES
                    WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s""", (DB_NAME, tabela))
                if ids and cur.fetchone()["qtd"]:
                    cur.execute(f"DELETE FROM {tabela} WHERE {coluna} IN ({','.join(['%s'] * len(ids))})", tuple(ids))

            cur.execute("SELECT id FROM avisos_publicacoes WHERE ambiente_id = %s FOR UPDATE", (INICIAL,))
            aviso_ids = [linha["id"] for linha in cur.fetchall()]
            excluir_ids("avisos_eventos", "aviso_id", aviso_ids)
            excluir_ids("avisos_destinatarios", "aviso_id", aviso_ids)
            excluir_ids("avisos_publicacoes", "id", aviso_ids)
            excluir_ids("usuario_dashboard_bloqueios", "dashboard_id", dash_ids)
            excluir_ids("usuario_subpasta_bloqueios", "subpasta_id", sub_ids)
            excluir_ids("dashboards", "id", dash_ids)
            cur.execute("DELETE FROM acessos WHERE ambiente_id = %s", (INICIAL,))
            cur.execute("DELETE FROM usuario_eventos WHERE ambiente_id = %s", (INICIAL,))
            cur.execute("DELETE FROM ambiente_sessoes WHERE ambiente_id = %s", (INICIAL,))
            cur.execute("DELETE FROM ambiente_usuarios WHERE ambiente_id = %s", (INICIAL,))
            cur.execute("DELETE FROM ambiente_avisos WHERE ambiente_id = %s", (INICIAL,))
            cur.execute("DELETE FROM pastas WHERE ambiente_id = %s", (INICIAL,))
            cur.execute("DELETE FROM ambientes WHERE id = %s", (INICIAL,))
            cur.execute("INSERT INTO ambiente_migracoes (id) VALUES ('remover-ambiente-inicial-v1')")


def listar_ambientes(usuario_id=None, somente_ativos=False):
    from db import conexao
    with conexao() as conn, conn.cursor() as cur:
        sql = """SELECT a.id, a.nome, a.ativo, a.imagem_mime,
                         CASE WHEN a.imagem_dados IS NULL THEN 0 ELSE 1 END AS tem_imagem,
                         UNIX_TIMESTAMP(a.imagem_atualizada_em) AS imagem_versao
                  FROM ambientes a WHERE 1=1"""
        params = []
        if usuario_id is not None:
            sql += " AND EXISTS (SELECT 1 FROM ambiente_usuarios au WHERE au.ambiente_id = a.id AND au.usuario_id = %s)"
            params.append(usuario_id)
        if somente_ativos:
            sql += " AND a.ativo = 1"
        cur.execute(sql + " ORDER BY a.nome, a.id", tuple(params))
        return list(cur.fetchall())


def salvar_imagem_ambiente(ator_id, ambiente_id, dados, mime, nome=""):
    """Salva a imagem do cartão de um ambiente (operação exclusiva do Master)."""
    from db import conexao

    ambiente_id = (ambiente_id or "").strip()
    if not ambiente_id:
        raise ValueError("Ambiente não informado.")
    if not isinstance(dados, (bytes, bytearray)) or not dados:
        raise ValueError("Selecione uma imagem para enviar.")
    if len(dados) > IMAGEM_AMBIENTE_MAX_BYTES:
        raise ValueError("A imagem deve ter no máximo 2 MB.")
    if mime not in IMAGEM_AMBIENTE_MIMES:
        raise ValueError("Use uma imagem PNG, JPG/JPEG ou WebP.")
    nome = (nome or "").replace("\x00", "").strip()[:255]
    with conexao() as conn, conn.cursor() as cur:
        _exigir_master(cur, ator_id)
        cur.execute("SELECT id FROM ambientes WHERE id = %s FOR UPDATE", (ambiente_id,))
        if not cur.fetchone():
            raise ValueError("Ambiente não encontrado.")
        cur.execute("""UPDATE ambientes
                       SET imagem_dados = %s, imagem_mime = %s, imagem_nome = %s,
                           imagem_atualizada_em = CURRENT_TIMESTAMP
                       WHERE id = %s""", (bytes(dados), mime, nome or None, ambiente_id))


def remover_imagem_ambiente(ator_id, ambiente_id):
    """Remove a imagem do ambiente, mantendo o cartão com o ícone padrão."""
    from db import conexao

    ambiente_id = (ambiente_id or "").strip()
    if not ambiente_id:
        raise ValueError("Ambiente não informado.")
    with conexao() as conn, conn.cursor() as cur:
        _exigir_master(cur, ator_id)
        cur.execute("SELECT id FROM ambientes WHERE id = %s FOR UPDATE", (ambiente_id,))
        if not cur.fetchone():
            raise ValueError("Ambiente não encontrado.")
        cur.execute("""UPDATE ambientes
                       SET imagem_dados = NULL, imagem_mime = NULL, imagem_nome = NULL,
                           imagem_atualizada_em = CURRENT_TIMESTAMP
                       WHERE id = %s""", (ambiente_id,))


def carregar_imagem_ambiente(ambiente_id):
    """Retorna os bytes e o MIME da imagem, sem carregar a lista de ambientes."""
    from db import conexao

    ambiente_id = (ambiente_id or "").strip()
    if not ambiente_id:
        return None
    with conexao() as conn, conn.cursor() as cur:
        cur.execute("""SELECT imagem_dados, imagem_mime, imagem_nome
                       FROM ambientes WHERE id = %s""", (ambiente_id,))
        return cur.fetchone()


def usuarios_do_ambiente(ambiente_id):
    from db import conexao
    cache = getattr(g, "_ambiente_membros", {}) if has_request_context() else {}
    if ambiente_id in cache:
        return cache[ambiente_id]
    with conexao() as conn, conn.cursor() as cur:
        cur.execute("""SELECT au.usuario_id FROM ambiente_usuarios au
            JOIN usuarios u ON u.id = au.usuario_id
            WHERE au.ambiente_id = %s AND u.papel <> 'master'""", (ambiente_id,))
        ids = {r["usuario_id"] for r in cur.fetchall()}
    if has_request_context():
        cache[ambiente_id] = ids
        g._ambiente_membros = cache
    return ids


def ambientes_do_usuario(usuario_id):
    return {a["id"] for a in listar_ambientes(usuario_id)}


def ler_ambiente_sessao(usuario_id, sessao):
    from db import conexao
    with conexao() as conn, conn.cursor() as cur:
        cur.execute("SELECT ambiente_id FROM ambiente_sessoes WHERE sessao = %s AND usuario_id = %s", (sessao, usuario_id))
        linha = cur.fetchone()
        return linha["ambiente_id"] if linha else None


def selecionar_ambiente_sessao(usuario_id, sessao, ambiente_id):
    """Escolha no servidor: uma resposta antiga não pode reverter a troca por cookie."""
    from db import conexao
    with conexao() as conn, conn.cursor() as cur:
        cur.execute("""SELECT a.id FROM ambientes a JOIN ambiente_usuarios au ON au.ambiente_id = a.id
            WHERE a.id = %s AND a.ativo = 1 AND au.usuario_id = %s FOR UPDATE""", (ambiente_id, usuario_id))
        if not cur.fetchone():
            raise PermissionError("Ambiente indisponível para este usuário.")
        cur.execute("""INSERT INTO ambiente_sessoes (sessao, usuario_id, ambiente_id)
            VALUES (%s, %s, %s) ON DUPLICATE KEY UPDATE usuario_id = VALUES(usuario_id),
            ambiente_id = VALUES(ambiente_id), atualizado_em = CURRENT_TIMESTAMP""", (sessao, usuario_id, ambiente_id))


def encerrar_ambiente_sessao(usuario_id, sessao):
    from db import conexao
    with conexao() as conn, conn.cursor() as cur:
        cur.execute("DELETE FROM ambiente_sessoes WHERE sessao = %s AND usuario_id = %s", (sessao, usuario_id))


def _exigir_master(cur, ator_id):
    from db import _exigir_master_no_banco
    cur.execute("SELECT usuario_id FROM portal_master_controle WHERE id = 1 FOR UPDATE")
    _exigir_master_no_banco(cur, ator_id)


def salvar_ambiente(ator_id, nome, ambiente_id=None):
    from db import conexao
    nome = " ".join(nome.split())
    if not 1 <= len(nome) <= 120:
        raise ValueError("Informe um nome de ambiente com até 120 caracteres.")
    with conexao() as conn, conn.cursor() as cur:
        _exigir_master(cur, ator_id)
        cur.execute("SELECT id FROM ambientes WHERE nome = %s", (nome,))
        existente = cur.fetchone()
        if existente and existente["id"] != ambiente_id:
            raise ValueError("Já existe um ambiente com esse nome.")
        if ambiente_id:
            cur.execute("SELECT id FROM ambientes WHERE id = %s FOR UPDATE", (ambiente_id,))
            if not cur.fetchone():
                raise ValueError("Ambiente não encontrado.")
            cur.execute("UPDATE ambientes SET nome = %s WHERE id = %s", (nome, ambiente_id))
        else:
            ambiente_id = uuid.uuid4().hex
            cur.execute("INSERT INTO ambientes (id, nome) VALUES (%s, %s)", (ambiente_id, nome))
            cur.execute("INSERT INTO ambiente_avisos (ambiente_id) VALUES (%s)", (ambiente_id,))
    return ambiente_id


def definir_ambiente_ativo(ator_id, ambiente_id, ativo):
    from db import conexao
    with conexao() as conn, conn.cursor() as cur:
        _exigir_master(cur, ator_id)
        cur.execute("SELECT id FROM ambientes WHERE id = %s FOR UPDATE", (ambiente_id,))
        if not cur.fetchone():
            raise ValueError("Ambiente não encontrado.")
        cur.execute("UPDATE ambientes SET ativo = %s WHERE id = %s", (int(ativo), ambiente_id))


def excluir_ambiente(ator_id, ambiente_id):
    """Exclui um ambiente e todos os dados que pertencem a ele.

    A operação é exclusiva do Master e ocorre em uma única transação.
    Contas de usuários são globais: somente o vínculo com o ambiente é
    removido; a conta continua disponível nos demais ambientes.
    """
    from db import conexao

    ambiente_id = (ambiente_id or "").strip()
    if not ambiente_id:
        raise ValueError("Ambiente não informado.")
    def _delete_ids(cur, tabela, coluna, ids):
        ids = sorted({str(item).strip() for item in ids if item})
        if not ids:
            return
        placeholders = ",".join(["%s"] * len(ids))
        cur.execute(f"DELETE FROM {tabela} WHERE {coluna} IN ({placeholders})", tuple(ids))

    with conexao() as conn, conn.cursor() as cur:
        _exigir_master(cur, ator_id)
        cur.execute("SELECT id, nome FROM ambientes WHERE id = %s FOR UPDATE", (ambiente_id,))
        ambiente = cur.fetchone()
        if not ambiente:
            raise ValueError("Ambiente não encontrado.")

        # Captura os IDs antes da exclusão para limpar tabelas sem FK e
        # preservar a operação atômica caso qualquer etapa falhe.
        cur.execute("SELECT id FROM pastas WHERE ambiente_id = %s FOR UPDATE", (ambiente_id,))
        pasta_ids = [row["id"] for row in cur.fetchall()]
        sub_ids = []
        dash_ids = []
        if pasta_ids:
            placeholders = ",".join(["%s"] * len(pasta_ids))
            cur.execute(
                f"SELECT id FROM subpastas WHERE pasta_id IN ({placeholders}) FOR UPDATE",
                tuple(pasta_ids),
            )
            sub_ids = [row["id"] for row in cur.fetchall()]
            cur.execute(
                f"SELECT id FROM dashboards WHERE pasta_id IN ({placeholders}) FOR UPDATE",
                tuple(pasta_ids),
            )
            dash_ids = [row["id"] for row in cur.fetchall()]

        # Publicações possuem tabelas filhas com FK para o aviso. Remova os
        # comprovantes primeiro; o histórico não deve ficar órfão do ambiente.
        cur.execute("SELECT aviso_id FROM ambiente_avisos WHERE ambiente_id = %s FOR UPDATE", (ambiente_id,))
        aviso_ids = {row["aviso_id"] for row in cur.fetchall() if row.get("aviso_id")}
        cur.execute("SELECT id FROM avisos_publicacoes WHERE ambiente_id = %s FOR UPDATE", (ambiente_id,))
        aviso_ids.update(row["id"] for row in cur.fetchall())
        # Uma instalação antiga pode ter reutilizado uma publicação em mais
        # de um ambiente. Nesse caso ela não pertence exclusivamente ao
        # ambiente removido e seus registros devem permanecer intactos.
        if aviso_ids:
            aviso_params = tuple(sorted(aviso_ids))
            placeholders = ",".join(["%s"] * len(aviso_params))
            cur.execute(
                f"SELECT DISTINCT aviso_id FROM ambiente_avisos "
                f"WHERE aviso_id IN ({placeholders}) AND ambiente_id <> %s",
                aviso_params + (ambiente_id,),
            )
            aviso_ids -= {row["aviso_id"] for row in cur.fetchall() if row.get("aviso_id")}
        _delete_ids(cur, "avisos_eventos", "aviso_id", aviso_ids)
        _delete_ids(cur, "avisos_destinatarios", "aviso_id", aviso_ids)
        _delete_ids(cur, "avisos_publicacoes", "id", aviso_ids)

        # As tabelas de bloqueios e auditoria não possuem FK de ambiente;
        # removemos seus registros explicitamente antes de apagar a estrutura.
        _delete_ids(cur, "usuario_dashboard_bloqueios", "dashboard_id", dash_ids)
        _delete_ids(cur, "usuario_subpasta_bloqueios", "subpasta_id", sub_ids)
        cur.execute("DELETE FROM acessos WHERE ambiente_id = %s", (ambiente_id,))
        cur.execute("DELETE FROM usuario_eventos WHERE ambiente_id = %s", (ambiente_id,))
        cur.execute("DELETE FROM ambiente_sessoes WHERE ambiente_id = %s", (ambiente_id,))
        cur.execute("DELETE FROM ambiente_usuarios WHERE ambiente_id = %s", (ambiente_id,))
        cur.execute("DELETE FROM ambiente_avisos WHERE ambiente_id = %s", (ambiente_id,))

        # As FKs em pastas/subpastas/dashboards, permissões e favoritos fazem
        # a limpeza em cascata apenas dentro da estrutura deste ambiente.
        cur.execute("DELETE FROM pastas WHERE ambiente_id = %s", (ambiente_id,))
        cur.execute("DELETE FROM ambientes WHERE id = %s", (ambiente_id,))

    if has_request_context():
        g.pop("_ambiente_membros", None)
        g.pop("_dados_cache", None)
        g.pop("_usuarios_cache", None)
    return ambiente["nome"]


def alterar_associacoes(ator_id, ambiente_id, usuarios, acao):
    from db import conexao
    if acao not in {"associar", "remover"} or not isinstance(usuarios, list) or not usuarios:
        raise ValueError("Selecione ao menos um usuário e uma ação válida.")
    if len(usuarios) > 500 or any(not isinstance(u, str) or not u or len(u) > 32 for u in usuarios):
        raise ValueError("Seleção inválida. Selecione até 500 usuários por vez.")
    ids = sorted(set(usuarios))
    with conexao() as conn, conn.cursor() as cur:
        # O Master administra todos os ambientes. Um Administrador pode
        # administrar somente a associação de Visualizadores no ambiente ao
        # qual ele próprio já está vinculado; nunca promove, remove ou move
        # outro Administrador por esta tela.
        cur.execute("SELECT usuario_id FROM portal_master_controle WHERE id = 1 FOR UPDATE")
        cur.execute("SELECT papel FROM usuarios WHERE id = %s", (ator_id,))
        ator = cur.fetchone()
        if not ator or ator["papel"] not in {"master", "admin"}:
            raise PermissionError("Operação não permitida.")
        cur.execute("SELECT id FROM ambientes WHERE id = %s FOR UPDATE", (ambiente_id,))
        if not cur.fetchone():
            raise ValueError("Ambiente não encontrado.")
        if ator["papel"] == "admin":
            cur.execute("SELECT 1 FROM ambiente_usuarios WHERE ambiente_id = %s AND usuario_id = %s",
                        (ambiente_id, ator_id))
            if not cur.fetchone():
                raise PermissionError("Ambiente indisponível para este Administrador.")
        placeholders = ",".join(["%s"] * len(ids))
        cur.execute(f"SELECT id, papel FROM usuarios WHERE id IN ({placeholders})", tuple(ids))
        encontrados = list(cur.fetchall())
        papeis_permitidos = {"admin", "viewer"} if ator["papel"] == "master" else {"viewer"}
        if len(encontrados) != len(ids) or any(u["papel"] not in papeis_permitidos for u in encontrados):
            raise ValueError("A seleção contém uma conta indisponível. Atualize a página.")
        for uid in ids:
            if acao == "associar":
                cur.execute("INSERT IGNORE INTO ambiente_usuarios (ambiente_id, usuario_id) VALUES (%s, %s)", (ambiente_id, uid))
            else:
                # Revoga só esta associação; não exclui a conta nem outros ambientes.
                cur.execute("DELETE FROM ambiente_usuarios WHERE ambiente_id = %s AND usuario_id = %s", (ambiente_id, uid))
    if has_request_context():
        g.pop("_ambiente_membros", None)


def remover_usuario_do_ambiente(ator, alvo):
    """Administrador remove apenas um Visualizador do ambiente em uso."""
    from db import conexao
    ambiente = contexto_ambiente()
    with conexao() as conn, conn.cursor() as cur:
        cur.execute("SELECT usuario_id FROM portal_master_controle WHERE id = 1 FOR UPDATE")
        cur.execute("SELECT id, papel FROM usuarios WHERE id IN (%s, %s)", (ator["id"], alvo["id"]))
        papeis = {u["id"]: u["papel"] for u in cur.fetchall()}
        if not ambiente or papeis.get(ator["id"]) != "admin" or papeis.get(alvo["id"]) != "viewer":
            raise PermissionError("Operação não permitida.")
        cur.execute("SELECT usuario_id FROM ambiente_usuarios WHERE ambiente_id = %s AND usuario_id = %s",
                    (ambiente, ator["id"]))
        if not cur.fetchone():
            raise PermissionError("Ambiente indisponível.")
        cur.execute("DELETE FROM ambiente_usuarios WHERE ambiente_id = %s AND usuario_id = %s", (ambiente, alvo["id"]))
    if has_request_context():
        g.pop("_ambiente_membros", None)
