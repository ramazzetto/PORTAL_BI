"""
Portal de Dashboards Power BI — com login e controle de acesso por pasta
------------------------------------------------------------------------
Papeis:
  - admin      : acessa o conteudo autorizado pelo Master e gerencia usuarios permitidos
  - viewer     : ve apenas os dashboards das pastas liberadas para ele

Senhas sao guardadas com HASH (werkzeug), nunca em texto puro.

Armazenamento: MySQL/MariaDB (veja db.py). Configure a conexao com as
variaveis de ambiente DB_HOST/DB_PORT/DB_USER/DB_PASSWORD/DB_NAME, ou
crie um arquivo ".env" na pasta do projeto (veja .env.exemplo) -- ele e
carregado automaticamente ao rodar localmente.

Primeiro acesso em instalacoes novas: execute criar_master.py localmente.
Somente o Master pode cadastrar ou promover usuarios Administradores.

Rodar (desenvolvimento local):
  pip install -r requirements.txt
  python app.py
  -> http://localhost:5000

Para deploy em Apache/producao, veja DEPLOY_APACHE_WINDOWS.md.
"""

import os
import uuid
import io
import re
import hashlib
import hmac
import json
import time
from tempfile import NamedTemporaryFile
from threading import Condition
from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode
from datetime import datetime, timedelta
from functools import wraps
from collections import Counter
from werkzeug.exceptions import HTTPException
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.middleware.proxy_fix import ProxyFix
from flask import (
    Flask, render_template, request, redirect, url_for, abort, session, flash,
    send_file, jsonify, g, Response, stream_with_context
)
from permissoes_guias import (
    GUIAS, IDS_GUIAS, GUIAS_ENDPOINT, eh_master, guias_efetivas,
    pode_guia, pode_endpoint, pode_gerenciar_usuario as _pode_gerenciar_por_perfil, nome_perfil,
)
from openpyxl import Workbook
from openpyxl.cell import WriteOnlyCell
from pymysql.err import IntegrityError, MySQLError
from cadastro_usuarios import (
    gerar_login, validar_email, ler_importacao, modelo_usuarios_em_memoria,
    LIMITE_USUARIOS, LIMITE_ARQUIVO,
)
from openpyxl.styles import Font, PatternFill, Alignment
from flask_wtf import CSRFProtect
from flask_wtf.csrf import CSRFError, generate_csrf
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired
from email_portal import (
    EmailNaoConfigurado, EmailEnvioFalhou,
    obter_configuracao_email, enviar_email_redefinicao,
)

try:
    from PIL import Image, ImageOps
except ImportError:  # A prévia no navegador continua funcionando sem Pillow.
    Image = None
    ImageOps = None

try:
    from dotenv import load_dotenv
    load_dotenv(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env"))
except ImportError:
    pass

app = Flask(__name__)

# --- Chave secreta: obrigatoria e nao pode ficar no valor padrao/exemplo ---
_SECRET_KEY = os.environ.get("SECRET_KEY", "")
_VALORES_INSEGUROS = {"", "troque-esta-chave-em-producao", "troque-por-uma-chave-aleatoria-longa"}
if _SECRET_KEY in _VALORES_INSEGUROS or len(_SECRET_KEY) < 32:
    raise RuntimeError(
        "SECRET_KEY nao configurada corretamente (ausente, no valor padrao, ou curta demais).\n"
        "Defina uma chave forte e unica no arquivo .env. Gere uma com:\n"
        '  python -c "import secrets; print(secrets.token_hex(32))"'
    )
app.secret_key = _SECRET_KEY

def _env_bool(nome, padrao="false"):
    valor = os.environ.get(nome, padrao).strip().lower()
    if valor not in {"true", "false"}:
        raise RuntimeError(f"{nome} deve ser true ou false.")
    return valor == "true"


def _env_minutos(nome, padrao, minimo=2, maximo=1440):
    try:
        valor = int(os.environ.get(nome, str(padrao)))
    except ValueError:
        raise RuntimeError(f"{nome} deve ser um numero inteiro de minutos.") from None
    if not minimo <= valor <= maximo:
        raise RuntimeError(f"{nome} deve ficar entre {minimo} e {maximo} minutos.")
    return valor


# Os mesmos arquivos atendem HTTP local e HTTPS; somente o .env muda.
_HTTPS_ATIVO = _env_bool("HTTPS_ATIVO")
_INATIVIDADE_MINUTOS = _env_minutos("INATIVIDADE_MINUTOS", 5)
_FORMULARIO_MINUTOS = _env_minutos("FORMULARIO_MINUTOS", 30)
_RECUPERACAO_SENHA_MINUTOS = _env_minutos(
    "RECUPERACAO_SENHA_MINUTOS", 30, minimo=5, maximo=120
)
_RATE_LIMIT_STORAGE_URI = os.environ.get("RATE_LIMIT_STORAGE_URI", "memory://").strip() or "memory://"
# Valor reservado apenas para a tela de Avisos. Ele não representa um
# ambiente real (os IDs dos ambientes são UUIDs hexadecimais) e permite ao
# Master publicar um comunicado único para todos os ambientes ativos.
_AVISO_TODOS_AMBIENTES = "__todos_ambientes__"
# Valor reservado apenas para a troca de contexto do Master. O redirecionamento
# converte esta opção para ``ambiente=`` antes de abrir a tela, para que ela não
# seja confundida com o destino especial de publicação de avisos.
_AMBIENTE_TODOS = "__todos_contextos__"
app.config.update(
    SESSION_COOKIE_NAME="portal_bi_session",
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=_HTTPS_ATIVO,
    PERMANENT_SESSION_LIFETIME=timedelta(minutes=_FORMULARIO_MINUTOS),
    WTF_CSRF_TIME_LIMIT=_FORMULARIO_MINUTOS * 60,
)

if _env_bool("PROXY_CONFIAVEL"):
    # Um unico proxy. O backend deve aceitar conexoes apenas desse proxy.
    app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=0)


@app.before_request
def preparar_sessao_formulario():
    if request.endpoint == "importar_usuarios":
        # Aplicado antes de o CSRF ler o multipart; inclui margem para o formulário.
        if request.content_length and request.content_length > LIMITE_ARQUIVO + 65536:
            abort(413, description="A planilha deve ter até 5 MB.")
        # Flask 3.1 permite o limite por requisição; 3.0 usa o tamanho acima.
        if getattr(type(request._get_current_object()).max_content_length, "fset", None):
            request.max_content_length = LIMITE_ARQUIVO + 65536
    if request.endpoint == "enviar_foto_perfil":
        # Limite antes de o Flask processar o multipart. O arquivo é tratado
        # novamente na rota, antes de ser salvo no banco.
        if request.content_length and request.content_length > FOTO_USUARIO_ORIGINAL_MAX_BYTES + 65536:
            abort(413, description="A foto deve ter até 5 MB.")
        if getattr(type(request._get_current_object()).max_content_length, "fset", None):
            request.max_content_length = FOTO_USUARIO_ORIGINAL_MAX_BYTES + 65536
    if request.endpoint != "static":
        session.permanent = True


@app.after_request
def impedir_cache_formularios(response):
    if request.endpoint != "static":
        response.headers["Cache-Control"] = "no-store, private"
        response.headers["Pragma"] = "no-cache"
    return response

# --- CSRF: protege todos os formularios (POST) contra requisicoes forjadas
# vindas de outros sites. Cada <form> precisa do campo {{ csrf_token() }}. ---
csrf = CSRFProtect(app)


def _solicitacao_assincrona_json():
    """Identifica ações da interface que precisam receber JSON.

    Alguns proxies removem cabeçalhos personalizados. O marcador no formulário
    e o Accept permitem preservar a resposta JSON mesmo nesses ambientes.
    """
    return (
        request.headers.get("X-Portal-Async") == "1"
        or request.form.get("_portal_async") == "1"
        or "application/json" in request.headers.get("Accept", "").lower()
    )


@app.errorhandler(CSRFError)
def erro_csrf(e):
    app.logger.warning("Falha CSRF: endpoint=%s motivo=%s", request.endpoint, e.description)
    if request.endpoint == "login":
        flash("O formulário expirou e foi atualizado. Digite sua senha novamente.", "erro")
        return render_template("login.html", usuario_preenchido=request.form.get("usuario", "")), 400
    if request.endpoint == "recuperar":
        flash("O formulário expirou. Informe o e-mail novamente para enviar um novo link.", "erro")
        return render_template("recuperar.html"), 400
    if request.endpoint == "recuperar_redefinir":
        token = (request.view_args or {}).get("token", "")
        if isinstance(token, str) and token:
            flash("O formulário expirou. Abra novamente o link e tente salvar a nova senha.", "erro")
            return redirect(url_for("recuperar_redefinir", token=token), code=303)
    if request.is_json or request.headers.get("X-CSRFToken") or _solicitacao_assincrona_json():
        return jsonify(
            ok=False,
            erro="formulario_expirado",
            mensagem="O formulário expirou. Atualize a página e tente novamente.",
        ), 400
    flash("O formulário expirou. A página foi atualizada; confira os dados e tente novamente.", "erro")
    origem = urlsplit(request.referrer or "")
    if origem.netloc == request.host and origem.scheme == request.scheme:
        return redirect(urlunsplit(("", "", origem.path, origem.query, "")), code=303)
    return redirect(url_for("login"), code=303)


@app.get("/sessao/csrf")
def token_formulario():
    # A leitura exige a mesma origem pelo navegador; nao habilitar CORS aqui.
    return jsonify(csrf_token=generate_csrf())


# --- Limite de tentativas de login, para dificultar ataques de forca bruta ---
limiter = Limiter(get_remote_address, app=app, storage_uri=_RATE_LIMIT_STORAGE_URI)


@app.errorhandler(429)
def erro_muitas_tentativas(e):
    flash("Muitas tentativas em pouco tempo. Aguarde um instante e tente de novo.", "erro")
    if request.endpoint == "recuperar":
        return render_template("recuperar.html"), 429
    if request.endpoint == "recuperar_redefinir":
        return render_template("recuperar_redefinir.html", token=None, usuario=None), 429
    return render_template("login.html"), 429

from db import criar_tabelas
criar_tabelas()  # cria as tabelas no banco se ainda nao existirem (idempotente)


# ===========================================================================
# Armazenamento: pastas + dashboards (agora em MySQL/MariaDB, via db.py)
# ===========================================================================
from db import (
    ConflitoGravacao,
    get_connection,
    load_data, load_data_ambientes, save_data, inserir_pasta, inserir_subpasta, load_users, save_users, concluir_primeiro_acesso, salvar_guias_usuario,
    atualizar_usuario_pontual, salvar_permissoes_usuario_pontual, remover_usuario_pontual,
    salvar_dashboard_pontual, mover_dashboard_pontual, excluir_dashboard_pontual,
    renomear_pasta_pontual, renomear_subpasta_pontual, mover_subpasta_pontual,
    excluir_subpastas_pontual, excluir_pasta_pontual,
    inserir_novos_usuarios, redefinir_senha_por_email,
    load_acessos, inserir_acesso, pagina_acessos, opcoes_acessos, iterar_acessos,
    resumo_acessos, ranking_acessos, grafico_acessos, visao_global_acessos,
    resumo_integridade_dashboards, resumo_usuarios_acessos,
    carregar_favoritos, alternar_favorito,
    carregar_aviso, carregar_aviso_atual, carregar_avisos_ativos, carregar_aviso_dashboard,
    salvar_aviso, salvar_aviso_todos, remover_aviso, remover_avisos_todos,
    aviso_pendente, registrar_aviso, acompanhamento_avisos, acompanhamento_avisos_todos,
    resumo_avisos, historico_avisos,
    load_user_events, inserir_user_evento,
    info_foto_usuario, carregar_foto_usuario, salvar_foto_usuario, remover_foto_usuario,
)

from ambientes import (
    INICIAL, contexto_ambiente, listar_ambientes, usuarios_do_ambiente, ambientes_do_usuario,
    ler_ambiente_sessao, selecionar_ambiente_sessao, encerrar_ambiente_sessao,
    salvar_ambiente, definir_ambiente_ativo, excluir_ambiente, alterar_associacoes,
    salvar_imagem_ambiente, remover_imagem_ambiente,
    carregar_imagem_ambiente, IMAGEM_AMBIENTE_MAX_BYTES, IMAGEM_AMBIENTE_MIMES,
)


@app.get("/saude")
def saude():
    """Sonda leve para o proxy/monitor, sem expor dados do portal."""
    try:
        conn = get_connection()
        try:
            with conn.cursor() as cur:
                cur.execute("SELECT 1 AS ok")
                if cur.fetchone()["ok"] != 1:
                    raise RuntimeError("Resposta inválida do banco")
        finally:
            conn.close()
    except Exception:
        app.logger.exception("Sonda de saúde não conseguiu consultar o banco")
        return jsonify(status="indisponivel"), 503
    return jsonify(status="ok"), 200

# O arquivo original pode ser maior porque será redimensionado antes de ser
# gravado. O resultado armazenado no banco continua limitado a 2 MB.
IMAGEM_AMBIENTE_ORIGINAL_MAX_BYTES = 8 * 1024 * 1024
IMAGEM_AMBIENTE_LARGURA = 1024
IMAGEM_AMBIENTE_ALTURA = 447
IMAGEM_AMBIENTE_MARGEM = 28

# O arquivo original pode ter qualquer proporção; para o avatar ele é sempre
# convertido para um JPEG quadrado e leve. Isso mantém a aparência idêntica
# no menu lateral e em Minha conta, sem deformar a foto enviada.
FOTO_USUARIO_ORIGINAL_MAX_BYTES = 5 * 1024 * 1024
FOTO_USUARIO_LADO = 320
FOTO_USUARIO_MIME = "image/jpeg"


@app.errorhandler(ConflitoGravacao)
def conflito_gravacao(erro):
    mensagem = "Os dados foram alterados em outro acesso. Recarregue a página, confira as alterações e tente salvar novamente."
    if request.is_json or request.accept_mimetypes.best == "application/json":
        return jsonify(erro="conflito_gravacao", mensagem=mensagem), 409
    flash(mensagem, "erro")
    retorno = request.referrer or ""
    partes = urlsplit(retorno)
    if partes.netloc != request.host or partes.scheme not in {"http", "https"}:
        retorno = url_for_sessao("index")
    return redirect(retorno, code=303)


def _garantir_tabela_dashboard_bloqueios():
    """Cria a tabela de excecoes de acesso por dashboard.

    A tabela fica separada das permissoes positivas existentes para permitir
    o modelo: Cliente/Divisao/Tema libera por heranca, mas um dashboard
    especifico pode ser bloqueado sem desmontar a permissao superior.
    """
    conn = get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("""
                CREATE TABLE IF NOT EXISTS usuario_dashboard_bloqueios (
                    usuario_id VARCHAR(32) NOT NULL,
                    dashboard_id VARCHAR(32) NOT NULL,
                    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (usuario_id, dashboard_id),
                    INDEX idx_udb_dashboard (dashboard_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
        conn.commit()
    finally:
        conn.close()


def carregar_dashboards_bloqueados(usuario_id):
    if not usuario_id:
        return set()
    cache_key = f"_dash_bloqueados_{usuario_id}"
    if hasattr(g, cache_key):
        return set(getattr(g, cache_key))
    conn = get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT dashboard_id FROM usuario_dashboard_bloqueios WHERE usuario_id = %s",
                (usuario_id,),
            )
            ids = {row["dashboard_id"] for row in cur.fetchall()}
    finally:
        conn.close()
    setattr(g, cache_key, set(ids))
    return ids


def salvar_dashboards_bloqueados(usuario_id, dashboard_ids):
    ids = sorted({str(x).strip() for x in dashboard_ids if str(x).strip()})
    conn = get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(
                "DELETE FROM usuario_dashboard_bloqueios WHERE usuario_id = %s",
                (usuario_id,),
            )
            if ids:
                cur.executemany(
                    "INSERT INTO usuario_dashboard_bloqueios (usuario_id, dashboard_id) VALUES (%s, %s)",
                    [(usuario_id, dash_id) for dash_id in ids],
                )
        conn.commit()
    finally:
        conn.close()
    cache_key = f"_dash_bloqueados_{usuario_id}"
    if hasattr(g, cache_key):
        delattr(g, cache_key)


def remover_bloqueios_dashboard(dashboard_ids):
    ids = sorted({str(x).strip() for x in dashboard_ids if str(x).strip()})
    if not ids:
        return
    conn = get_connection()
    try:
        with conn.cursor() as cur:
            placeholders = ",".join(["%s"] * len(ids))
            cur.execute(
                f"DELETE FROM usuario_dashboard_bloqueios WHERE dashboard_id IN ({placeholders})",
                ids,
            )
        conn.commit()
    finally:
        conn.close()


def remover_bloqueios_usuario(usuario_id):
    conn = get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(
                "DELETE FROM usuario_dashboard_bloqueios WHERE usuario_id = %s",
                (usuario_id,),
            )
        conn.commit()
    finally:
        conn.close()


def _garantir_tabela_subpasta_bloqueios():
    """Cria exceções negativas de acesso para Divisão/Tema/Subnível."""
    conn = get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("""
                CREATE TABLE IF NOT EXISTS usuario_subpasta_bloqueios (
                    usuario_id VARCHAR(32) NOT NULL,
                    subpasta_id VARCHAR(32) NOT NULL,
                    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (usuario_id, subpasta_id),
                    INDEX idx_usb_subpasta (subpasta_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
        conn.commit()
    finally:
        conn.close()


def carregar_subpastas_bloqueadas(usuario_id):
    if not usuario_id:
        return set()
    cache_key = f"_subpastas_bloqueadas_{usuario_id}"
    if hasattr(g, cache_key):
        return set(getattr(g, cache_key))
    conn = get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT subpasta_id FROM usuario_subpasta_bloqueios WHERE usuario_id = %s",
                (usuario_id,),
            )
            ids = {row["subpasta_id"] for row in cur.fetchall()}
    finally:
        conn.close()
    setattr(g, cache_key, set(ids))
    return ids


def salvar_subpastas_bloqueadas(usuario_id, subpasta_ids):
    ids = sorted({str(x).strip() for x in subpasta_ids if str(x).strip()})
    conn = get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(
                "DELETE FROM usuario_subpasta_bloqueios WHERE usuario_id = %s",
                (usuario_id,),
            )
            if ids:
                cur.executemany(
                    "INSERT INTO usuario_subpasta_bloqueios (usuario_id, subpasta_id) VALUES (%s, %s)",
                    [(usuario_id, subpasta_id) for subpasta_id in ids],
                )
        conn.commit()
    finally:
        conn.close()
    cache_key = f"_subpastas_bloqueadas_{usuario_id}"
    if hasattr(g, cache_key):
        delattr(g, cache_key)


def remover_bloqueios_subpasta(subpasta_ids):
    ids = sorted({str(x).strip() for x in subpasta_ids if str(x).strip()})
    if not ids:
        return
    conn = get_connection()
    try:
        with conn.cursor() as cur:
            placeholders = ",".join(["%s"] * len(ids))
            cur.execute(
                f"DELETE FROM usuario_subpasta_bloqueios WHERE subpasta_id IN ({placeholders})",
                ids,
            )
        conn.commit()
    finally:
        conn.close()


def remover_bloqueios_subpasta_usuario(usuario_id):
    conn = get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(
                "DELETE FROM usuario_subpasta_bloqueios WHERE usuario_id = %s",
                (usuario_id,),
            )
        conn.commit()
    finally:
        conn.close()


def _garantir_tabela_estado_permissoes():
    """Registra se o padrão inicial de permissões já foi resolvido.

    Isso permite migrar Visualizadores antigos que nunca tiveram permissões
    configuradas sem reativar o acesso total depois que o administrador
    deliberadamente usar "Limpar seleções".
    """
    conn = get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("""
                CREATE TABLE IF NOT EXISTS usuario_permissoes_estado (
                    usuario_id VARCHAR(32) NOT NULL,
                    inicializado TINYINT(1) NOT NULL DEFAULT 1,
                    atualizado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    PRIMARY KEY (usuario_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
        conn.commit()
    finally:
        conn.close()


def permissoes_inicializadas(usuario_id):
    if not usuario_id:
        return False
    conn = get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT inicializado FROM usuario_permissoes_estado WHERE usuario_id = %s",
                (usuario_id,),
            )
            row = cur.fetchone()
            return bool(row and row.get("inicializado"))
    finally:
        conn.close()


def marcar_permissoes_inicializadas(usuario_id):
    if not usuario_id:
        return
    conn = get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("""
                INSERT INTO usuario_permissoes_estado (usuario_id, inicializado)
                VALUES (%s, 1)
                ON DUPLICATE KEY UPDATE inicializado = 1
            """, (usuario_id,))
        conn.commit()
    finally:
        conn.close()


def remover_estado_permissoes(usuario_id):
    if not usuario_id:
        return
    conn = get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(
                "DELETE FROM usuario_permissoes_estado WHERE usuario_id = %s",
                (usuario_id,),
            )
        conn.commit()
    finally:
        conn.close()




def _garantir_tabela_migracoes_portal():
    """Controle simples de migrações únicas do portal."""
    conn = get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("""
                CREATE TABLE IF NOT EXISTS portal_migracoes (
                    chave VARCHAR(120) NOT NULL,
                    executada_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (chave)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            """)
        conn.commit()
    finally:
        conn.close()


def _migracao_portal_concluida(chave):
    conn = get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute("SELECT chave FROM portal_migracoes WHERE chave = %s", (chave,))
            return cur.fetchone() is not None
    finally:
        conn.close()


def _marcar_migracao_portal_concluida(chave):
    conn = get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(
                "INSERT IGNORE INTO portal_migracoes (chave) VALUES (%s)",
                (chave,),
            )
        conn.commit()
    finally:
        conn.close()


def migrar_todos_visualizadores_para_acesso_total():
    """Aplica uma única vez o novo padrão a TODOS os Visualizadores existentes.

    A migração redefine os usuários atualmente cadastrados como ``viewer`` para
    todos os Clientes/Pastas. Depois de concluída, não roda novamente e, portanto,
    as personalizações feitas pelo administrador após esta versão são preservadas.
    """
    chave = "viewer_todos_clientes_v2"
    if _migracao_portal_concluida(chave):
        return False

    data = load_data()
    pasta_ids = [p.get("id") for p in data.get("pastas", []) if p.get("id")]
    usuarios = load_users()
    visualizadores = [u for u in usuarios if u.get("papel") == "viewer" and u.get("id")]

    for u in visualizadores:
        u["pastas"] = list(pasta_ids)
        u["subpastas"] = []
        u["dashboards"] = []

    if visualizadores:
        save_users(usuarios)
        for u in visualizadores:
            salvar_dashboards_bloqueados(u["id"], [])
            salvar_subpastas_bloqueadas(u["id"], [])
            marcar_permissoes_inicializadas(u["id"])

    _marcar_migracao_portal_concluida(chave)
    return bool(visualizadores)

def aplicar_padrao_visualizador_se_necessario(usuario, usuarios=None):
    """Aplica acesso total somente uma vez a Visualizadores sem histórico.

    Visualizadores antigos com alguma permissão positiva ou exceção já
    configurada são preservados. Se não houver configuração alguma, todos os
    Clientes passam a ser selecionados, reproduzindo o padrão da interface.
    """
    if not usuario or usuario.get("papel") != "viewer" or not usuario.get("id"):
        return False
    if permissoes_inicializadas(usuario["id"]):
        return False

    tem_configuracao = bool(
        usuario.get("pastas")
        or usuario.get("subpastas")
        or usuario.get("dashboards")
        or carregar_dashboards_bloqueados(usuario["id"])
        or carregar_subpastas_bloqueadas(usuario["id"])
    )
    if tem_configuracao:
        marcar_permissoes_inicializadas(usuario["id"])
        return False

    data = load_data()
    permitidos = ambientes_do_usuario(usuario["id"])
    usuario["pastas"] = [p["id"] for p in data.get("pastas", []) if p.get("ambiente_id", "inicial") in permitidos]
    usuario["subpastas"] = []
    usuario["dashboards"] = []
    if usuarios is None:
        usuarios = load_users()
    alvo = next((u for u in usuarios if u.get("id") == usuario.get("id")), None)
    if alvo is not None and alvo is not usuario:
        alvo["pastas"] = list(usuario["pastas"])
        alvo["subpastas"] = []
        alvo["dashboards"] = []
    save_users(usuarios)
    salvar_dashboards_bloqueados(usuario["id"], [])
    salvar_subpastas_bloqueadas(usuario["id"], [])
    marcar_permissoes_inicializadas(usuario["id"])
    return True


_garantir_tabela_dashboard_bloqueios()
_garantir_tabela_subpasta_bloqueios()
_garantir_tabela_estado_permissoes()
_garantir_tabela_migracoes_portal()

# A migração usa helpers que consultam/invalidam cache em ``flask.g``.
# Durante a importação do módulo ainda não existe um contexto de aplicação
# ativo, portanto executamos a migração explicitamente dentro dele.
with app.app_context():
    migrar_todos_visualizadores_para_acesso_total()


def _subpasta_ancestrais(subpasta_id, sub_por_id):
    """Retorna os ids ancestrais de uma subpasta, do pai ate a raiz."""
    ancestrais = []
    atual = subpasta_id
    vistos = set()
    while atual and atual not in vistos:
        vistos.add(atual)
        sp = sub_por_id.get(atual)
        if not sp:
            break
        pai = sp.get("parent_subpasta_id") or None
        if not pai:
            break
        ancestrais.append(pai)
        atual = pai
    return ancestrais


def _subpasta_nivel(subpasta_id, sub_por_id):
    """Nivel da subpasta: 1=Divisao, 2=Tema, 3=Subnivel."""
    if not subpasta_id or subpasta_id not in sub_por_id:
        return 0
    return 1 + len(_subpasta_ancestrais(subpasta_id, sub_por_id))


def agrupar(data):
    """Organiza em Pasta -> Divisao -> Tema -> Subnivel -> Dashboard.

    A estrutura mantem as chaves antigas (``subpastas`` e ``temas``) para
    compatibilidade, acrescentando ``subniveis`` dentro de cada Tema.
    """
    grupos = []
    todas_subpastas = data.get("subpastas", [])

    for p in data["pastas"]:
        itens = sorted(
            [d for d in data["dashboards"] if d.get("pasta_id") == p["id"]],
            key=lambda d: (int(d.get("ordem_exibicao", 0) or 0), str(d.get("criado_em") or ""), d.get("nome", "").lower()),
        )
        subs_pasta = [sp for sp in todas_subpastas if sp.get("pasta_id") == p["id"]]
        por_id = {sp["id"]: sp for sp in subs_pasta}

        divisoes = [
            sp for sp in subs_pasta
            if not sp.get("parent_subpasta_id") or sp.get("parent_subpasta_id") not in por_id
        ]
        ids_subs_validas = set(por_id)
        dashboards_raiz = [
            d for d in itens
            if not d.get("subpasta_id") or d.get("subpasta_id") not in ids_subs_validas
        ]

        grupos_divisoes = []
        for divisao in divisoes:
            temas = [sp for sp in subs_pasta if sp.get("parent_subpasta_id") == divisao["id"]]
            dashboards_divisao = [d for d in itens if d.get("subpasta_id") == divisao["id"]]
            grupos_temas = []
            dashboards_temas = []

            for tema in temas:
                subniveis = [sp for sp in subs_pasta if sp.get("parent_subpasta_id") == tema["id"]]
                dashboards_tema_diretos = [d for d in itens if d.get("subpasta_id") == tema["id"]]
                grupos_subniveis = []
                dashboards_subniveis = []
                for subnivel in subniveis:
                    dashes_subnivel = [d for d in itens if d.get("subpasta_id") == subnivel["id"]]
                    dashboards_subniveis.extend(dashes_subnivel)
                    grupos_subniveis.append({"subnivel": subnivel, "dashboards": dashes_subnivel})

                todos_tema = dashboards_tema_diretos + dashboards_subniveis
                dashboards_temas.extend(todos_tema)
                grupos_temas.append({
                    "tema": tema,
                    "dashboards": todos_tema,
                    "dashboards_diretos": dashboards_tema_diretos,
                    "subniveis": grupos_subniveis,
                })

            grupos_divisoes.append({
                "subpasta": divisao,
                "dashboards": dashboards_divisao + dashboards_temas,
                "dashboards_diretos": dashboards_divisao,
                "temas": grupos_temas,
            })

        grupos.append({
            "pasta": p,
            "dashboards": itens,
            "dashboards_raiz": dashboards_raiz,
            "subpastas": grupos_divisoes,
        })
    return grupos


def _agrupar_arvore_por_ambiente(grupos, data=None, ambientes_override=None, ignorar_contexto=False):
    """Envolve a árvore da sidebar com o ambiente ao qual ela pertence.

    O Master pode navegar em ``Todos os ambientes``. Nesse contexto, uma
    árvore única deixa pastas e dashboards com o mesmo nome indistinguíveis.
    Cada nó retornado aqui representa um ambiente e mantém a hierarquia já
    montada por :func:`agrupar` (pasta -> subpasta -> dashboard) intacta.

    ``load_data`` já recorta pastas, subpastas e dashboards quando o Master
    escolhe um ambiente específico. O filtro abaixo é repetido de forma
    defensiva para que uma eventual linha legada não apareça no ramo errado.
    Dashboards sem pasta, permitidos apenas no Ambiente inicial, são exibidos
    diretamente dentro do respectivo ambiente.
    """
    contexto = None if ignorar_contexto else contexto_ambiente()
    disponiveis = list(ambientes_override) if ambientes_override is not None else listar_ambientes()
    if contexto:
        disponiveis = [a for a in disponiveis if a.get("id") == contexto]

    ambientes = {a["id"]: dict(a) for a in disponiveis if a.get("id")}
    grupos_por_ambiente = {aid: [] for aid in ambientes}
    dashboards_sem_pasta = {aid: [] for aid in ambientes}

    def garantir_ambiente(ambiente_id):
        ambiente_id = ambiente_id or INICIAL
        if contexto and ambiente_id != contexto:
            return None
        if ambiente_id not in ambientes:
            # Preserva estruturas antigas cujo ambiente foi removido ou ainda
            # não apareceu na tabela de ambientes, sem misturá-las a outro
            # cliente. O Master poderá identificá-las e corrigi-las.
            ambientes[ambiente_id] = {
                "id": ambiente_id,
                "nome": "Ambiente inicial" if ambiente_id == INICIAL else ambiente_id,
                "ativo": 1,
            }
            grupos_por_ambiente[ambiente_id] = []
            dashboards_sem_pasta[ambiente_id] = []
        return ambiente_id

    for grupo in grupos:
        pasta = grupo.get("pasta") or {}
        aid = garantir_ambiente(pasta.get("ambiente_id") or INICIAL)
        if aid is not None:
            grupos_por_ambiente[aid].append(grupo)

    if data:
        ids_pastas = {p.get("id") for p in data.get("pastas", [])}
        for dash in data.get("dashboards", []):
            # A árvore pública nunca exibe dashboards inativos. Os itens
            # inativos continuam acessíveis apenas nas telas administrativas.
            if not bool(dash.get("ativo", True)):
                continue
            pasta_id = dash.get("pasta_id")
            if pasta_id and pasta_id in ids_pastas:
                continue
            aid = garantir_ambiente(dash.get("ambiente_id") or INICIAL)
            if aid is not None:
                dashboards_sem_pasta[aid].append(dash)

    resultado = []
    for aid, ambiente in sorted(
        ambientes.items(),
        key=lambda par: (str(par[1].get("nome", "")).casefold(), par[0]),
    ):
        sem_pasta = sorted(
            dashboards_sem_pasta.get(aid, []),
            key=lambda d: (str(d.get("nome", "")).casefold(), d.get("id", "")),
        )
        grupos_ambiente = grupos_por_ambiente.get(aid, [])
        total = sum(len(g.get("dashboards", [])) for g in grupos_ambiente) + len(sem_pasta)
        resultado.append({
            "id": aid,
            "nome": ambiente.get("nome") or aid,
            "ativo": bool(ambiente.get("ativo", True)),
            "grupos": grupos_ambiente,
            "dashboards_sem_pasta": sem_pasta,
            "total": total,
        })
    return resultado


def _caminho_subpasta(subpasta_id, sub_por_id, pasta_nome_por_id=None):
    """Retorna a cadeia de nomes da raiz ate a subpasta informada."""
    if not subpasta_id or subpasta_id not in sub_por_id:
        return []
    nomes = []
    atual = sub_por_id.get(subpasta_id)
    limite = 0
    while atual and limite < 10:
        nomes.append(atual.get("nome", ""))
        pai = atual.get("parent_subpasta_id") or None
        atual = sub_por_id.get(pai) if pai else None
        limite += 1
    nomes.reverse()
    return nomes


def _dashboard_admin_context(data, dash, usuarios_por_id=None):
    """Enriquece um dashboard com caminho e ids de cada nivel para a tela admin."""
    if not dash:
        return None
    item = dict(dash)
    pasta_por_id = {p["id"]: p for p in data.get("pastas", [])}
    sub_por_id = {sp["id"]: sp for sp in data.get("subpastas", [])}
    pasta = pasta_por_id.get(dash.get("pasta_id"))
    item["pasta_nome"] = pasta.get("nome") if pasta else "Sem pasta"
    item["ambiente_id"] = dash.get("ambiente_id") or (pasta.get("ambiente_id") if pasta else INICIAL)
    item["divisao_id"] = ""
    item["tema_id"] = ""
    item["subnivel_id"] = ""

    sub_id = dash.get("subpasta_id") or None
    if sub_id and sub_id in sub_por_id:
        nivel = _subpasta_nivel(sub_id, sub_por_id)
        atual = sub_por_id[sub_id]
        if nivel == 1:
            item["divisao_id"] = sub_id
        elif nivel == 2:
            item["tema_id"] = sub_id
            item["divisao_id"] = atual.get("parent_subpasta_id") or ""
        elif nivel >= 3:
            item["subnivel_id"] = sub_id
            tema = sub_por_id.get(atual.get("parent_subpasta_id"))
            if tema:
                item["tema_id"] = tema["id"]
                item["divisao_id"] = tema.get("parent_subpasta_id") or ""

    caminho = [item["pasta_nome"]]
    caminho.extend(_caminho_subpasta(sub_id, sub_por_id))
    item["hierarquia"] = caminho
    item["hierarquia_texto"] = " › ".join([x for x in caminho if x])
    autor = (usuarios_por_id or {}).get(dash.get("cadastrado_por"))
    item["cadastrado_por_nome"] = autor.get("nome") if autor else ""
    item["cadastrado_por_login"] = autor.get("usuario") if autor else ""
    item["cadastrado_por_papel"] = nome_perfil(autor.get("papel")) if autor else ""
    return item


def _dashboard_admin_integridade(data, dashboards_admin, acessos=None, usuarios=None, resumo_acessos=None):
    """Calcula indicadores de integridade sem alterar os dados persistidos.

    A tela de administracao precisa destacar problemas acionaveis, mas os
    dados existentes nao possuem uma tabela de auditoria de edicoes. Por isso
    esta funcao usa somente cadastro, estrutura, link, status e acessos
    registrados, mantendo o diagnostico rastreavel ao banco atual.
    """
    agora = datetime.now()
    limite_90d = agora - timedelta(days=90)
    limite_30d = agora - timedelta(days=30)
    pasta_ids = {p.get("id") for p in data.get("pastas", [])}
    usuarios = usuarios or []
    acessos = acessos or []
    resumo_acessos = resumo_acessos or {}

    def converter_data(valor):
        if isinstance(valor, datetime):
            return valor
        try:
            return datetime.strptime(str(valor), "%Y-%m-%d %H:%M:%S")
        except (TypeError, ValueError):
            return None

    def exibir_data(valor):
        dt = converter_data(valor)
        return dt.strftime("%d/%m/%Y %H:%M") if dt else (str(valor) if valor else "—")

    acessos_por_dashboard = {}
    if not resumo_acessos:
        for acesso in acessos:
            if acesso.get("status", "sucesso") != "sucesso":
                continue
            dashboard_id = acesso.get("dashboard_id")
            if not dashboard_id:
                continue
            dt = converter_data(acesso.get("data_hora"))
            acessos_por_dashboard.setdefault(dashboard_id, []).append((dt, acesso))

    nomes = {}
    for dash in dashboards_admin:
        nome = (dash.get("nome") or "").strip().casefold()
        if nome:
            nomes.setdefault(nome, []).append(dash)

    duplicados = set()
    for itens in nomes.values():
        if len(itens) > 1:
            duplicados.update(item.get("id") for item in itens)

    for dash in dashboards_admin:
        dashboard_id = dash.get("id")
        if resumo_acessos:
            agregado = resumo_acessos.get(dashboard_id, {})
            ultimo_acesso = converter_data(agregado.get("ultimo_acesso"))
            acessos_30d = int(agregado.get("acessos_30d") or 0)
            acessos_total = int(agregado.get("acessos_total") or 0)
        else:
            registros = acessos_por_dashboard.get(dashboard_id, [])
            datas = [dt for dt, _ in registros if dt]
            ultimo_acesso = max(datas) if datas else None
            acessos_30d = sum(1 for dt in datas if dt >= limite_30d)
            acessos_total = len(registros)
        sem_localizacao = not dash.get("pasta_id") or dash.get("pasta_id") not in pasta_ids
        sem_acesso_90d = ultimo_acesso is None or ultimo_acesso < limite_90d
        link_valido = (dash.get("embed_url") or "").startswith("https://app.powerbi.com/")

        motivos = []
        if not dash.get("ativo", True):
            motivos.append("Dashboard inativo")
        if sem_localizacao:
            motivos.append("Sem pasta ou localização")
        if not link_valido:
            motivos.append("Link do Power BI inválido")
        if dashboard_id in duplicados:
            motivos.append("Nome duplicado")
        if sem_acesso_90d:
            motivos.append("Nunca acessado" if ultimo_acesso is None else "Sem acesso há mais de 90 dias")

        usuarios_com_permissao = sum(
            1 for usuario in usuarios if dashboard_id in (usuario.get("dashboards") or [])
        )
        dash["integridade"] = {
            "atencao": bool(motivos),
            "motivos": motivos,
            "resumo": " · ".join(motivos) if motivos else "Nenhuma pendência encontrada",
            "sem_localizacao": sem_localizacao,
            "sem_acesso_90d": sem_acesso_90d,
            "acessos_total": acessos_total,
            "acessos_30d": acessos_30d,
            "ultimo_acesso": exibir_data(ultimo_acesso),
            "criado_em": exibir_data(dash.get("criado_em")),
            "usuarios_com_permissao": usuarios_com_permissao,
        }


def _dashboards_admin_por_ambiente(data, grupos, dashboards_admin):
    """Organiza a árvore administrativa completa do Master por ambiente.

    A lista de dashboards continua sendo a fonte do total: pastas/subpastas
    sem dashboards também são exibidas para preservar a estrutura, enquanto
    cada dashboard aparece uma única vez dentro do ambiente da sua pasta.
    A tela possui um filtro próprio por ambiente; por isso, a árvore deve
    carregar todos os ambientes, independentemente do contexto global que o
    Master tenha selecionado em outra tela.
    """
    ambientes_disponiveis_admin = listar_ambientes()
    ambientes = {a["id"]: dict(a) for a in ambientes_disponiveis_admin}
    grupos_por_ambiente = {aid: [] for aid in ambientes}
    dashboards_por_ambiente = {aid: [] for aid in ambientes}
    for grupo in grupos:
        aid = grupo.get("pasta", {}).get("ambiente_id") or INICIAL
        if aid not in grupos_por_ambiente:
            ambientes[aid] = {"id": aid, "nome": aid, "ativo": 1}
            grupos_por_ambiente[aid] = []
            dashboards_por_ambiente[aid] = []
        grupos_por_ambiente[aid].append(grupo)
    for dash in dashboards_admin:
        aid = dash.get("ambiente_id") or INICIAL
        if aid not in dashboards_por_ambiente:
            ambientes[aid] = {"id": aid, "nome": aid, "ativo": 1}
            grupos_por_ambiente[aid] = []
            dashboards_por_ambiente[aid] = []
        dashboards_por_ambiente[aid].append(dash)
    resultado = []
    for aid, ambiente in sorted(ambientes.items(), key=lambda par: (str(par[1].get("nome", "")).casefold(), par[0])):
        pastas_ids = {g.get("pasta", {}).get("id") for g in grupos_por_ambiente[aid]}
        sem_pasta = [d for d in dashboards_por_ambiente[aid] if not d.get("pasta_id") or d.get("pasta_id") not in pastas_ids]
        resultado.append({
            "id": aid,
            "nome": ambiente.get("nome") or aid,
            "ativo": bool(ambiente.get("ativo", True)),
            "grupos": grupos_por_ambiente[aid],
            "dashboards_sem_pasta": sorted(sem_pasta, key=lambda d: (d.get("nome", "").casefold(), d.get("id", ""))),
            "total": len(dashboards_por_ambiente[aid]),
        })
    return resultado


def _descendentes_subpasta(subpasta_id, subpastas):
    """Retorna ids da subpasta e de todos os seus descendentes."""
    ids = {subpasta_id}
    mudou = True
    while mudou:
        mudou = False
        for sp in subpastas:
            if sp["id"] not in ids and sp.get("parent_subpasta_id") in ids:
                ids.add(sp["id"])
                mudou = True
    return ids


def _estrutura_admin_context(data, token=None):
    """Contexto da estrutura selecionada na Administracao de Dashboards."""
    pastas = data.get("pastas", [])
    subpastas = data.get("subpastas", [])
    dashboards = data.get("dashboards", [])
    pasta_por_id = {p["id"]: p for p in pastas}
    sub_por_id = {sp["id"]: sp for sp in subpastas}

    tipo = None
    item_id = None
    if token and ":" in token:
        tipo, item_id = token.split(":", 1)
    if tipo == "p" and item_id not in pasta_por_id:
        tipo = item_id = None
    if tipo == "s" and item_id not in sub_por_id:
        tipo = item_id = None
    if not tipo:
        if pastas:
            tipo, item_id = "p", pastas[0]["id"]
        elif subpastas:
            tipo, item_id = "s", subpastas[0]["id"]
        else:
            return None

    if tipo == "p":
        pasta = pasta_por_id[item_id]
        children = [sp for sp in subpastas if sp.get("pasta_id") == item_id and not sp.get("parent_subpasta_id")]
        direct_dashes = [d for d in dashboards if d.get("pasta_id") == item_id and not d.get("subpasta_id")]
        all_sub_ids = {sp["id"] for sp in subpastas if sp.get("pasta_id") == item_id}
        all_dashes = [d for d in dashboards if d.get("pasta_id") == item_id]
        return {
            "token": f"p:{item_id}", "tipo": "pasta", "id": item_id,
            "nome": pasta.get("nome", ""), "nivel": 0, "nivel_nome": "Cliente / Pasta",
            "pasta_id": item_id, "parent_id": None,
            "breadcrumb": [pasta.get("nome", "")],
            "children": children, "dashboards_diretos": direct_dashes,
            "total_subpastas": len(all_sub_ids), "total_dashboards": len(all_dashes),
            "destinos": [],
        }

    sp = sub_por_id[item_id]
    nivel = _subpasta_nivel(item_id, sub_por_id)
    pasta = pasta_por_id.get(sp.get("pasta_id"))
    filhos = [x for x in subpastas if x.get("parent_subpasta_id") == item_id]
    direct_dashes = [d for d in dashboards if d.get("subpasta_id") == item_id]
    subtree_ids = _descendentes_subpasta(item_id, subpastas)
    all_dashes = [d for d in dashboards if d.get("subpasta_id") in subtree_ids]
    breadcrumb = [pasta.get("nome", "") if pasta else "Sem pasta"] + _caminho_subpasta(item_id, sub_por_id)

    destinos = []
    if nivel == 1:
        for p in pastas:
            destinos.append({"token": f"p:{p['id']}", "label": p.get("nome", ""), "pasta_id": p["id"]})
    elif nivel == 2:
        for cand in subpastas:
            if _subpasta_nivel(cand["id"], sub_por_id) == 1:
                p = pasta_por_id.get(cand.get("pasta_id"))
                destinos.append({
                    "token": f"s:{cand['id']}",
                    "label": " › ".join([p.get("nome", "") if p else "", cand.get("nome", "")]),
                    "pasta_id": cand.get("pasta_id"),
                })
    elif nivel == 3:
        for cand in subpastas:
            if _subpasta_nivel(cand["id"], sub_por_id) == 2:
                p = pasta_por_id.get(cand.get("pasta_id"))
                caminho = [p.get("nome", "") if p else ""] + _caminho_subpasta(cand["id"], sub_por_id)
                destinos.append({"token": f"s:{cand['id']}", "label": " › ".join(caminho), "pasta_id": cand.get("pasta_id")})

    current_parent_token = f"s:{sp.get('parent_subpasta_id')}" if sp.get("parent_subpasta_id") else f"p:{sp.get('pasta_id')}"
    nivel_nome = {1: "Divisão", 2: "Tema", 3: "Subnível"}.get(nivel, "Subpasta")
    return {
        "token": f"s:{item_id}", "tipo": "subpasta", "id": item_id,
        "nome": sp.get("nome", ""), "nivel": nivel, "nivel_nome": nivel_nome,
        "pasta_id": sp.get("pasta_id"), "parent_id": sp.get("parent_subpasta_id"),
        "breadcrumb": breadcrumb, "children": filhos, "dashboards_diretos": direct_dashes,
        "total_subpastas": max(0, len(subtree_ids) - 1), "total_dashboards": len(all_dashes),
        "destinos": destinos, "current_parent_token": current_parent_token,
    }


def _acoes_estrutura_admin(usuario, data, estrutura):
    """Informa quais ações estruturais podem aparecer para o Administrador.

    Pastas ancestrais podem ser visíveis apenas para compor o caminho de um
    dashboard liberado. Elas não devem receber ações de escrita sem a
    permissão correspondente do Master.
    """
    resultado = {"editar": False, "mover": False, "excluir": False}
    if not usuario or not estrutura:
        return resultado
    if eh_master(usuario):
        return {"editar": True, "mover": estrutura.get("tipo") == "subpasta", "excluir": True}
    if usuario.get("papel") != "admin":
        return resultado

    pastas_permitidas = set(usuario.get("pastas", []))
    subpastas_permitidas = _ids_subpastas_permitidas(usuario, data)
    dashboards_permitidos = _ids_dashboards_permitidos(usuario, data)
    subpastas = data.get("subpastas", [])

    def subarvore_permitida(subpasta_id):
        ids = _descendentes_subpasta(subpasta_id, subpastas)
        return (subpasta_id in subpastas_permitidas and ids <= subpastas_permitidas
                and all(d.get("id") in dashboards_permitidos for d in data.get("dashboards", [])
                        if d.get("subpasta_id") in ids))

    if estrutura.get("tipo") == "pasta":
        pasta_id = estrutura.get("id")
        pode_editar = pasta_id in pastas_permitidas
        pode_excluir = (pode_editar
                         and all(sp.get("id") in subpastas_permitidas for sp in subpastas
                                 if sp.get("pasta_id") == pasta_id)
                         and all(d.get("id") in dashboards_permitidos for d in data.get("dashboards", [])
                                 if d.get("pasta_id") == pasta_id))
        return {"editar": pode_editar, "mover": False, "excluir": pode_excluir}

    subpasta_id = estrutura.get("id")
    pode_editar = subpasta_id in subpastas_permitidas
    subarvore_ok = subarvore_permitida(subpasta_id)
    pai_id = estrutura.get("parent_id")
    destino_permitido = (pai_id in subpastas_permitidas if pai_id else estrutura.get("pasta_id") in pastas_permitidas)
    return {"editar": pode_editar, "mover": subarvore_ok, "excluir": subarvore_ok and destino_permitido}


# ===========================================================================
# Usuarios (funcoes de consulta, a persistencia em si esta em db.py)
# ===========================================================================
def get_user(uid):
    return next((u for u in load_users() if u["id"] == uid), None)


def get_user_by_login(usuario):
    usuario = usuario.lower()
    return next((u for u in load_users() if u["usuario"].lower() == usuario), None)


def get_user_by_email(email):
    """Retorna uma conta apenas quando o e-mail identifica um único usuário.

    Instalações antigas podem ter registros sem e-mail ou duplicados. Neste
    último caso não enviamos link para ninguém, evitando que uma redefinição
    alcance a conta errada até o Master corrigir os dados.
    """
    alvo = (email or "").strip().casefold()
    encontrados = [
        u for u in load_users()
        if isinstance(u.get("email"), str) and u["email"].strip().casefold() == alvo
    ]
    return encontrados[0] if len(encontrados) == 1 else None


def total_admins(users):
    return sum(1 for u in users if u["papel"] in {"admin", "master"})


# ===========================================================================
# Registro de acessos (auditoria)
# ===========================================================================
def registrar_acesso(usuario, dash, pasta_nome, status="sucesso"):
    """Grava um registro de auditoria: quem tentou acessar qual dashboard,
    quando, de qual IP, e se o acesso foi permitido ('sucesso') ou
    bloqueado por falta de permissao ('negado'). O historico e preservado
    integralmente, sem exclusao automatica por idade dos registros."""
    inserir_acesso({
        "id": uuid.uuid4().hex,
        "data_hora": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "usuario_id": usuario["id"],
        "usuario_nome": usuario["nome"],
        "usuario_login": usuario["usuario"],
        "usuario_papel": usuario["papel"],
        "dashboard_id": dash["id"],
        "dashboard_nome": dash["nome"],
        "pasta_nome": pasta_nome,
        "status": status,
        "ip": request.remote_addr or "—",
    })


def formatar_data_hora(valor):
    """Converte 'AAAA-MM-DD HH:MM:SS' (formato interno, ordenavel) para o
    formato brasileiro 'DD/MM/AAAA HH:MM:SS' usado na exibicao."""
    try:
        return datetime.strptime(valor, "%Y-%m-%d %H:%M:%S").strftime("%d/%m/%Y %H:%M:%S")
    except (ValueError, TypeError):
        return valor


# Regra de senha forte: >=6 caracteres, com maiuscula, numero e especial
SENHA_REGRA = "A senha deve ter pelo menos 6 caracteres, incluindo 1 letra maiúscula, 1 número e 1 caractere especial."
SENHA_INICIAL = "Novo@123"


def senha_valida(senha):
    if len(senha) < 6:
        return False
    tem_maiuscula = any(c.isupper() for c in senha)
    tem_numero = any(c.isdigit() for c in senha)
    tem_especial = any(not c.isalnum() for c in senha)
    return tem_maiuscula and tem_numero and tem_especial


def get_estado_paineis():
    """Le preferencias antigas na primeira abertura. O navegador migra os
    cookies det_* para localStorage e passa a restaurar o estado localmente."""
    estado = {}
    for nome, valor in request.cookies.items():
        if nome.startswith("det_"):
            estado[nome[4:]] = (valor == "1")
    return estado


# ===========================================================================
# Autenticacao / permissoes
# ===========================================================================
#
# MULTIPLAS SESSOES NO MESMO NAVEGADOR
# -------------------------------------
# O cookie padrao do Flask e compartilhado entre todas as abas do mesmo
# navegador. Por isso, guardar o UID diretamente em ``session`` fazia um
# segundo login substituir o primeiro.
#
# Agora cada login recebe um identificador de contexto (``sessao``) que fica
# apenas na URL. O dado de autenticacao continua protegido em cookie HttpOnly,
# mas cada contexto usa um cookie diferente: portal_auth_<sessao>. Assim duas
# abas podem manter usuarios diferentes, inclusive dois visualizadores.
_AUTH_COOKIE_PREFIX = "portal_auth_"
_AUTH_SLOT_RE = re.compile(r"^[A-Za-z0-9_-]{12,32}$")
_AUTH_MAX_AGE = _INATIVIDADE_MINUTOS * 60
_AUTH_SERIALIZER = URLSafeTimedSerializer(app.secret_key, salt="portal-bi-multisessao-v1")
_RECUPERACAO_SERIALIZER = URLSafeTimedSerializer(
    app.secret_key, salt="portal-bi-recuperacao-email-v1"
)


def _versao_redefinicao(valor):
    """Não coloca hash de senha ou e-mail em texto no token assinado."""
    return hashlib.sha256((valor or "").encode("utf-8")).hexdigest()


def _gerar_token_redefinicao(usuario):
    email = usuario.get("email")
    if not isinstance(email, str) or not email.strip():
        raise ValueError("A conta não possui um e-mail cadastrado.")
    # O identificador aleatório torna cada solicitação distinta. A versão da
    # senha e do e-mail torna o link inutilizável depois de uma alteração.
    return _RECUPERACAO_SERIALIZER.dumps({
        "uid": usuario["id"],
        "jti": uuid.uuid4().hex,
        "senha_versao": _versao_redefinicao(usuario.get("senha_hash")),
        "email_versao": _versao_redefinicao(email.strip().casefold()),
    })


def _usuario_do_token_redefinicao(token):
    try:
        dados = _RECUPERACAO_SERIALIZER.loads(
            token, max_age=_RECUPERACAO_SENHA_MINUTOS * 60
        )
    except (BadSignature, SignatureExpired):
        return None
    if not isinstance(dados, dict) or not isinstance(dados.get("uid"), str):
        return None
    if not isinstance(dados.get("jti"), str) or not re.fullmatch(r"[0-9a-f]{32}", dados["jti"]):
        return None
    usuario = get_user(dados["uid"])
    if not usuario or not isinstance(usuario.get("email"), str) or not usuario["email"].strip():
        return None
    senha_atual = _versao_redefinicao(usuario.get("senha_hash"))
    email_atual = _versao_redefinicao(usuario["email"].strip().casefold())
    if not (
        isinstance(dados.get("senha_versao"), str)
        and isinstance(dados.get("email_versao"), str)
        and hmac.compare_digest(dados["senha_versao"], senha_atual)
        and hmac.compare_digest(dados["email_versao"], email_atual)
    ):
        return None
    return usuario


def _url_redefinicao_publica(token):
    """Monta o link usando somente a URL pública definida pelo servidor.

    Não usa o cabeçalho Host da requisição; isso evita enviar um link para um
    domínio injetado por quem preencheu o formulário.
    """
    base = os.environ.get("PORTAL_URL", "").strip().rstrip("/")
    partes = urlsplit(base)
    if (
        partes.scheme not in {"http", "https"}
        or not partes.netloc
        or partes.query
        or partes.fragment
    ):
        raise EmailNaoConfigurado(
            "Configure PORTAL_URL com o endereço público do portal para usar a recuperação por e-mail."
        )
    origem = urlunsplit((partes.scheme, partes.netloc, "", "", ""))
    prefixo = partes.path.rstrip("/")
    rota = url_for("recuperar_redefinir", token=token)
    # Quando o Flask já conhece um prefixo (ex.: /portal), url_for pode
    # devolvê-lo. Assim não duplicamos esse trecho no link enviado.
    if prefixo and rota.startswith(prefixo + "/"):
        return origem + rota
    return origem + prefixo + rota


def _sessao_ativa():
    # GETs and normal navigation keep the slot in the URL. Async form submits
    # also carry it in the body as a fallback if an intermediary drops query
    # parameters from the action URL.
    slot = (request.args.get("sessao") or "").strip()
    if not _AUTH_SLOT_RE.fullmatch(slot) and request.method == "POST":
        slot_formulario = (request.form.get("sessao") or "").strip()
        if _AUTH_SLOT_RE.fullmatch(slot_formulario):
            slot = slot_formulario
    return slot if _AUTH_SLOT_RE.fullmatch(slot) else ""


def _auth_cookie_name(slot):
    return f"{_AUTH_COOKIE_PREFIX}{slot}"


def _auth_token(uid, slot):
    usuario = get_user(uid)
    return _AUTH_SERIALIZER.dumps({
        "uid": uid, "slot": slot,
        "senha_versao": hashlib.sha256(usuario["senha_hash"].encode()).hexdigest(),
    })


def _set_auth_cookie(response, slot, uid):
    response.set_cookie(
        _auth_cookie_name(slot),
        _auth_token(uid, slot),
        # Master usa cookie de sessao do navegador, sem prazo por inatividade.
        max_age=None if eh_master(get_user(uid)) else _AUTH_MAX_AGE,
        httponly=True,
        secure=app.config.get("SESSION_COOKIE_SECURE", False),
        samesite="Lax",
        path="/",
    )


def _adicionar_sessao_url(destino, slot):
    """Inclui/atualiza ?sessao=<slot> em uma URL local."""
    partes = urlsplit(destino)
    params = dict(parse_qsl(partes.query, keep_blank_values=True))
    params["sessao"] = slot
    return urlunsplit((partes.scheme, partes.netloc, partes.path, urlencode(params), partes.fragment))


def url_for_sessao(endpoint, **values):
    """url_for usado nos templates/redirecionamentos autenticados.

    Mantem automaticamente o contexto da aba sem colocar credenciais na URL.
    O parametro ``sessao`` e apenas um identificador; o token real permanece
    em cookie HttpOnly.
    """
    if endpoint not in {"static", "login", "recuperar", "recuperar_redefinir"} and "sessao" not in values:
        slot = _sessao_ativa()
        if slot:
            values["sessao"] = slot
    if endpoint not in {"static", "login", "logout", "recuperar", "recuperar_redefinir",
                         "selecionar_ambiente", "entrar_ambiente", "administracao_master", "salvar_guias_master",
                         "permissoes_ambiente", "ambiente_salvar", "ambiente_status", "ambiente_excluir",
                         "ambiente_associacoes", "ambiente_imagem", "ambiente_imagem_salvar",
                         "ambiente_imagem_remover"}:
        ambiente = contexto_ambiente()
        if ambiente and ambiente != "__sem_ambiente__":
            values.setdefault("ambiente", ambiente)
    return url_for(endpoint, **values)


def _redirecionar_apos_troca_ambiente(ambiente_id):
    """Retorna à tela que abriu o seletor, preservando sua aba e filtros."""
    retorno = (request.form.get("retorno") or "").strip()
    partes = urlsplit(retorno)
    if (
        not retorno
        or partes.scheme
        or partes.netloc
        or not partes.path.startswith("/")
        or partes.path.startswith("//")
    ):
        return redirect(url_for_sessao("index", ambiente=ambiente_id or ""))

    parametros = [
        (chave, valor)
        for chave, valor in parse_qsl(partes.query, keep_blank_values=True)
        if chave not in {"ambiente", "sessao"}
    ]
    slot = _sessao_ativa()
    if slot:
        parametros.append(("sessao", slot))
    parametros.append(("ambiente", ambiente_id or ""))
    destino = urlunsplit(("", "", partes.path, urlencode(parametros), ""))
    return redirect(destino)


def _usuario_cookie_auth(token, slot):
    """Valida assinatura antes de consultar o perfil atual no banco."""
    try:
        dados = _AUTH_SERIALIZER.loads(token)
        if not isinstance(dados, dict) or dados.get("slot") != slot or not dados.get("uid"):
            return None
        usuario = get_user(dados["uid"])
        if not usuario:
            return None
        # A isencao vem do perfil no banco, nunca de um parametro do cliente.
        if not eh_master(usuario):
            _AUTH_SERIALIZER.loads(token, max_age=_AUTH_MAX_AGE)
    except (BadSignature, SignatureExpired):
        return None

    versao = dados.get("senha_versao")
    if versao:
        atual = hashlib.sha256(usuario["senha_hash"].encode()).hexdigest()
        if not isinstance(versao, str) or not hmac.compare_digest(versao, atual):
            return None
    elif usuario.get("troca_senha_obrigatoria"):
        return None
    return usuario


def current_user():
    if hasattr(g, "_portal_current_user"):
        return g._portal_current_user

    g._portal_current_user = None
    g._portal_auth_slot = ""
    slot = _sessao_ativa()
    if not slot:
        return None

    token = request.cookies.get(_auth_cookie_name(slot), "")
    if not token:
        return None

    usuario = _usuario_cookie_auth(token, slot)
    if not usuario:
        return None

    g._portal_current_user = usuario
    g._portal_auth_slot = slot
    if eh_master(usuario):
        escolhido = request.args.get("ambiente", "")
        # Os valores reservados significam contexto vazio: o primeiro é usado
        # pelo destino de publicação de avisos e o segundo pelo seletor do
        # Master. Nenhuma consulta comum deve tratá-los como um ambiente real.
        if escolhido in {_AVISO_TODOS_AMBIENTES, _AMBIENTE_TODOS}:
            g._portal_ambiente_id = None
        elif escolhido and escolhido not in {a["id"] for a in listar_ambientes()}:
            abort(404)
        else:
            g._portal_ambiente_id = escolhido or None
    else:
        escolhido = ler_ambiente_sessao(usuario["id"], slot)
        disponiveis = ambientes_disponiveis(usuario)
        ids_disponiveis = {a["id"] for a in disponiveis}
        if escolhido in ids_disponiveis:
            g._portal_ambiente_id = escolhido
        elif disponiveis:
            # Administradores e Visualizadores não passam mais pela tela
            # obrigatória de seleção após o login. Mantemos um contexto padrão
            # apenas para telas administrativas que ainda dependem de ambiente,
            # enquanto a guia Dashboards carrega a árvore multiambiente inteira.
            padrao = disponiveis[0]["id"]
            g._portal_ambiente_id = padrao
            try:
                selecionar_ambiente_sessao(usuario["id"], slot, padrao)
            except Exception:
                pass
        else:
            g._portal_ambiente_id = "__sem_ambiente__"
    g.pop("_dados_cache", None)
    return usuario


@app.after_request
def renovar_cookie_multisessao(response):
    """Renova somente a sessao usada por esta aba/requisicao."""
    # Limpeza limitada por resposta, sem encerrar contextos ainda validos.
    removidos = 0
    if request.endpoint != "static":
        for nome, token in request.cookies.items():
            if not nome.startswith(_AUTH_COOKIE_PREFIX):
                continue
            valido = _usuario_cookie_auth(token, nome[len(_AUTH_COOKIE_PREFIX):]) is not None
            if not valido:
                response.delete_cookie(nome, path="/", secure=_HTTPS_ATIVO, httponly=True, samesite="Lax")
                removidos += 1
                if removidos >= 8:
                    break
    if getattr(g, "_portal_nao_renovar_auth", False):
        return response
    usuario = getattr(g, "_portal_current_user", None)
    slot = getattr(g, "_portal_auth_slot", "")
    if usuario and slot:
        _set_auth_cookie(response, slot, usuario["id"])
    return response


def _login_url_com_contexto():
    valores = {"next": request.path}
    slot = _sessao_ativa()
    if slot:
        valores["sessao"] = slot
    return url_for("login", **valores)


def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not current_user():
            resposta = _resposta_autenticacao_assincrona()
            if resposta is not None:
                return resposta
            return redirect(_login_url_com_contexto())
        return view(*args, **kwargs)
    return wrapped


def _resposta_autenticacao_assincrona():
    """Explains why an async action cannot continue without a valid login."""
    if not _solicitacao_assincrona_json():
        return None

    slot = _sessao_ativa()
    if not slot:
        motivo = "contexto_ausente"
        mensagem = "O identificador da sessão não chegou ao servidor. Atualize a página e tente novamente."
    elif _auth_cookie_name(slot) not in request.cookies:
        motivo = "cookie_ausente"
        mensagem = "O navegador não enviou o cookie desta sessão. Atualize a página e entre novamente."
    else:
        motivo = "sessao_invalida"
        mensagem = "A sessão não foi reconhecida pelo servidor. Entre novamente e tente criar a pasta."

    return jsonify(ok=False, erro="sessao_expirada", motivo=motivo, mensagem=mensagem), 401


def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        u = current_user()
        if not u:
            resposta = _resposta_autenticacao_assincrona()
            if resposta is not None:
                return resposta
            return redirect(_login_url_com_contexto())
        # As rotas protegidas por este decorador alteram dados administrativos.
        # A guia liberada continua sendo necessária, mas Visualizadores nunca
        # devem obter permissão de escrita apenas por receberem uma guia.
        if not (eh_master(u) or (u.get("papel") == "admin" and pode_endpoint(u, request.endpoint))):
            abort(403)
        _exigir_escopo_administrador(u)
        return view(*args, **kwargs)
    return wrapped


def master_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        usuario = current_user()
        if not usuario:
            return redirect(_login_url_com_contexto())
        if not eh_master(usuario):
            abort(403)
        return view(*args, **kwargs)
    return wrapped


@app.before_request
def exigir_primeira_troca():
    # A restricao e aplicada no servidor, inclusive para APIs e URLs diretas.
    permitidos = {"static", "login", "logout", "token_formulario", "renovar_sessao", "primeiro_acesso"}
    if request.endpoint in permitidos:
        return None
    usuario = current_user()
    if usuario and usuario.get("troca_senha_obrigatoria"):
        destino = url_for_sessao("primeiro_acesso")
        if request.method not in {"GET", "HEAD"} or request.is_json:
            return jsonify(erro="troca_senha_obrigatoria", redirect_url=destino), 403
        return redirect(destino)


@app.before_request
def exigir_ambiente_liberado():
    if request.endpoint in {None, "static", "login", "logout", "recuperar", "recuperar_redefinir",
                            "token_formulario", "primeiro_acesso", "selecionar_ambiente", "entrar_ambiente",
                            "ambiente_imagem"}:
        return None
    usuario = current_user()
    if not usuario or eh_master(usuario):
        return None
    ambiente = contexto_ambiente()
    divergente = request.args.get("ambiente") and request.args["ambiente"] != ambiente
    if ambiente == "__sem_ambiente__" or divergente:
        if request.endpoint == "aviso_eventos_fluxo":
            return Response('event: encerrar\ndata: {}\n\n', mimetype="text/event-stream")
        if request.is_json or request.method != "GET":
            return jsonify(erro="ambiente_indisponivel", mensagem="Nenhum ambiente disponível para este usuário.",
                           destino=url_for_sessao("index")), 409
        flash("Nenhum ambiente disponível para este usuário.", "erro")
        return redirect(url_for_sessao("index"))


@app.before_request
def exigir_guia_liberada():
    if request.endpoint not in GUIAS_ENDPOINT:
        return None
    usuario = current_user()
    if not usuario or pode_endpoint(usuario, request.endpoint):
        return None
    if request.endpoint in {"aviso_eventos_fluxo", "aviso_eventos_online"}:
        g._portal_nao_renovar_auth = True
    if request.endpoint == "aviso_eventos_fluxo":
        return Response('event: encerrar\ndata: {}\n\n', mimetype="text/event-stream")
    if request.endpoint == "index" and request.method == "GET":
        for guia, _, endpoint in GUIAS:
            if pode_guia(usuario, guia):
                return redirect(url_for_sessao(endpoint))
        return render_template("sem_guias.html", active="")
    abort(403)


@app.context_processor
def inject_user():
    usuario = current_user()
    foto = info_foto_usuario(usuario["id"]) if usuario else None
    ambientes_disponiveis_usuario = ambientes_disponiveis(usuario)
    ambiente_atual = next((a for a in ambientes_disponiveis_usuario
                           if a["id"] == contexto_ambiente()), None)
    if usuario and eh_master(usuario) and ambiente_atual is None:
        ambiente_atual = {"id": _AMBIENTE_TODOS, "nome": "Todos os ambientes", "ativo": True}
    ambientes_nomes = {
        a.get("id"): a.get("nome")
        for a in ambientes_disponiveis_usuario
        if a.get("id")
    }
    ambientes_nomes.setdefault(INICIAL, "Ambiente inicial")
    return {
        "current_user": usuario,
        "tem_foto_usuario": bool(foto),
        "versao_foto_usuario": foto.get("versao") if foto else None,
        "pode_guia": lambda guia: pode_guia(usuario, guia),
        "pode_gerenciar_usuario": lambda alvo: pode_gerenciar_usuario(usuario, alvo),
        "is_master": eh_master(usuario),
        "ambientes_disponiveis": ambientes_disponiveis_usuario,
        "ambientes_nomes": ambientes_nomes,
        "ambiente_atual": ambiente_atual,
        "ambiente_todos": _AMBIENTE_TODOS,
        "ambiente_master": next((a for a in listar_ambientes() if a["id"] == contexto_ambiente()), None)
                            if eh_master(usuario) and contexto_ambiente() else None,
        "nome_perfil": nome_perfil,
        # Consultado somente pelo modal, ao renderizar a pagina autenticada.
        # O primeiro acesso continua priorizando a troca obrigatoria de senha.
        "carregar_aviso_modal": lambda: aviso_pendente(usuario["id"])
        if usuario and not eh_master(usuario) and not usuario.get("troca_senha_obrigatoria") else None,
        "url_for": url_for_sessao,
        "sessao_ativa": _sessao_ativa(),
        "inatividade_segundos": _AUTH_MAX_AGE,
    }


@app.context_processor
def inject_tema():
    # Tema é preferência pessoal, não configuração do portal. O cookie antigo
    # ``tema`` era compartilhado pelo navegador: ao trocar de conta no mesmo
    # computador, a escolha de um usuário passava a alterar a de outro.
    # Usamos uma chave por conta autenticada e uma chave separada para a tela
    # de login, preservando também a troca instantânea entre abas da *mesma*
    # conta.
    usuario = current_user()
    tema_chave = f"tema_{usuario['id']}" if usuario else "tema_visitante"
    tema = request.cookies.get(tema_chave, "escuro")
    if tema not in ("claro", "escuro"):
        tema = "escuro"
    return {"tema": tema, "tema_chave": tema_chave}


# ===========================================================================
# Login / logout
# ===========================================================================
@app.route("/login", methods=["GET", "POST"])
@limiter.limit("8 per minute", methods=["POST"])
def login():
    # A tela de login fica acessivel mesmo que outra aba ja esteja autenticada.
    # Isso e intencional: permite abrir uma nova sessao sem derrubar a atual.
    if request.method == "POST":
        usuario = request.form.get("usuario", "").strip()
        senha = request.form.get("senha", "")
        if "<" in usuario:
            flash("Usuário ou senha inválidos.", "erro")
            return render_template("login.html")
        u = get_user_by_login(usuario)
        if u and check_password_hash(u["senha_hash"], senha):
            # Visualizadores antigos sem configuração recebem o padrão de
            # acesso total na primeira autenticação após esta atualização.
            usuarios = load_users()
            alvo_login = next((x for x in usuarios if x.get("id") == u.get("id")), u)
            aplicar_padrao_visualizador_se_necessario(alvo_login, usuarios)
            u = alvo_login

            g._portal_ambiente_id = None
            novo_slot = uuid.uuid4().hex[:16]
            # Mantemos a sessao Flask somente para CSRF/flash; o UID nao fica
            # mais nela, pois esse cookie e compartilhado entre as abas.
            session.pop("uid", None)
            session.permanent = True

            destino = request.args.get("next", "")
            if u.get("troca_senha_obrigatoria"):
                destino = url_for("primeiro_acesso")
            elif not eh_master(u):
                destino = url_for("index")
            if not destino.startswith("/") or destino.startswith("//"):
                destino = url_for("index")
            destino = _adicionar_sessao_url(destino, novo_slot)

            resposta = redirect(destino)
            _set_auth_cookie(resposta, novo_slot, u["id"])
            return resposta
        flash("Usuário ou senha inválidos.", "erro")
    return render_template("login.html")


@app.post("/sessao/renovar")
def renovar_sessao():
    # CSRF continua obrigatorio. Uma sessao expirada nunca e ressuscitada.
    if not current_user():
        return jsonify(erro="sessao_expirada", login_url=url_for("login", sessao=_sessao_ativa())), 401
    return jsonify(ok=True, expira_em_segundos=None if eh_master(current_user()) else _AUTH_MAX_AGE)


@app.route("/logout")
def logout():
    usuario_ambiente = current_user()
    if usuario_ambiente:
        encerrar_ambiente_sessao(usuario_ambiente["id"], _sessao_ativa())
    # Encerra SOMENTE a sessao identificada na URL desta aba.
    slot = _sessao_ativa()
    # Descarta o aviso de primeiro acesso deixado por versoes anteriores.
    # Preserva os demais avisos e a sessao CSRF compartilhada entre abas.
    mensagens = session.get("_flashes", [])
    restantes = [m for m in mensagens if not (
        m[0] == "ok" and m[1] == "Senha alterada com sucesso. Bem-vindo ao portal!"
    )]
    if len(restantes) != len(mensagens):
        if restantes:
            session["_flashes"] = restantes
        else:
            session.pop("_flashes", None)
    resposta = redirect(url_for("login"))
    if slot:
        resposta.delete_cookie(
            _auth_cookie_name(slot),
            path="/",
            secure=app.config.get("SESSION_COOKIE_SECURE", False),
            samesite="Lax",
        )
    g._portal_nao_renovar_auth = True
    return resposta


def ambientes_disponiveis(usuario):
    if not usuario:
        return []
    # O Master continua com todas as permissões, mas pode escolher um recorte
    # de ambiente para navegar sem misturar o Ambiente inicial aos demais.
    if eh_master(usuario):
        return listar_ambientes()
    return listar_ambientes(usuario["id"], somente_ativos=True)


@app.get("/ambientes")
@login_required
def selecionar_ambiente():
    # A seleção obrigatória de ambiente após o login foi removida para
    # Administradores e Visualizadores. A guia Dashboards agora exibe todos
    # os ambientes permitidos na árvore lateral.
    return redirect(url_for_sessao("index"))


@app.post("/ambientes/entrar")
@login_required
def entrar_ambiente():
    usuario = current_user()
    escolhido = (request.form.get("ambiente_id") or "").strip()
    if eh_master(usuario):
        if escolhido == _AMBIENTE_TODOS:
            # Contexto vazio significa "todos" para o Master. O valor vazio
            # também evita ativar a opção de publicação para todos os
            # ambientes na guia Avisos.
            g._portal_ambiente_id = None
            g.pop("_dados_cache", None)
            return _redirecionar_apos_troca_ambiente("")
        if escolhido not in {a["id"] for a in listar_ambientes()}:
            abort(404, description="Ambiente não encontrado.")
        g._portal_ambiente_id = escolhido
        g.pop("_dados_cache", None)
        return _redirecionar_apos_troca_ambiente(escolhido)
    if escolhido not in {a["id"] for a in ambientes_disponiveis(usuario)}:
        abort(403, description="Ambiente indisponível para este usuário.")
    try:
        selecionar_ambiente_sessao(usuario["id"], _sessao_ativa(), escolhido)
    except PermissionError:
        abort(403)
    g._portal_ambiente_id = escolhido
    g.pop("_dados_cache", None)
    return _redirecionar_apos_troca_ambiente(escolhido)


def _normalizar_imagem_ambiente(dados, mime, nome="", quadro_ja_padronizado=False):
    """Converte qualquer imagem válida para o quadro padrão dos cartões.

    A imagem é orientada pelo EXIF, ampliada ou reduzida proporcionalmente,
    centralizada em um canvas horizontal e exportada em um formato otimizado.
    A cor do fundo é inferida das bordas do próprio arquivo; não há regras
    específicas para cliente, nome ou logomarca.
    """
    if Image is None:
        # O JavaScript também faz a normalização no navegador; este caminho
        # mantém compatibilidade com instalações sem a dependência Pillow.
        return dados, mime, nome
    try:
        with Image.open(io.BytesIO(dados)) as aberta:
            if (aberta.format or "").upper() not in {"PNG", "JPEG", "WEBP"}:
                raise ValueError("Use uma imagem PNG, JPG/JPEG ou WebP válida.")
            if aberta.width > 12000 or aberta.height > 12000:
                raise ValueError("A imagem possui dimensões muito grandes.")
            imagem = ImageOps.exif_transpose(aberta).convert("RGBA")

        # Ao exibir uma imagem já gravada, o quadro padrão não deve receber
        # uma segunda margem. No upload, porém, até um arquivo originalmente
        # com 1024 x 447 px precisa passar pelo tratamento e pela margem.
        if quadro_ja_padronizado and imagem.size == (IMAGEM_AMBIENTE_LARGURA, IMAGEM_AMBIENTE_ALTURA):
            return dados, mime, nome

        pontos = [(0, 0), (imagem.width - 1, 0), (0, imagem.height - 1),
                  (imagem.width - 1, imagem.height - 1)]
        pontos += [(imagem.width // 2, 0), (0, imagem.height // 2),
                   (imagem.width - 1, imagem.height // 2), (imagem.width // 2, imagem.height - 1)]
        amostras = [imagem.getpixel(ponto) for ponto in pontos]
        opacidade = sum(pixel[3] for pixel in amostras) / len(amostras)
        if opacidade < 210:
            fundo = (255, 255, 255)
        else:
            fundo = tuple(round(sum(pixel[indice] for pixel in amostras) / len(amostras)) for indice in range(3))

        largura_final = IMAGEM_AMBIENTE_LARGURA
        altura_final = IMAGEM_AMBIENTE_ALTURA
        margem = IMAGEM_AMBIENTE_MARGEM
        resampling = getattr(Image, "Resampling", Image).LANCZOS
        limite_largura = largura_final - margem * 2
        limite_altura = altura_final - margem * 2
        escala = min(limite_largura / imagem.width, limite_altura / imagem.height)
        nova_tamanho = (
            max(1, round(imagem.width * escala)),
            max(1, round(imagem.height * escala)),
        )
        if imagem.size != nova_tamanho:
            imagem = imagem.resize(nova_tamanho, resampling)
        quadro = Image.new("RGBA", (largura_final, altura_final), fundo + (255,))
        quadro.alpha_composite(imagem, ((largura_final - imagem.width) // 2, (altura_final - imagem.height) // 2))
        quadro_rgb = quadro.convert("RGB")

        png_buffer = io.BytesIO()
        quadro_rgb.save(png_buffer, format="PNG", optimize=True)
        png_dados = png_buffer.getvalue()
        if len(png_dados) <= IMAGEM_AMBIENTE_MAX_BYTES:
            base = os.path.splitext(nome or "ambiente")[0] or "ambiente"
            return png_dados, "image/png", (base[:251] + ".png")

        # Fotos detalhadas podem gerar um PNG maior que o limite. O JPEG é
        # usado somente nesse caso, preservando o mesmo quadro e proporção.
        base = os.path.splitext(nome or "ambiente")[0] or "ambiente"
        for qualidade in (92, 88, 82, 76):
            jpg_buffer = io.BytesIO()
            quadro_rgb.save(jpg_buffer, format="JPEG", quality=qualidade, optimize=True, progressive=True)
            jpg_dados = jpg_buffer.getvalue()
            if len(jpg_dados) <= IMAGEM_AMBIENTE_MAX_BYTES:
                return jpg_dados, "image/jpeg", (base[:251] + ".jpg")
    except ValueError:
        raise
    except Exception as exc:
        raise ValueError("Não foi possível ler ou formatar a imagem selecionada.") from exc
    raise ValueError("A imagem formatada ainda ultrapassa 2 MB. Escolha um arquivo menor.")


def _ler_imagem_ambiente(arquivo):
    """Valida e normaliza uma imagem, sem confiar no MIME do navegador."""
    if not arquivo or not arquivo.filename:
        raise ValueError("Selecione uma imagem para enviar.")
    if Image is None or ImageOps is None:
        raise ValueError(
            "O tratamento de imagens está indisponível no servidor. "
            "Instale a dependência Pillow e reinicie o Portal BI."
        )
    dados = arquivo.stream.read(IMAGEM_AMBIENTE_ORIGINAL_MAX_BYTES + 1)
    if not dados:
        raise ValueError("O arquivo selecionado está vazio.")
    if len(dados) > IMAGEM_AMBIENTE_ORIGINAL_MAX_BYTES:
        raise ValueError("O arquivo original deve ter no máximo 8 MB.")
    if dados.startswith(b"\x89PNG\r\n\x1a\n"):
        mime = "image/png"
    elif dados.startswith(b"\xff\xd8\xff"):
        mime = "image/jpeg"
    elif dados.startswith(b"RIFF") and len(dados) >= 12 and dados[8:12] == b"WEBP":
        mime = "image/webp"
    else:
        raise ValueError("Use uma imagem PNG, JPG/JPEG ou WebP válida.")
    if mime not in IMAGEM_AMBIENTE_MIMES:
        raise ValueError("Formato de imagem não permitido.")
    nome = (arquivo.filename or "").replace("\x00", "")
    # O nome original serve apenas para informação no banco; nunca é usado
    # como caminho de arquivo no servidor.
    nome = nome.rsplit("/", 1)[-1].rsplit("\\", 1)[-1].strip()[:255]
    return _normalizar_imagem_ambiente(dados, mime, nome)


def _ler_foto_usuario(arquivo):
    """Valida e prepara a foto de perfil em um formato único e leve.

    A preparação é feita no servidor, portanto vale tanto para imagens
    enviadas pelo computador quanto pelo celular. O recorte central evita
    distorção no avatar circular da barra lateral.
    """
    if not arquivo or not arquivo.filename:
        raise ValueError("Selecione uma foto para enviar.")
    if Image is None or ImageOps is None:
        raise ValueError("O tratamento de fotos requer Pillow. Execute: python -m pip install Pillow")

    dados = arquivo.stream.read(FOTO_USUARIO_ORIGINAL_MAX_BYTES + 1)
    if not dados:
        raise ValueError("O arquivo selecionado está vazio.")
    if len(dados) > FOTO_USUARIO_ORIGINAL_MAX_BYTES:
        raise ValueError("A foto original deve ter no máximo 5 MB.")

    try:
        with Image.open(io.BytesIO(dados)) as aberta:
            if (aberta.format or "").upper() not in {"PNG", "JPEG", "WEBP"}:
                raise ValueError("Use uma foto PNG, JPG/JPEG ou WebP válida.")
            if not aberta.width or not aberta.height or aberta.width > 12000 or aberta.height > 12000:
                raise ValueError("A foto possui dimensões muito grandes.")
            imagem = ImageOps.exif_transpose(aberta).convert("RGB")

        resampling = getattr(Image, "Resampling", Image).LANCZOS
        avatar = ImageOps.fit(
            imagem,
            (FOTO_USUARIO_LADO, FOTO_USUARIO_LADO),
            method=resampling,
            centering=(0.5, 0.5),
        )
        buffer = io.BytesIO()
        avatar.save(buffer, format="JPEG", quality=90, optimize=True, progressive=True)
        foto = buffer.getvalue()
    except ValueError:
        raise
    except Exception as exc:
        raise ValueError("Não foi possível ler ou tratar a foto selecionada.") from exc

    if len(foto) > 1024 * 1024:
        raise ValueError("A foto formatada ficou muito grande. Escolha outra imagem.")
    nome = (arquivo.filename or "").replace("\x00", "")
    nome = nome.rsplit("/", 1)[-1].rsplit("\\", 1)[-1].strip()
    base = os.path.splitext(nome or "foto-perfil")[0] or "foto-perfil"
    return foto, FOTO_USUARIO_MIME, (base[:251] + ".jpg")


def _usuario_pode_ver_imagem_ambiente(usuario, ambiente_id):
    if not usuario or not ambiente_id:
        return False
    if eh_master(usuario):
        return any(a["id"] == ambiente_id for a in listar_ambientes())
    return any(a["id"] == ambiente_id for a in ambientes_disponiveis(usuario))


@app.get("/ambientes/<ambiente_id>/imagem")
def ambiente_imagem(ambiente_id):
    imagem = carregar_imagem_ambiente(ambiente_id)
    if not imagem or not imagem.get("imagem_dados") or imagem.get("imagem_mime") not in IMAGEM_AMBIENTE_MIMES:
        abort(404)
    dados = bytes(imagem["imagem_dados"])
    mime = imagem["imagem_mime"]
    imagem_formatada = False
    # Normaliza em memória imagens gravadas por versões anteriores. Se a
    # normalização falhar, entrega o BLOB original do banco para não quebrar
    # a tela de Ambientes. O CSS mantém o ajuste visual no cartão.
    if Image is not None and ImageOps is not None:
        try:
            dados_normalizados, mime_normalizado, _ = _normalizar_imagem_ambiente(
                dados,
                mime,
                imagem.get("imagem_nome") or "ambiente",
                quadro_ja_padronizado=True,
            )
            dados = dados_normalizados
            mime = mime_normalizado
            imagem_formatada = True
        except ValueError:
            imagem_formatada = False
    resposta = send_file(io.BytesIO(dados), mimetype=mime, max_age=0)
    # A resposta é derivada do banco, mas não deve ficar presa ao cache do
    # navegador após uma troca ou remoção da imagem.
    resposta.headers["Cache-Control"] = "no-store, private"
    resposta.headers["X-Portal-Imagem-Formatada"] = "1" if imagem_formatada else "0"
    resolucao = "desconhecida"
    if Image is not None:
        try:
            with Image.open(io.BytesIO(dados)) as final:
                resolucao = f"{final.width}x{final.height}"
        except Exception:
            pass
    resposta.headers["X-Portal-Imagem-Resolucao"] = resolucao
    return resposta


@app.post("/ambientes/<ambiente_id>/imagem")
@master_required
def ambiente_imagem_salvar(ambiente_id):
    # Funcionalidade de imagem de ambiente desativada.
    abort(404)


@app.post("/ambientes/<ambiente_id>/imagem/remover")
@master_required
def ambiente_imagem_remover(ambiente_id):
    # Funcionalidade de imagem de ambiente desativada.
    abort(404)


def _usuarios_associacao(ambiente_id, ator=None):
    associados = usuarios_do_ambiente(ambiente_id)
    # Na tela do Administrador, contas administrativas e a conta Master não
    # são exibidas nem podem ser alteradas. Ele gerencia exclusivamente os
    # Visualizadores do ambiente que já lhe foi atribuído pelo Master.
    if ator and ator.get("papel") == "admin":
        usuarios = [u for u in load_users() if u.get("papel") == "viewer"]
    else:
        usuarios = [u for u in load_users() if not eh_master(u)]
    usuarios.sort(key=lambda u: (u["nome"].casefold(), u["id"]))
    return [{"id": u["id"], "nome": u["nome"], "usuario": u["usuario"], "papel": u["papel"], "perfil": nome_perfil(u["papel"]),
             "associado": u["id"] in associados} for u in usuarios]


@app.get("/ambientes/permissoes")
@admin_required
def permissoes_ambiente():
    ator = current_user()
    ambientes = listar_ambientes() if eh_master(ator) else ambientes_disponiveis(ator)
    # As abas escolhem o ambiente de gestão apenas entre os disponíveis ao
    # ator. Para o Administrador, o contexto atual continua sendo o padrão.
    escolhido = request.args.get("ambiente_id") or (None if eh_master(ator) else contexto_ambiente())
    ambiente = next((a for a in ambientes if a["id"] == escolhido), None)
    if escolhido and not ambiente:
        abort(404)
    ambiente = ambiente or (ambientes[0] if ambientes else None)
    return render_template("permissoes_ambiente.html", active="administracao", admin_tab="ambientes",
                           ambientes=ambientes, ambiente=ambiente,
                           usuarios_associacao=_usuarios_associacao(ambiente["id"], ator) if ambiente else [],
                           ocultar_seletor_ambiente=eh_master(ator))


@app.post("/ambientes/salvar")
@master_required
def ambiente_salvar():
    ambiente_id = request.form.get("ambiente_id") or None
    try:
        ambiente_id = salvar_ambiente(current_user()["id"], request.form.get("nome", ""), ambiente_id)
    except PermissionError:
        abort(403)
    except (ValueError, IntegrityError) as exc:
        flash(str(exc) if isinstance(exc, ValueError) else "Já existe um ambiente com esse nome.", "erro")
    else:
        flash("Ambiente salvo.", "ok")
    return redirect(url_for_sessao("permissoes_ambiente", ambiente_id=ambiente_id))


@app.post("/ambientes/<ambiente_id>/status")
@master_required
def ambiente_status(ambiente_id):
    ativo = request.form.get("ativo")
    if ativo not in {"0", "1"}:
        abort(400)
    try:
        definir_ambiente_ativo(current_user()["id"], ambiente_id, ativo == "1")
    except PermissionError:
        abort(403)
    except ValueError as exc:
        abort(404, description=str(exc))
    flash("Ambiente ativado." if ativo == "1" else "Ambiente desativado. As associações foram preservadas.", "ok")
    return redirect(url_for_sessao("permissoes_ambiente", ambiente_id=ambiente_id))


@app.post("/ambientes/<ambiente_id>/excluir")
@master_required
def ambiente_excluir(ambiente_id):
    try:
        nome = excluir_ambiente(current_user()["id"], ambiente_id)
    except PermissionError:
        abort(403)
    except ValueError as exc:
        flash(str(exc), "erro")
        return redirect(url_for_sessao("permissoes_ambiente", ambiente_id=ambiente_id))
    flash(f'Ambiente "{nome}" excluído com sucesso. Seus usuários continuam disponíveis nos demais ambientes.', "ok")
    return redirect(url_for_sessao("permissoes_ambiente"))


@app.post("/ambientes/<ambiente_id>/associacoes")
@admin_required
def ambiente_associacoes(ambiente_id):
    dados = request.get_json(silent=True)
    if not isinstance(dados, dict):
        abort(400)
    ator = current_user()
    ambientes_permitidos = listar_ambientes() if eh_master(ator) else ambientes_disponiveis(ator)
    if ambiente_id not in {ambiente["id"] for ambiente in ambientes_permitidos}:
        abort(403)
    # Defesa no endpoint: a interface já esconde Administradores do Administrador
    # local, mas uma requisição direta também não pode alterar essas contas.
    if ator.get("papel") == "admin":
        ids_validos = {u["id"] for u in load_users() if u.get("papel") == "viewer"}
        ids_recebidos = dados.get("usuarios")
        if not isinstance(ids_recebidos, list) or any(uid not in ids_validos for uid in ids_recebidos):
            abort(403)
    try:
        alterar_associacoes(ator["id"], ambiente_id, dados.get("usuarios"), dados.get("acao"))
    except PermissionError:
        abort(403)
    except ValueError as exc:
        return jsonify(erro=str(exc)), 400
    return jsonify(usuarios=_usuarios_associacao(ambiente_id, ator), mensagem="Associações atualizadas.")


# --- Esqueci minha senha (link seguro enviado por e-mail) ---
@app.route("/recuperar", methods=["GET", "POST"])
@limiter.limit("5 per hour", methods=["POST"])
def recuperar():
    if current_user():
        return redirect(url_for_sessao("index"))
    if request.method == "POST":
        try:
            email = validar_email(request.form.get("email"), obrigatorio=True)
        except ValueError as exc:
            flash(str(exc), "erro")
            return render_template("recuperar.html"), 400

        # A configuração é verificada antes da consulta da conta. A mensagem
        # de sucesso abaixo é sempre igual e nunca revela se o e-mail existe.
        try:
            obter_configuracao_email()
            usuario = get_user_by_email(email)
            if usuario:
                token = _gerar_token_redefinicao(usuario)
                link = _url_redefinicao_publica(token)
                try:
                    enviar_email_redefinicao(
                        email, usuario.get("nome", ""), link, _RECUPERACAO_SENHA_MINUTOS
                    )
                except EmailEnvioFalhou:
                    # Não expõe a falha para uma pessoa que poderia estar
                    # testando e-mails de terceiros. O detalhe fica no log.
                    app.logger.exception(
                        "Falha ao enviar recuperação de senha para uma conta cadastrada"
                    )
                else:
                    registrar_evento_usuario(
                        "recuperacao_email_solicitada", usuario,
                        "Link de redefinição de senha solicitado por e-mail",
                    )
        except EmailNaoConfigurado as exc:
            app.logger.warning("Recuperação por e-mail indisponível: %s", exc)
            flash("A recuperação por e-mail ainda não está disponível. Contate o administrador do portal.", "erro")
            return render_template("recuperar.html"), 503
        except Exception:
            # A resposta ao navegador continua genérica. O administrador pode
            # investigar o erro no log sem que a tela exponha dados da conta.
            app.logger.exception("Falha inesperada na solicitação de recuperação de senha")

        flash(
            "Se existir uma conta vinculada a este e-mail, enviaremos um link de redefinição. "
            "Verifique também a caixa de spam.",
            "ok",
        )
        return redirect(url_for("recuperar"))
    return render_template("recuperar.html")


@app.route("/recuperar/redefinir/<token>", methods=["GET", "POST"])
@limiter.limit("10 per hour", methods=["POST"])
def recuperar_redefinir(token):
    if current_user():
        return redirect(url_for_sessao("index"))
    usuario = _usuario_do_token_redefinicao(token)
    if not usuario:
        flash("Este link é inválido, expirou ou já foi utilizado. Solicite um novo link.", "erro")
        return render_template("recuperar_redefinir.html", token=None, usuario=None), 400

    if request.method == "POST":
        nova = request.form.get("senha_nova", "")
        confirma = request.form.get("senha_confirma", "")
        if not senha_valida(nova):
            flash(SENHA_REGRA, "erro")
        elif nova != confirma:
            flash("A confirmação não confere com a nova senha.", "erro")
        elif check_password_hash(usuario["senha_hash"], nova):
            flash("Escolha uma senha diferente da senha atual.", "erro")
        else:
            nova_hash = generate_password_hash(nova)
            if not redefinir_senha_por_email(
                usuario["id"], usuario["senha_hash"], usuario["email"], nova_hash
            ):
                flash("Este link deixou de valer. Solicite um novo link de redefinição.", "erro")
                return render_template(
                    "recuperar_redefinir.html", token=None, usuario=None
                ), 400
            registrar_evento_usuario(
                "senha_redefinida_email", usuario,
                "Senha redefinida por link enviado ao e-mail cadastrado",
            )
            flash("Senha redefinida com sucesso. Faça login com a nova senha.", "ok")
            return redirect(url_for("login"))
    return render_template("recuperar_redefinir.html", token=token, usuario=usuario)


# ===========================================================================
# Paginas
# ===========================================================================
def _pastas_herdadas_do_ambiente_admin(u, data):
    """Resolve as pastas que um Administrador recebe pelo ambiente.

    A associação em ``Permissões de ambiente`` é a autorização do Master
    para que a conta admin opere naquele ambiente. Por isso ela não pode ser
    uma fotografia da estrutura no dia em que foi configurada: dashboards e
    pastas incluídos ou movidos depois devem aparecer automaticamente, sem
    exigir que o Master refaça a permissão do Administrador.

    Visualizadores continuam usando somente as permissões explícitas e suas
    exceções. Assim, a alteração não amplia o acesso de contas viewer.
    """
    if not u or u.get("papel") != "admin":
        return set()
    ambientes = ambientes_do_usuario(u.get("id"))
    return {
        pasta["id"] for pasta in data.get("pastas", [])
        if (pasta.get("ambiente_id") or INICIAL) in ambientes
    }


def _estado_subpasta_permissao(u, subpasta_id, data=None, sub_por_id=None, bloqueadas=None,
                               pastas_herdadas=None):
    """Resolve o acesso de uma subpasta pelo nível mais específico."""
    if data is None:
        data = load_data()
    if sub_por_id is None:
        sub_por_id = {sp["id"]: sp for sp in data.get("subpastas", [])}
    if bloqueadas is None:
        bloqueadas = carregar_subpastas_bloqueadas(u.get("id"))

    sp = sub_por_id.get(subpasta_id)
    if not sp:
        return False

    permitidas = set(u.get("subpastas", []))
    if pastas_herdadas is None:
        pastas_herdadas = _pastas_herdadas_do_ambiente_admin(u, data)
    estado = sp.get("pasta_id") in (set(u.get("pastas", [])) | set(pastas_herdadas))
    cadeia = list(reversed(_subpasta_ancestrais(subpasta_id, sub_por_id))) + [subpasta_id]
    for node_id in cadeia:
        if node_id in bloqueadas:
            estado = False
        if node_id in permitidas:
            estado = True
    return estado


def _ids_subpastas_permitidas(u, data=None, bloqueadas=None):
    if data is None:
        data = load_data()
    sub_por_id = {sp["id"]: sp for sp in data.get("subpastas", [])}
    if bloqueadas is None:
        bloqueadas = carregar_subpastas_bloqueadas(u.get("id"))
    pastas_herdadas = _pastas_herdadas_do_ambiente_admin(u, data)
    return {
        sub_id for sub_id in sub_por_id
        if _estado_subpasta_permissao(
            u, sub_id, data, sub_por_id, bloqueadas, pastas_herdadas
        )
    }


def _ids_dashboards_permitidos(u, data=None, subpastas_bloqueadas=None, dashboards_bloqueados=None):
    """Resolve permissões com sobrescrita em Cliente, Divisão, Tema e Dashboard.

    O nível mais específico pode sempre alterar o nível superior. Exemplo:
    Cliente liberado -> Divisão bloqueada -> Tema liberado -> Dashboard bloqueado.
    """
    if data is None:
        data = load_data()

    # Para Administradores, a associação ao ambiente é uma permissão
    # dinâmica de toda a estrutura daquele ambiente. Isso mantém o espelho
    # do que o Master acabou de incluir, editar ou mover sem persistir cópias
    # de IDs de dashboards em cada conta administrativa.
    pastas_ok = set(u.get("pastas", [])) | _pastas_herdadas_do_ambiente_admin(u, data)
    subpastas_ok = set(u.get("subpastas", []))
    dashboards_ok = set(u.get("dashboards", []))
    if subpastas_bloqueadas is None:
        subpastas_bloqueadas = carregar_subpastas_bloqueadas(u.get("id"))
    if dashboards_bloqueados is None:
        dashboards_bloqueados = carregar_dashboards_bloqueados(u.get("id"))
    sub_por_id = {sp["id"]: sp for sp in data.get("subpastas", [])}
    permitidos = set()

    for d in data.get("dashboards", []):
        estado = d.get("pasta_id") in pastas_ok
        sub_id = d.get("subpasta_id")
        if sub_id:
            cadeia = list(reversed(_subpasta_ancestrais(sub_id, sub_por_id))) + [sub_id]
            for node_id in cadeia:
                if node_id in subpastas_bloqueadas:
                    estado = False
                if node_id in subpastas_ok:
                    estado = True

        if d["id"] in dashboards_bloqueados:
            estado = False
        if d["id"] in dashboards_ok:
            estado = True

        if estado:
            permitidos.add(d["id"])

    return permitidos

def _permissoes_dentro_do_escopo(ator, alvo, sub_bloqueadas=None, dash_bloqueados=None):
    """Não permite conceder acesso atual ou herdado mais amplo que o do ator."""
    data = load_data()
    pastas_ator = set(ator.get("pastas", [])) | _pastas_herdadas_do_ambiente_admin(ator, data)
    subs_ator = _ids_subpastas_permitidas(ator, data)
    dashes_ator = _ids_dashboards_permitidos(ator, data)
    if contexto_ambiente():
        alvo = dict(alvo, **{campo: list(set(alvo.get(campo, [])) & {x["id"] for x in data[campo]})
                            for campo in ("pastas", "subpastas", "dashboards")})
    return (set(alvo.get("pastas", [])) <= pastas_ator
            and set(alvo.get("subpastas", [])) <= subs_ator
            and set(alvo.get("dashboards", [])) <= dashes_ator
            and _ids_subpastas_permitidas(alvo, data, sub_bloqueadas) <= subs_ator
            and _ids_dashboards_permitidos(alvo, data, sub_bloqueadas, dash_bloqueados) <= dashes_ator)


def pode_gerenciar_usuario(ator, alvo):
    if not ator or not alvo:
        return False
    if contexto_ambiente() and alvo.get("id") not in usuarios_do_ambiente(contexto_ambiente()):
        return False
    if not _pode_gerenciar_por_perfil(ator, alvo):
        return False
    return ator.get("papel") != "admin" or _permissoes_dentro_do_escopo(ator, alvo)


def _dados_no_escopo_admin(u, data):
    """Filtra leituras administrativas sem usar esta cópia em save_data.

    Ancestrais de uma permissão pontual aparecem apenas para compor o caminho;
    sua presença não concede acesso aos irmãos ou ao restante do cliente.
    """
    if not u or u.get("papel") != "admin":
        return data
    dashes = _ids_dashboards_permitidos(u, data)
    subs = _ids_subpastas_permitidas(u, data)
    sub_por_id = {sp["id"]: sp for sp in data.get("subpastas", [])}
    subs_visiveis = set(subs)
    pastas = set(u.get("pastas", [])) | _pastas_herdadas_do_ambiente_admin(u, data)
    for d in data.get("dashboards", []):
        if d["id"] in dashes:
            pastas.add(d.get("pasta_id"))
            if d.get("subpasta_id"):
                subs_visiveis.add(d["subpasta_id"])
    for sid in list(subs_visiveis):
        subs_visiveis.update(_subpasta_ancestrais(sid, sub_por_id))
    for sid in subs_visiveis:
        if sid in sub_por_id:
            pastas.add(sub_por_id[sid].get("pasta_id"))
    return dict(data,
        pastas=[p for p in data.get("pastas", []) if p["id"] in pastas],
        subpastas=[sp for sp in data.get("subpastas", []) if sp["id"] in subs_visiveis],
        dashboards=[d for d in data.get("dashboards", []) if d["id"] in dashes])


def _dados_do_ambiente(data, ambiente_id):
    """Retorna somente a estrutura pertencente a um ambiente.

    O helper é usado tanto pelo filtro de permissões da Administração de
    Usuários quanto por consultas do Master que precisam montar uma visão
    isolada de um cliente, sem alterar as permissões globais da conta.
    """
    ambiente_id = (ambiente_id or "").strip()
    if not ambiente_id:
        return data

    pastas = [p for p in data.get("pastas", [])
              if (p.get("ambiente_id") or INICIAL) == ambiente_id]
    pasta_ids = {p.get("id") for p in pastas}
    subpastas = [sp for sp in data.get("subpastas", [])
                 if sp.get("pasta_id") in pasta_ids]
    subpastas_ids = {sp.get("id") for sp in subpastas}

    pasta_ambientes = {p.get("id"): (p.get("ambiente_id") or INICIAL)
                       for p in data.get("pastas", [])}
    dashboards = []
    for dash in data.get("dashboards", []):
        dash_ambiente = dash.get("ambiente_id") or pasta_ambientes.get(dash.get("pasta_id"), INICIAL)
        if dash_ambiente == ambiente_id:
            dashboards.append(dash)

    return dict(data, pastas=pastas, subpastas=subpastas, dashboards=dashboards)


def _dados_cadastro_master(ambiente_id=None):
    """Carrega a estrutura do Cadastro sem alterar o contexto da barra lateral.

    O Master pode filtrar a tela Cadastro por um ambiente diferente daquele
    usado na navegação global. O contexto e o cache da requisição são
    restaurados antes que os processadores de template montem a barra lateral.
    """
    marcador = object()
    contexto_original = getattr(g, "_portal_ambiente_id", marcador)
    cache_original = getattr(g, "_dados_cache", marcador)
    try:
        g._portal_ambiente_id = (ambiente_id or None)
        g.pop("_dados_cache", None)
        return load_data()
    finally:
        if contexto_original is marcador:
            g.pop("_portal_ambiente_id", None)
        else:
            g._portal_ambiente_id = contexto_original
        if cache_original is marcador:
            g.pop("_dados_cache", None)
        else:
            g._dados_cache = cache_original


def _dados_cadastro_master_da_requisicao():
    """Obtém os dados do filtro local usado por uma ação iniciada no Cadastro."""
    ambiente_id = request.args.get("ambiente_cadastro")
    if ambiente_id is None:
        ambiente_id = contexto_ambiente() or ""
    ambiente_id = (ambiente_id or "").strip()
    if ambiente_id == _AMBIENTE_TODOS:
        ambiente_id = ""
    if ambiente_id and ambiente_id not in {a["id"] for a in listar_ambientes()}:
        abort(404)
    return _dados_cadastro_master(ambiente_id)


def _ambientes_atribuidos_por_usuario(ids):
    """Lê as associações em uma única consulta para a lista administrativa."""
    ids = sorted({str(uid).strip() for uid in ids if uid})
    if not ids:
        return {}
    placeholders = ",".join(["%s"] * len(ids))
    conn = get_connection()
    try:
        with conn.cursor() as cur:
            cur.execute(f"""
                SELECT au.usuario_id, a.id, a.nome, a.ativo
                FROM ambiente_usuarios au
                JOIN ambientes a ON a.id = au.ambiente_id
                WHERE au.usuario_id IN ({placeholders})
                ORDER BY au.usuario_id, a.nome, a.id
            """, tuple(ids))
            ambientes = {uid: [] for uid in ids}
            for row in cur.fetchall():
                ambientes.setdefault(row["usuario_id"], []).append({
                    "id": row["id"],
                    "nome": row["nome"],
                    "ativo": bool(row.get("ativo", True)),
                })
            return ambientes
    finally:
        conn.close()


def _acessos_no_escopo_admin(u, registros):
    if not u or u.get("papel") != "admin":
        return registros
    permitidos = _ids_dashboards_permitidos(u)
    # Um registro sem ID verificável não autoriza acesso por coincidência de nome.
    return [r for r in registros if r.get("dashboard_id") in permitidos]


def _exigir_escopo_administrador(u):
    """Protege também POSTs diretos; ter a guia liberada não libera seu conteúdo."""
    if u.get("papel") != "admin" or request.method != "POST":
        return
    endpoint = request.endpoint
    acoes = {"renomear_pasta", "excluir_pasta", "criar_subpasta",
             "renomear_subpasta", "editar_estrutura_subpasta", "excluir_subpasta",
             "cadastrar", "editar", "mover_dashboard", "excluir"}
    if endpoint not in acoes:
        return
    data = load_data()
    pastas = set(u.get("pastas", []))
    subs = _ids_subpastas_permitidas(u, data)
    dashes = _ids_dashboards_permitidos(u, data)
    sub_por_id = {sp["id"]: sp for sp in data.get("subpastas", [])}
    dash_por_id = {d["id"]: d for d in data.get("dashboards", [])}

    def exigir(condicao):
        if not condicao:
            abort(403, description="Este conteúdo não está autorizado pelo Master para seu usuário.")

    def destino_permitido(pid, sid=None):
        if sid:
            return (sid in subs and sub_por_id.get(sid, {}).get("pasta_id") == pid)
        return pid in pastas

    def exigir_subarvore(sid):
        ids = _descendentes_subpasta(sid, data.get("subpastas", []))
        exigir(sid in subs and ids <= subs)
        exigir(all(d["id"] in dashes for d in data.get("dashboards", [])
                   if d.get("subpasta_id") in ids))

    args = request.view_args or {}
    if endpoint in {"renomear_pasta", "excluir_pasta"}:
        pid = args.get("pasta_id")
        exigir(pid in pastas)
        if endpoint == "excluir_pasta":
            exigir(all(sp["id"] in subs for sp in data.get("subpastas", []) if sp.get("pasta_id") == pid))
            exigir(all(d["id"] in dashes for d in data.get("dashboards", []) if d.get("pasta_id") == pid))
    elif endpoint == "criar_subpasta":
        exigir(destino_permitido(request.form.get("pasta_id"), request.form.get("parent_subpasta_id")))
    elif endpoint in {"renomear_subpasta", "editar_estrutura_subpasta", "excluir_subpasta"}:
        sid = args.get("subpasta_id")
        exigir(sid in subs)
        if endpoint != "renomear_subpasta":
            exigir_subarvore(sid)
        if endpoint == "excluir_subpasta":
            sp = sub_por_id[sid]
            # A exclusão promove dashboards ao pai; valida também o destino.
            exigir(destino_permitido(sp.get("pasta_id"), sp.get("parent_subpasta_id")))
        if endpoint == "editar_estrutura_subpasta":
            destino = request.form.get("destino", "").strip()
            if destino.startswith("p:"):
                exigir(destino[2:] in pastas)
            elif destino.startswith("s:"):
                exigir(destino[2:] in subs)
            elif destino:
                exigir(False)
    else:
        dash = dash_por_id.get(args.get("dash_id"))
        if endpoint in {"editar", "mover_dashboard", "excluir"}:
            exigir(dash is not None and dash["id"] in dashes)
        if endpoint in {"cadastrar", "editar", "mover_dashboard"}:
            pid = request.form.get("pasta_id", "").strip()
            sid = (request.form.get("subpasta_id", "").strip() or None)
            if endpoint != "mover_dashboard":
                sid = (request.form.get("subnivel_id", "").strip()
                       or request.form.get("tema_id", "").strip()
                       or sid)
            # Permissão só no dashboard permite editá-lo onde está, sem abrir o pai.
            mesma_localizacao = (dash is not None and dash.get("pasta_id") == pid
                                 and (dash.get("subpasta_id") or None) == sid)
            exigir(mesma_localizacao or destino_permitido(pid, sid))


def _carregar_dados_dashboards_usuario(u):
    """Carrega a guia Dashboards em modo multiambiente para Admin/Viewer.

    A sessão do usuário ainda guarda um ``ambiente_atual`` para as telas
    administrativas. Porém, na guia Dashboards, a árvore lateral deve mostrar
    todos os ambientes atribuídos ao usuário, igual ao Master. A consulta é
    limitada a esses ambientes no banco, sem carregar a estrutura completa para
    depois descartá-la em memória.

    A filtragem fina de pastas/subpastas/dashboards continua sendo feita por
    ``calcular_arvore_dashboards`` e ``usuario_pode_ver``, respeitando as
    permissões concedidas pelo Master.
    """
    if not u or eh_master(u):
        return load_data()

    ambientes = ambientes_disponiveis(u)
    ids_ambientes = {a.get("id") for a in ambientes if a.get("id")}
    if not ids_ambientes:
        return {"pastas": [], "subpastas": [], "dashboards": []}
    return load_data_ambientes(ids_ambientes)

def usuario_pode_ver(u, dash, data=None):
    """Verifica a permissao efetiva do usuario para um dashboard.

    Dashboards inativos deixam de ficar disponiveis para visualizadores. O
    administrador pode acessar os autorizados para manutencao, mesmo inativos.
    Quando ``data`` é informado, a checagem usa esse escopo — necessário na
    guia Dashboards, que agora reúne todos os ambientes atribuídos ao usuário.
    """
    if eh_master(u):
        return True
    if u.get("papel") != "admin" and not bool(dash.get("ativo", True)):
        return False
    return dash["id"] in _ids_dashboards_permitidos(u, data)


def _filtrar_grupo_por_dashboards(grupo, ids_permitidos, subpastas_permitidas=None):
    """Mantem a hierarquia visivel mesmo quando uma pasta/subpasta ainda esta vazia.

    Para visualizadores, uma permissao direta em Divisao/Tema/Subnivel deve fazer
    a estrutura aparecer imediatamente na barra lateral, inclusive antes de haver
    dashboards cadastrados nela. Permissoes em niveis superiores tambem revelam
    seus descendentes, pois o acesso e herdado para conteudos futuros.
    """
    subpastas_permitidas = set(subpastas_permitidas or [])
    permitidos = [d for d in grupo["dashboards"] if d["id"] in ids_permitidos]
    permitidos_ids = {d["id"] for d in permitidos}
    raiz = [d for d in grupo.get("dashboards_raiz", []) if d["id"] in permitidos_ids]
    divisoes = []

    for sg in grupo.get("subpastas", []):
        sg_id = sg["subpasta"]["id"]
        sg_liberada = sg_id in subpastas_permitidas
        diretos = [d for d in sg.get("dashboards_diretos", []) if d["id"] in permitidos_ids]
        temas = []
        dashes_temas = []

        for tg in sg.get("temas", []):
            tg_id = tg["tema"]["id"]
            tg_liberado = tg_id in subpastas_permitidas
            diretos_tema = [d for d in tg.get("dashboards_diretos", []) if d["id"] in permitidos_ids]
            subniveis = []
            dashes_subniveis = []

            for ng in tg.get("subniveis", []):
                ng_id = ng["subnivel"]["id"]
                ng_liberado = ng_id in subpastas_permitidas
                itens_sub = [d for d in ng.get("dashboards", []) if d["id"] in permitidos_ids]
                if itens_sub or ng_liberado:
                    subniveis.append({"subnivel": ng["subnivel"], "dashboards": itens_sub})
                    dashes_subniveis.extend(itens_sub)

            todos_tema = diretos_tema + dashes_subniveis
            tema_tem_permissao_descendente = any(
                ng["subnivel"]["id"] in subpastas_permitidas
                for ng in tg.get("subniveis", [])
            )
            if todos_tema or tg_liberado or tema_tem_permissao_descendente:
                temas.append({
                    "tema": tg["tema"],
                    "dashboards": todos_tema,
                    "dashboards_diretos": diretos_tema,
                    "subniveis": subniveis,
                })
                dashes_temas.extend(todos_tema)

        todos_divisao = diretos + dashes_temas
        divisao_tem_permissao_descendente = any(
            tg["tema"]["id"] in subpastas_permitidas
            or any(ng["subnivel"]["id"] in subpastas_permitidas for ng in tg.get("subniveis", []))
            for tg in sg.get("temas", [])
        )
        if todos_divisao or sg_liberada or divisao_tem_permissao_descendente:
            divisoes.append({
                "subpasta": sg["subpasta"],
                "dashboards": todos_divisao,
                "dashboards_diretos": diretos,
                "temas": temas,
            })

    return {
        "pasta": grupo["pasta"],
        "dashboards": permitidos,
        "dashboards_raiz": raiz,
        "subpastas": divisoes,
    }


def calcular_arvore_dashboards(u, data=None):
    """Monta a arvore visivel de Pasta -> Divisao -> Tema -> Subnivel -> Dashboard.

    O menu/portal mostra somente dashboards ativos. Itens inativos continuam
    disponiveis na tela administrativa de cadastro para edicao. Na navegação
    de Admin/Visualizador, ``data`` reúne todos os ambientes atribuídos.
    """
    if data is None:
        data = load_data() if eh_master(u) else _carregar_dados_dashboards_usuario(u)
    data_visivel = dict(data)
    data_visivel["dashboards"] = [d for d in data.get("dashboards", []) if bool(d.get("ativo", True))]
    grupos = agrupar(data_visivel)
    if not eh_master(u):
        dashes_ok = _ids_dashboards_permitidos(u, data)
        subpastas_visiveis = _ids_subpastas_permitidas(u, data)
        filtrados = []
        for g in grupos:
            grupo_filtrado = _filtrar_grupo_por_dashboards(
                g, dashes_ok, subpastas_visiveis
            )
            if (grupo_filtrado["dashboards"] or grupo_filtrado.get("subpastas")
                    or g["pasta"]["id"] in set(u.get("pastas", []))):
                filtrados.append(grupo_filtrado)
        grupos = filtrados

    favoritos_ids = carregar_favoritos(u["id"])
    dashboards_favoritos = []
    ambientes_nomes = {
        a.get("id"): a.get("nome")
        for a in listar_ambientes()
        if a.get("id")
    }
    ambientes_nomes.setdefault(INICIAL, "Ambiente inicial")
    for g in grupos:
        divisao_por_dash = {}
        tema_por_dash = {}
        subnivel_por_dash = {}
        for sg in g.get("subpastas", []):
            for d in sg.get("dashboards_diretos", []):
                divisao_por_dash[d["id"]] = sg["subpasta"]["nome"]
            for tg in sg.get("temas", []):
                for d in tg.get("dashboards_diretos", []):
                    divisao_por_dash[d["id"]] = sg["subpasta"]["nome"]
                    tema_por_dash[d["id"]] = tg["tema"]["nome"]
                for ng in tg.get("subniveis", []):
                    for d in ng.get("dashboards", []):
                        divisao_por_dash[d["id"]] = sg["subpasta"]["nome"]
                        tema_por_dash[d["id"]] = tg["tema"]["nome"]
                        subnivel_por_dash[d["id"]] = ng["subnivel"]["nome"]
        for d in g["dashboards"]:
            if d["id"] in favoritos_ids and bool(d.get("permitir_favoritar", True)):
                item = dict(d)
                item["pasta_nome"] = g["pasta"]["nome"]
                item["ambiente_id"] = d.get("ambiente_id") or g["pasta"].get("ambiente_id") or INICIAL
                item["ambiente_nome"] = ambientes_nomes.get(item["ambiente_id"], item["ambiente_id"])
                item["subpasta_nome"] = divisao_por_dash.get(d["id"], "")
                item["tema_nome"] = tema_por_dash.get(d["id"], "")
                item["subnivel_nome"] = subnivel_por_dash.get(d["id"], "")
                dashboards_favoritos.append(item)

    return grupos, favoritos_ids, dashboards_favoritos


@app.context_processor
def inject_arvore_lateral():
    """Disponibiliza a arvore de pastas/dashboards para TODAS as paginas
    (a barra lateral e compartilhada por toda a area logada), alem de
    qual dashboard esta selecionado no momento (para destacar o item
    certo na arvore, quando aplicavel)."""
    u = current_user()
    if not u or u.get("troca_senha_obrigatoria") or request.endpoint == "selecionar_ambiente":
        return {}
    data_arvore = load_data() if eh_master(u) else _carregar_dados_dashboards_usuario(u)
    grupos, favoritos_ids, dashboards_favoritos = calcular_arvore_dashboards(u, data_arvore)
    if eh_master(u):
        arvore_ambientes = _agrupar_arvore_por_ambiente(grupos, data_arvore)
    else:
        arvore_ambientes = _agrupar_arvore_por_ambiente(
            grupos,
            data_arvore,
            ambientes_override=ambientes_disponiveis(u),
            ignorar_contexto=True,
        )
    return {
        "arvore_grupos": grupos,
        "arvore_ambientes": arvore_ambientes,
        "arvore_favoritos_ids": favoritos_ids,
        "arvore_favoritos": dashboards_favoritos,
        "arvore_dashboard_selecionado_id": request.args.get("dashboard", "").strip() or None,
        "estado": get_estado_paineis(),
    }


@app.route("/")
@login_required
def index():
    u = current_user()
    data = load_data() if eh_master(u) else _carregar_dados_dashboards_usuario(u)

    # Dashboard selecionado na arvore da barra lateral: exibido no painel
    # de conteudo desta pagina, sem sair dela (o link e um
    # <a href="?dashboard=..."> comum, entao voltar/avancar do navegador
    # continua funcionando normalmente).
    dashboard_selecionado = None
    dash_id_solicitado = request.args.get("dashboard", "").strip()
    if dash_id_solicitado:
        dash_encontrado = next((d for d in data["dashboards"] if d["id"] == dash_id_solicitado), None)
        if dash_encontrado:
            pasta_do_dash = next((p for p in data["pastas"] if p["id"] == dash_encontrado.get("pasta_id")), None)
            pasta_nome = pasta_do_dash["nome"] if pasta_do_dash else "—"
            if usuario_pode_ver(u, dash_encontrado, data):
                registrar_acesso(u, dash_encontrado, pasta_nome, status="sucesso")
                dashboard_selecionado = dict(dash_encontrado)
                dashboard_selecionado["pasta_nome"] = pasta_nome
                sub_por_id = {sp["id"]: sp for sp in data.get("subpastas", [])}
                sub_id = dash_encontrado.get("subpasta_id")
                caminho = []
                vistos = set()
                while sub_id and sub_id in sub_por_id and sub_id not in vistos:
                    vistos.add(sub_id)
                    sp = sub_por_id[sub_id]
                    caminho.append(sp)
                    sub_id = sp.get("parent_subpasta_id") or None
                caminho.reverse()
                dashboard_selecionado["subpasta_nome"] = caminho[0]["nome"] if len(caminho) > 0 else ""
                dashboard_selecionado["tema_nome"] = caminho[1]["nome"] if len(caminho) > 1 else ""
                dashboard_selecionado["subnivel_nome"] = caminho[2]["nome"] if len(caminho) > 2 else ""
            else:
                registrar_acesso(u, dash_encontrado, pasta_nome, status="negado")

    favoritos_ids = carregar_favoritos(u["id"])
    return render_template("portal.html", active="dashboards",
                           favoritos_ids=favoritos_ids,
                           aviso=None if eh_master(u) else carregar_aviso_dashboard(),
                           dashboard_selecionado=dashboard_selecionado,
                           # Na guia Dashboards a navegação por ambiente passa a
                           # acontecer exclusivamente pela árvore lateral.
                           ocultar_seletor_ambiente=True)


@app.route("/dashboard/<dash_id>")
@login_required
def dashboard(dash_id):
    """Exibe o dashboard embutido (iframe) dentro do portal, sem nunca
    expor o link real do Power BI na barra de enderecos ou no botao
    'copiar link'. Exige login e verifica a permissao do usuario."""
    u = current_user()
    data = load_data() if eh_master(u) else _carregar_dados_dashboards_usuario(u)
    dash = next((d for d in data["dashboards"] if d["id"] == dash_id), None)
    if not dash:
        abort(404)
    pasta = next((p for p in data["pastas"] if p["id"] == dash.get("pasta_id")), None)
    pasta_nome = pasta["nome"] if pasta else "—"
    if not usuario_pode_ver(u, dash, data):
        registrar_acesso(u, dash, pasta_nome, status="negado")
        abort(403)
    registrar_acesso(u, dash, pasta_nome, status="sucesso")
    return render_template("view.html", nome=dash["nome"], embed_url=dash["embed_url"])


@app.route("/favoritos/<dash_id>/alternar", methods=["POST"])
@login_required
def favoritos_alternar(dash_id):
    """Marca/desmarca um dashboard como favorito do usuario logado.
    Responde em JSON (chamado via JavaScript, sem recarregar a pagina)."""
    u = current_user()
    data = load_data() if eh_master(u) else _carregar_dados_dashboards_usuario(u)
    dash = next((d for d in data["dashboards"] if d["id"] == dash_id), None)
    if not dash:
        return jsonify({"erro": "Dashboard não encontrado."}), 404
    if not usuario_pode_ver(u, dash, data):
        return jsonify({"erro": "Sem permissão para este dashboard."}), 403
    if not bool(dash.get("permitir_favoritar", True)):
        return jsonify({"erro": "Este dashboard não permite favoritos."}), 403
    favoritado = alternar_favorito(u["id"], dash_id)
    return jsonify({"favorito": favoritado})


@app.route("/cadastro")
@admin_required
def cadastro():
    usuario = current_user()
    cadastro_id = (request.args.get("cadastro_id") or "").strip().lower()
    if not re.fullmatch(r"[0-9a-f]{32}", cadastro_id):
        cadastro_id = uuid.uuid4().hex
    folder_submission_id = uuid.uuid4().hex
    ambientes_cadastro = listar_ambientes() if eh_master(usuario) else []
    ids_ambientes = {a["id"] for a in ambientes_cadastro}
    if eh_master(usuario):
        filtro_presente = "ambiente_cadastro" in request.args
        ambiente_solicitado = (
            request.args.get("ambiente_cadastro", "") if filtro_presente
            else request.args.get("ambiente", "")
        ).strip()
        if ambiente_solicitado and ambiente_solicitado != _AMBIENTE_TODOS and ambiente_solicitado not in ids_ambientes:
            abort(404, description="Ambiente do cadastro não encontrado.")
        cadastro_todos_ambientes = ambiente_solicitado == _AMBIENTE_TODOS
        if filtro_presente:
            ambiente_cadastro_selecionado = ambiente_solicitado
        else:
            ambiente_cadastro_selecionado = (
                _AMBIENTE_TODOS if cadastro_todos_ambientes
                else contexto_ambiente() if contexto_ambiente() in ids_ambientes else ""
            )
        ambiente_filtro_cadastro = (
            ambiente_cadastro_selecionado
            if ambiente_cadastro_selecionado in ids_ambientes else None
        )
        data = _dados_cadastro_master(ambiente_filtro_cadastro)
    else:
        cadastro_todos_ambientes = False
        ambiente_cadastro_selecionado = ""
        data = _dados_no_escopo_admin(usuario, load_data())
    return render_template("cadastro.html", grupos=agrupar(data), pastas=data["pastas"],
                           subpastas=data.get("subpastas", []),
                           ambientes_cadastro=ambientes_cadastro,
                           ambiente_cadastro_padrao=ambiente_cadastro_selecionado,
                           dashboard_submission_id=cadastro_id,
                           folder_submission_id=folder_submission_id,
                           cadastro_todos_ambientes=cadastro_todos_ambientes,
                           ocultar_seletor_ambiente=eh_master(usuario),
                           active="cadastro", estado=get_estado_paineis())


@app.route("/dashboards/administracao")
@admin_required
def dashboards_administracao():
    usuario_atual = current_user()
    dados_completos = load_data()
    data = _dados_no_escopo_admin(usuario_atual, dados_completos)
    grupos = agrupar(data)
    usuarios_admin = list(load_users())
    usuarios_por_id = {u.get("id"): u for u in usuarios_admin if u.get("id")}
    dashboards_admin = [_dashboard_admin_context(data, d, usuarios_por_id) for d in data.get("dashboards", [])]
    resumo_integridade = resumo_integridade_dashboards(
        None if eh_master(usuario_atual) else _ids_dashboards_permitidos(usuario_atual, data)
    )
    _dashboard_admin_integridade(data, dashboards_admin, usuarios=usuarios_admin,
                                 resumo_acessos=resumo_integridade)
    dashboards_admin.sort(key=lambda d: (d.get("nome", "").lower(), d.get("hierarquia_texto", "").lower()))
    dashboards_admin_ambientes = _dashboards_admin_por_ambiente(data, grupos, dashboards_admin) if eh_master(usuario_atual) else []

    dash_id = request.args.get("dash", "").strip()
    dashboard_selecionado = next((d for d in dashboards_admin if d.get("id") == dash_id), None)
    if dashboard_selecionado is None and dashboards_admin:
        dashboard_selecionado = dashboards_admin[0]

    # A administração usa uma única visão: a árvore de Dashboards também
    # concentra o gerenciamento de pastas e subpastas.
    tab = "dashboards"
    estrutura_token = request.args.get("estrutura", "").strip()
    estrutura_selecionada = _estrutura_admin_context(data, estrutura_token)
    estrutura_acoes = _acoes_estrutura_admin(usuario_atual, dados_completos, estrutura_selecionada)
    estrutura_no_dashboard = tab == "dashboards" and bool(estrutura_token)
    if estrutura_no_dashboard:
        # A seleção de uma pasta/subpasta ocupa o painel de detalhes da direita;
        # não deixe o fallback do primeiro dashboard aparecer ao mesmo tempo.
        dashboard_selecionado = None

    return render_template(
        "dashboards_administracao.html",
        pastas=data.get("pastas", []),
        subpastas=data.get("subpastas", []),
        grupos=grupos,
        dashboards_admin=dashboards_admin,
        dashboards_admin_ambientes=dashboards_admin_ambientes,
        dashboard_selecionado=dashboard_selecionado,
        estrutura_selecionada=estrutura_selecionada,
        estrutura_acoes=estrutura_acoes,
        estrutura_no_dashboard=estrutura_no_dashboard,
        admin_tab=tab,
        ocultar_seletor_ambiente=eh_master(usuario_atual),
        active="dashboards_administracao",
        estado=get_estado_paineis(),
    )


def _filtro_periodo_aviso(prefix=""):
    """Lê o período opcional usado no acompanhamento dos avisos.

    As datas chegam no formato ISO do campo ``type=date``. O limite final é
    tratado como inclusivo pela camada de banco; por isso ela recebe apenas
    as datas válidas, sem precisar conhecer detalhes do formulário.
    """
    inicio_chave = f"{prefix}_inicio" if prefix else "periodo_inicio"
    fim_chave = f"{prefix}_fim" if prefix else "periodo_fim"
    inicio_raw = request.args.get(inicio_chave, "").strip()[:10]
    fim_raw = request.args.get(fim_chave, "").strip()[:10]

    def converter(valor, rotulo):
        if not valor:
            return None, None
        try:
            data = datetime.strptime(valor, "%Y-%m-%d").date()
        except (TypeError, ValueError):
            return None, f"Informe uma {rotulo} válida."
        return data, None

    inicio, erro = converter(inicio_raw, "data inicial")
    fim, erro_fim = converter(fim_raw, "data final")
    erro = erro or erro_fim
    if erro:
        # Não aplique parcialmente um período inválido; a tela informa o
        # problema e permite que o usuário o corrija pelo calendário.
        inicio = fim = None
    elif inicio and fim and inicio > fim:
        erro = "A data inicial não pode ser posterior à data final."
        inicio = fim = None

    inicio_valor = inicio.isoformat() if inicio else ""
    fim_valor = fim.isoformat() if fim else ""
    if inicio and fim:
        resumo = f"De {inicio:%d/%m/%Y} a {fim:%d/%m/%Y}"
    elif inicio:
        resumo = f"A partir de {inicio:%d/%m/%Y}"
    elif fim:
        resumo = f"Até {fim:%d/%m/%Y}"
    else:
        resumo = ""
    return inicio, fim, inicio_valor, fim_valor, resumo, erro


def _filtro_periodo_aviso_compat(prefix):
    """Lê o filtro nomeado e mantém compatibilidade com links antigos."""
    especifico = _filtro_periodo_aviso(prefix)
    if (not request.args.get(f"{prefix}_inicio") and not request.args.get(f"{prefix}_fim")
            and (request.args.get("periodo_inicio") or request.args.get("periodo_fim"))):
        return _filtro_periodo_aviso()
    return especifico


@app.route("/aviso")
@admin_required
def aviso():
    filtro_assunto = request.args.get("assunto", "").strip()[:120]
    abas_validas = {"visao-geral", "novo-aviso", "avisos-ativos", "aceites", "historico"}
    aba = request.args.get("aba", "visao-geral").strip().lower()
    if aba not in abas_validas:
        aba = "visao-geral"

    periodo_generico = _filtro_periodo_aviso()
    periodo_aceites = _filtro_periodo_aviso("aceites")
    periodo_historico = _filtro_periodo_aviso("historico")
    # Links antigos da guia usavam periodo_inicio/periodo_fim. A leitura
    # continua compatível para não quebrar favoritos nem exports antigos.
    if (not request.args.get("aceites_inicio") and not request.args.get("aceites_fim")
            and (request.args.get("periodo_inicio") or request.args.get("periodo_fim"))):
        periodo_aceites = periodo_generico
    if (not request.args.get("historico_inicio") and not request.args.get("historico_fim")
            and (request.args.get("periodo_inicio") or request.args.get("periodo_fim"))):
        periodo_historico = periodo_generico

    (aceites_inicio, aceites_fim, aceites_inicio_valor, aceites_fim_valor,
     aceites_resumo, aceites_erro) = periodo_aceites
    (historico_inicio, historico_fim, historico_inicio_valor, historico_fim_valor,
     historico_resumo, historico_erro) = periodo_historico
    usuario = current_user()
    master = eh_master(usuario)
    # O master não possui ambiente implícito: publicar no inicial por padrão
    # deixava o comunicado invisível para quem estava nos demais ambientes.
    ambientes_aviso = listar_ambientes() if master else ambientes_disponiveis(usuario)
    aviso_para_todos = (
        master
        and request.args.get("ambiente") == _AVISO_TODOS_AMBIENTES
    )
    ambiente_aviso = next((a for a in ambientes_aviso if a["id"] == contexto_ambiente()), None)
    ids_ambientes_permitidos = [item["id"] for item in ambientes_aviso]
    escopo_ambientes = None if master else ids_ambientes_permitidos
    publicacoes, publicacao, registros, ativo_id = ([], None, [], None)
    # O acompanhamento do Master é sempre consolidado; o histórico
    # individual continua sendo consultado pelos demais administradores.
    if ambiente_aviso and not aviso_para_todos and not master:
        publicacoes, publicacao, registros, ativo_id = acompanhamento_avisos(
            request.args.get("publicacao"),
            assunto=filtro_assunto,
            periodo_inicio=aceites_inicio,
            periodo_fim=aceites_fim,
        )
    # O Master também recebe uma visão consolidada do histórico. Ela é
    # carregada mesmo com um ambiente pré-selecionado para que a tabela de
    # aceite permaneça disponível assim que a guia é aberta.
    registros_todos = (
        acompanhamento_avisos_todos(
            assunto=filtro_assunto,
            periodo_inicio=aceites_inicio,
            periodo_fim=aceites_fim,
            aviso_id=request.args.get("aviso_id", "").strip()[:32] or None,
        )
        if master else []
    )
    # A prévia do Master não usa o texto do formulário: ela mostra exatamente
    # o aviso atualmente instalado, inclusive o assunto e a data. No modo
    # "Todos os ambientes" cada ambiente tem um ponteiro/histórico próprio.
    aviso_detalhes = (
        carregar_aviso_atual()
        if ambiente_aviso and not aviso_para_todos else None
    )
    escopo_ativos = escopo_ambientes
    if not master and contexto_ambiente() in ids_ambientes_permitidos:
        # A remoção/edição do administrador continua limitada ao ambiente
        # atualmente selecionado, mesmo quando ele possui mais de um vínculo.
        escopo_ativos = [contexto_ambiente()]
    avisos_ativos = carregar_avisos_ativos(escopo_ativos)
    resumo_aviso = resumo_avisos(escopo_ambientes)
    escopo_historico = escopo_ambientes
    if not master and contexto_ambiente() in ids_ambientes_permitidos:
        escopo_historico = [contexto_ambiente()]
    historico = historico_avisos(
        assunto=filtro_assunto,
        periodo_inicio=historico_inicio,
        periodo_fim=historico_fim,
        ambiente_ids=escopo_historico,
    )
    aviso_edicao = None
    editar_id = request.args.get("editar_aviso", "").strip()[:32]
    if editar_id:
        aviso_edicao = next((item for item in historico if item.get("aviso_id") == editar_id), None)
    novo_assunto = request.form.get("assunto", "") if request.method == "POST" else (aviso_edicao.get("assunto", "") if aviso_edicao else "")
    novo_texto = request.form.get("texto", "") if request.method == "POST" else (aviso_edicao.get("texto", "") if aviso_edicao else "")
    nova_duracao = request.form.get("duracao_horas", "24") if request.method == "POST" else "24"
    periodo_erro = aceites_erro if aba == "aceites" else historico_erro if aba == "historico" else ""
    return render_template("aviso.html", active="aviso",
                           aviso_atual=carregar_aviso() if ambiente_aviso and not aviso_para_todos else None,
                           aviso_detalhes=aviso_detalhes, avisos_ativos=avisos_ativos,
                           ambientes_aviso=ambientes_aviso, ambiente_aviso=ambiente_aviso,
                           aviso_para_todos=aviso_para_todos,
                           publicacoes=publicacoes, publicacao=publicacao,
                           registros=registros, ativo_id=ativo_id,
                           registros_todos=registros_todos,
                           aba=aba, resumo_aviso=resumo_aviso, historico=historico,
                           aviso_id_consultado=request.args.get("aviso_id", "").strip()[:32],
                           aviso_edicao=aviso_edicao,
                           novo_assunto=novo_assunto, novo_texto=novo_texto, nova_duracao=nova_duracao,
                           filtro_assunto=filtro_assunto,
                           aceites_inicio=aceites_inicio_valor,
                           aceites_fim=aceites_fim_valor,
                           aceites_ativo=bool(aceites_inicio or aceites_fim),
                           aceites_resumo=aceites_resumo,
                           aceites_erro=aceites_erro,
                           historico_inicio=historico_inicio_valor,
                           historico_fim=historico_fim_valor,
                           historico_ativo=bool(historico_inicio or historico_fim),
                           historico_resumo=historico_resumo,
                           historico_erro=historico_erro,
                           periodo_inicio=aceites_inicio_valor,
                           periodo_fim=aceites_fim_valor,
                           periodo_ativo=bool(aceites_inicio or aceites_fim),
                           periodo_resumo=aceites_resumo,
                           periodo_erro=periodo_erro)


def _destino_aviso_valido(publicar=False):
    ambiente = next((a for a in listar_ambientes() if a["id"] == contexto_ambiente()), None)
    if not ambiente:
        flash("Selecione o ambiente de destino do aviso antes de continuar.", "erro")
        return False
    if publicar and not ambiente["ativo"]:
        flash("Este ambiente está inativo. Selecione um ambiente ativo para publicar o aviso.", "erro")
        return False
    return True


# Notifica as conexoes de acompanhamento somente depois de gravar o evento.
_AVISOS_CONDICAO = Condition()
_AVISOS_VERSAO = 0


def _notificar_evento_aviso():
    global _AVISOS_VERSAO
    with _AVISOS_CONDICAO:
        _AVISOS_VERSAO += 1
        _AVISOS_CONDICAO.notify_all()


@app.route("/aviso/<aviso_id>/fluxo")
def aviso_eventos_fluxo(aviso_id):
    g._portal_nao_renovar_auth = True
    periodo_inicio, periodo_fim, _, _, _, _ = _filtro_periodo_aviso_compat("aceites")
    usuario = current_user()
    if not usuario or not pode_guia(usuario, "aviso"):
        return Response('event: encerrar\ndata: {}\n\n', mimetype="text/event-stream")
    _, publicacao, _, _ = acompanhamento_avisos(
        aviso_id,
        periodo_inicio=periodo_inicio,
        periodo_fim=periodo_fim,
    )
    if not publicacao:
        return Response('event: indisponivel\ndata: {}\n\n', mimetype="text/event-stream")
    ultimo_id = request.headers.get("Last-Event-ID", "")
    template = app.jinja_env.get_template("aviso_eventos.html")

    @stream_with_context
    def gerar():
        nonlocal ultimo_id
        limite = time.monotonic() + 25
        yield "retry: 1000\n\n"
        while time.monotonic() < limite:
            with _AVISOS_CONDICAO:
                versao = _AVISOS_VERSAO
            # Revalida perfil/senha e expiracao sem renovar cookies ou tocar a sessao.
            g.pop("_portal_current_user", None)
            g.pop("_usuarios_cache", None)
            atual = current_user()
            if not atual or contexto_ambiente() == "__sem_ambiente__" or not pode_guia(atual, "aviso") or atual.get("troca_senha_obrigatoria"):
                yield 'event: encerrar\ndata: {}\n\n'
                return
            _, existente, registros, _ = acompanhamento_avisos(
                aviso_id,
                periodo_inicio=periodo_inicio,
                periodo_fim=periodo_fim,
            )
            if not existente:
                yield 'event: indisponivel\ndata: {}\n\n'
                return
            html = template.render(registros=registros, nome_perfil=nome_perfil)
            assinatura = hashlib.sha256(html.encode()).hexdigest()
            if assinatura != ultimo_id:
                ultimo_id = assinatura
                yield f"id: {assinatura}\nevent: registros\ndata: {json.dumps({'html': html}, ensure_ascii=False)}\n\n"
            else:
                yield ": conectado\n\n"
            with _AVISOS_CONDICAO:
                if versao == _AVISOS_VERSAO:
                    # Tambem detecta gravacoes em outro processo do servidor.
                    # Apenas mudancas geram dados para a tabela no navegador.
                    _AVISOS_CONDICAO.wait(timeout=min(2, max(0, limite - time.monotonic())))

    resposta = Response(gerar(), mimetype="text/event-stream")
    resposta.headers["X-Accel-Buffering"] = "no"
    resposta.headers["Vary"] = "Cookie"
    return resposta


@app.route("/avisos/fluxo")
def avisos_eventos_fluxo():
    """Atualiza a tabela consolidada do Master por evento, sem polling."""
    g._portal_nao_renovar_auth = True
    usuario = current_user()
    if not usuario or not eh_master(usuario) or not pode_guia(usuario, "aviso"):
        return Response('event: encerrar\ndata: {}\n\n', mimetype="text/event-stream")

    filtro_assunto = request.args.get("assunto", "").strip()[:120]
    aviso_id_consultado = request.args.get("aviso_id", "").strip()[:32] or None
    periodo_inicio, periodo_fim, _, _, _, _ = _filtro_periodo_aviso_compat("aceites")
    template = app.jinja_env.get_template("aviso_eventos_consolidado.html")
    ultimo_id = request.headers.get("Last-Event-ID", "")

    @stream_with_context
    def gerar():
        nonlocal ultimo_id
        limite = time.monotonic() + 25
        yield "retry: 1000\n\n"
        while time.monotonic() < limite:
            with _AVISOS_CONDICAO:
                versao = _AVISOS_VERSAO

            g.pop("_portal_current_user", None)
            g.pop("_usuarios_cache", None)
            atual = current_user()
            if (not atual or not eh_master(atual) or not pode_guia(atual, "aviso")
                    or atual.get("troca_senha_obrigatoria")):
                yield 'event: encerrar\ndata: {}\n\n'
                return

            registros = acompanhamento_avisos_todos(
                assunto=filtro_assunto,
                periodo_inicio=periodo_inicio,
                periodo_fim=periodo_fim,
                aviso_id=aviso_id_consultado,
            )
            html = template.render(
                registros=registros,
                filtro_assunto=filtro_assunto,
                periodo_ativo=bool(periodo_inicio or periodo_fim),
                nome_perfil=nome_perfil,
            )
            assinatura = hashlib.sha256(html.encode()).hexdigest()
            if assinatura != ultimo_id:
                ultimo_id = assinatura
                yield f"id: {assinatura}\nevent: registros\ndata: {json.dumps({'html': html}, ensure_ascii=False)}\n\n"
            else:
                yield ": conectado\n\n"

            with _AVISOS_CONDICAO:
                if versao == _AVISOS_VERSAO:
                    _AVISOS_CONDICAO.wait(timeout=min(2, max(0, limite - time.monotonic())))

    resposta = Response(gerar(), mimetype="text/event-stream")
    resposta.headers["X-Accel-Buffering"] = "no"
    resposta.headers["Vary"] = "Cookie"
    return resposta


@app.route("/aviso/<aviso_id>/exportar.xlsx")
@admin_required
def exportar_avisos(aviso_id):
    periodo_inicio, periodo_fim, _, _, _, _ = _filtro_periodo_aviso_compat("aceites")
    _, publicacao, registros, _ = acompanhamento_avisos(
        aviso_id,
        periodo_inicio=periodo_inicio,
        periodo_fim=periodo_fim,
    )
    if not publicacao:
        abort(404)
    wb = Workbook()
    ws = wb.active
    ws.title = "Histórico dos avisos"
    ws.append(["Assunto", "Publicado em", "Data/hora da visualização", "Data/hora da resposta",
               "Usuário", "Login", "Perfil", "Visualizou o modal", "Aceite", "Mensagem"])
    for item in registros:
        valores = [publicacao.get("assunto") or "Sem assunto", publicacao["publicado_em"],
                   item.get("visualizado_em"), item.get("aceito_em") or item.get("recusado_em"),
                   item["nome"], item["usuario"],
                   nome_perfil(item["papel"]),
                   "Sim" if item.get("visualizado_em") else "Não",
                   "Aceito" if item.get("aceito_em") else "Não aceito" if item.get("recusado_em") else "Pendente",
                   publicacao["texto"]]
        ws.append([re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", valor)
                   if isinstance(valor, str) else valor for valor in valores])
    for row in ws:
        for cell in row:
            if isinstance(cell.value, str):
                # Conteudo do usuario e texto literal, nunca formula do Excel.
                cell.data_type = "s"
            if isinstance(cell.value, datetime):
                cell.number_format = "dd/mm/yyyy hh:mm:ss"
            cell.alignment = Alignment(vertical="top", wrap_text=True)
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="1F2937")
    for row in ws.iter_rows(min_row=2):
        for cell in (row[7], row[8]):
            if cell.value in {"Sim", "Aceito", "Não", "Não aceito"}:
                cell.fill = PatternFill("solid", fgColor="15803D" if cell.value in {"Sim", "Aceito"} else "B42318")
                cell.font = Font(color="FFFFFF")
    for i, largura in enumerate([32, 23, 25, 25, 28, 24, 20, 20, 16, 70], 1):
        ws.column_dimensions[ws.cell(1, i).column_letter].width = largura
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return send_file(buf, as_attachment=True,
                     download_name=f"historico_avisos_{datetime.now():%Y%m%d_%H%M%S}.xlsx",
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


@app.route("/avisos/exportar.xlsx")
@admin_required
def exportar_avisos_todos():
    """Exporta o acompanhamento consolidado disponível ao Master."""
    if not eh_master(current_user()):
        abort(403)
    filtro_assunto = request.args.get("assunto", "").strip()[:120]
    aviso_id_consultado = request.args.get("aviso_id", "").strip()[:32] or None
    periodo_inicio, periodo_fim, _, _, _, _ = _filtro_periodo_aviso_compat("aceites")
    registros = acompanhamento_avisos_todos(
        assunto=filtro_assunto,
        periodo_inicio=periodo_inicio,
        periodo_fim=periodo_fim,
        aviso_id=aviso_id_consultado,
    )
    wb = Workbook()
    ws = wb.active
    ws.title = "Histórico dos avisos"
    ws.append(["Ambiente", "Assunto", "Publicado em", "Data/hora da visualização",
               "Data/hora da resposta", "Usuário", "Login", "Perfil",
               "Visualizou o modal", "Aceite", "Mensagem"])
    for item in registros:
        valores = [item.get("ambiente_nome"), item.get("assunto") or "Sem assunto",
                   item.get("publicado_em"), item.get("visualizado_em"),
                   item.get("aceito_em") or item.get("recusado_em"), item.get("nome"),
                   item.get("usuario"), nome_perfil(item.get("papel")),
                   "Sim" if item.get("visualizado_em") else "Não",
                   "Aceito" if item.get("aceito_em") else "Não aceito" if item.get("recusado_em") else "Pendente",
                   item.get("texto") or ""]
        ws.append([re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", valor)
                   if isinstance(valor, str) else valor for valor in valores])
    for row in ws:
        for cell in row:
            if isinstance(cell.value, str):
                cell.data_type = "s"
            if isinstance(cell.value, datetime):
                cell.number_format = "dd/mm/yyyy hh:mm:ss"
            cell.alignment = Alignment(vertical="top", wrap_text=True)
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="1F2937")
    for row in ws.iter_rows(min_row=2):
        for cell in (row[8], row[9]):
            if cell.value in {"Sim", "Aceito", "Não", "Não aceito"}:
                cell.fill = PatternFill("solid", fgColor="15803D" if cell.value in {"Sim", "Aceito"} else "B42318")
                cell.font = Font(color="FFFFFF")
    for i, largura in enumerate([25, 32, 23, 25, 25, 28, 24, 20, 20, 16, 70], 1):
        ws.column_dimensions[ws.cell(1, i).column_letter].width = largura
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return send_file(buf, as_attachment=True,
                     download_name=f"historico_avisos_consolidado_{datetime.now():%Y%m%d_%H%M%S}.xlsx",
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


@app.route("/avisos/historico.xlsx")
@admin_required
def exportar_avisos_historico():
    """Exporta o resumo de publicações exibido na aba Histórico."""
    usuario = current_user()
    master = eh_master(usuario)
    ambientes = listar_ambientes() if master else ambientes_disponiveis(usuario)
    escopo = None if master else [item["id"] for item in ambientes]
    if not master and contexto_ambiente() in {item["id"] for item in ambientes}:
        escopo = [contexto_ambiente()]
    periodo_inicio, periodo_fim, _, _, _, _ = _filtro_periodo_aviso_compat("historico")
    filtro_assunto = request.args.get("assunto", "").strip()[:120]
    registros = historico_avisos(
        assunto=filtro_assunto,
        periodo_inicio=periodo_inicio,
        periodo_fim=periodo_fim,
        ambiente_ids=escopo,
    )
    wb = Workbook()
    ws = wb.active
    ws.title = "Histórico de publicações"
    ws.append([
        "Ambiente", "Assunto", "Publicado em", "Responsável", "Status",
        "Ambiente ativo", "Visualizações", "Aceites", "Recusas", "Pendentes",
        "Último evento", "Mensagem",
    ])
    for item in registros:
        status = "Ativo" if item.get("aviso_ativo") else "Encerrado"
        valores = [
            item.get("ambiente_nome"), item.get("assunto") or "Sem assunto",
            item.get("publicado_em"), item.get("responsavel") or "Não informado",
            status, "Sim" if item.get("ambiente_ativo") else "Não",
            item.get("visualizacoes", 0), item.get("aceites", 0),
            item.get("recusas", 0), item.get("pendentes", 0),
            item.get("ultimo_evento"), item.get("texto") or "",
        ]
        ws.append([
            re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", valor)
            if isinstance(valor, str) else valor for valor in valores
        ])
    for row in ws:
        for cell in row:
            if isinstance(cell.value, str):
                cell.data_type = "s"
            if isinstance(cell.value, datetime):
                cell.number_format = "dd/mm/yyyy hh:mm:ss"
            cell.alignment = Alignment(vertical="top", wrap_text=True)
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="1F2937")
    for i, largura in enumerate([24, 30, 23, 28, 14, 16, 16, 12, 12, 14, 23, 70], 1):
        ws.column_dimensions[ws.cell(1, i).column_letter].width = largura
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return send_file(
        buf, as_attachment=True,
        download_name=f"historico_publicacoes_avisos_{datetime.now():%Y%m%d_%H%M%S}.xlsx",
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )


@app.route("/aviso/<aviso_id>/eventos")
def aviso_eventos_online(aviso_id):
    # A consulta automatica nao renova o prazo de inatividade da sessao.
    g._portal_nao_renovar_auth = True
    periodo_inicio, periodo_fim, _, _, _, _ = _filtro_periodo_aviso_compat("aceites")
    usuario = current_user()
    if not usuario:
        return jsonify(erro="sessao_expirada"), 401
    if not pode_guia(usuario, "aviso"):
        return jsonify(erro="acesso_negado"), 403
    _, publicacao, registros, _ = acompanhamento_avisos(
        aviso_id,
        periodo_inicio=periodo_inicio,
        periodo_fim=periodo_fim,
    )
    if not publicacao:
        return jsonify(erro="aviso_nao_encontrado"), 404
    return render_template("aviso_eventos.html", registros=registros)


@app.route("/aviso/salvar", methods=["POST"])
@admin_required
def aviso_salvar():
    todos_ambientes = request.form.get("todos_ambientes") == "1"
    if todos_ambientes and not eh_master(current_user()):
        abort(403)
    if not todos_ambientes and not _destino_aviso_valido(publicar=True):
        return aviso(), 400
    texto = request.form.get("texto", "").strip()
    assunto = request.form.get("assunto", "").strip()
    inicio_em = request.form.get("inicio_em", "")
    fim_em = request.form.get("fim_em", "")
    if 1 <= len(texto) <= 300 and 1 <= len(assunto) <= 120:
        try:
            if todos_ambientes:
                ids = salvar_aviso_todos(current_user()["id"], texto, assunto=assunto, inicio_em=inicio_em, fim_em=fim_em)
                flash(f"Aviso publicado para todos os ambientes ativos ({len(ids)}).", "ok")
            else:
                salvar_aviso(texto, assunto=assunto, ator_id=current_user()["id"], inicio_em=inicio_em, fim_em=fim_em)
                flash("Aviso publicado para os usuários associados ao ambiente selecionado.", "ok")
        except ValueError as erro:
            flash(str(erro), "erro")
            if todos_ambientes:
                return redirect(url_for_sessao("aviso", ambiente=_AVISO_TODOS_AMBIENTES, aba="novo-aviso"))
            return aviso(), 400
        except PermissionError:
            abort(403)
    else:
        flash("Preencha o assunto (até 120 caracteres) e a mensagem (até 300 caracteres).", "erro")
        if todos_ambientes:
            return redirect(url_for_sessao("aviso", ambiente=_AVISO_TODOS_AMBIENTES, aba="novo-aviso"))
        return aviso(), 400
    if todos_ambientes:
        return redirect(url_for_sessao("aviso", ambiente=_AVISO_TODOS_AMBIENTES, aba="avisos-ativos"))
    return redirect(url_for_sessao("aviso", aba="avisos-ativos"))


@app.route("/aviso/remover", methods=["POST"])
@admin_required
def aviso_remover():
    if request.form.get("excluir_todos") == "1":
        # A operação em massa só pode ser disparada pelo formulário do
        # seletor "Todos os ambientes ativos". Não permita que um POST direto
        # em um ambiente específico seja interpretado como exclusão global.
        if not eh_master(current_user()) or request.args.get("ambiente") != _AVISO_TODOS_AMBIENTES:
            abort(403)
        try:
            total = remover_avisos_todos(current_user()["id"])
        except PermissionError:
            abort(403)
        flash(
            f"{total} aviso(s) ativo(s) removido(s) dos ambientes ativos. O histórico foi preservado.",
            "ok",
        )
        return redirect(url_for_sessao("aviso", ambiente=_AVISO_TODOS_AMBIENTES, aba="avisos-ativos"))
    if not _destino_aviso_valido():
        return aviso(), 400
    remover_aviso()
    flash("Aviso removido.", "ok")
    if request.form.get("todos_ambientes") == "1":
        return redirect(url_for_sessao("aviso", ambiente=_AVISO_TODOS_AMBIENTES, aba="avisos-ativos"))
    return redirect(url_for_sessao("aviso", aba="avisos-ativos"))



@app.route("/avisos/pendente")
def consultar_aviso_pendente():
    # Consultas periodicas nao devem prolongar uma sessao inativa.
    g._portal_nao_renovar_auth = True
    usuario = current_user()
    if not usuario:
        return jsonify(erro="sessao_expirada"), 401
    if eh_master(usuario):
        return jsonify(aviso=None)
    if request.args.get("fixado") == "1" and pode_guia(usuario, "dashboards"):
        return jsonify(aviso=aviso_pendente(usuario["id"]), fixado=carregar_aviso_dashboard())
    return jsonify(aviso=aviso_pendente(usuario["id"]))


def _evento_aviso_recebido():
    dados = request.get_json(silent=True)
    evento_id = dados.get("evento_id") if isinstance(dados, dict) else None
    if not isinstance(evento_id, str) or not re.fullmatch(r"[0-9a-f]{32}", evento_id):
        abort(400)
    return evento_id


@app.route("/avisos/<aviso_id>/visualizar", methods=["POST"])
def visualizar_aviso(aviso_id):
    g._portal_nao_renovar_auth = True
    usuario = current_user()
    if not usuario:
        return jsonify(erro="sessao_expirada"), 401
    if eh_master(usuario):
        return jsonify(erro="master_isento_de_avisos"), 403
    if not registrar_aviso(aviso_id, usuario["id"], _evento_aviso_recebido()):
        return jsonify(erro="aviso_desatualizado"), 409
    _notificar_evento_aviso()
    return jsonify(ok=True)


@app.route("/avisos/<aviso_id>/aceitar", methods=["POST"])
def aceitar_aviso(aviso_id):
    usuario = current_user()
    if not usuario:
        return jsonify(erro="sessao_expirada"), 401
    if eh_master(usuario):
        return jsonify(erro="master_isento_de_avisos"), 403
    dados = request.get_json(silent=True) or {}
    if not isinstance(dados, dict) or dados.get("concordo") is not True:
        return jsonify(erro="aceite_necessario"), 400
    if not registrar_aviso(aviso_id, usuario["id"], _evento_aviso_recebido(), aceitar=True):
        return jsonify(erro="aviso_desatualizado_ou_nao_exibido"), 409
    _notificar_evento_aviso()
    return jsonify(ok=True)


@app.route("/avisos/<aviso_id>/recusar", methods=["POST"])
def recusar_aviso(aviso_id):
    usuario = current_user()
    if not usuario:
        return jsonify(erro="sessao_expirada"), 401
    if eh_master(usuario):
        return jsonify(erro="master_isento_de_avisos"), 403
    if not registrar_aviso(aviso_id, usuario["id"], _evento_aviso_recebido(), recusar=True):
        return jsonify(erro="aviso_desatualizado_ou_ja_aceito"), 409
    _notificar_evento_aviso()
    return jsonify(ok=True)


def _data_curta(valor):
    """Formata timestamps do portal em linguagem curta para a visao geral."""
    if isinstance(valor, datetime):
        dt = valor
    else:
        try:
            dt = datetime.strptime(str(valor), "%Y-%m-%d %H:%M:%S")
        except (ValueError, TypeError):
            return str(valor or "—")
    hoje = datetime.now().date()
    if dt.date() == hoje:
        return f"Hoje, {dt.strftime('%H:%M')}"
    if dt.date() == hoje - timedelta(days=1):
        return f"Ontem, {dt.strftime('%H:%M')}"
    return dt.strftime("%d/%m/%Y %H:%M")


def registrar_evento_usuario(tipo, alvo=None, detalhe=""):
    ator = current_user()
    inserir_user_evento({
        "id": uuid.uuid4().hex,
        "data_hora": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "ator_id": ator.get("id") if ator else None,
        "ator_nome": ator.get("nome") if ator else "Sistema",
        "tipo": tipo,
        "usuario_id": alvo.get("id") if alvo else None,
        "usuario_nome": alvo.get("nome") if alvo else None,
        "detalhe": detalhe[:500],
    })


@app.route("/administracao")
@master_required
def administracao_master():
    tab = request.args.get("tab", "guias").strip().lower()
    if tab in {"ambiente", "ambientes", "permissoes_ambiente"}:
        # A tela de ambientes continua usando seu endpoint especializado, mas
        # agora entra pelo mesmo menu/guia da Administração do Master.
        valores = {}
        ambiente_id = request.args.get("ambiente_id", "").strip()
        if ambiente_id:
            valores["ambiente_id"] = ambiente_id
        return redirect(url_for_sessao("permissoes_ambiente", **valores))
    tab = "guias"
    usuarios = load_users()
    uid = request.args.get("uid", "")
    alvo = next((u for u in usuarios if u["id"] == uid), None)
    if alvo is None:
        alvo = next((u for u in usuarios if not eh_master(u)), current_user())
    return render_template("administracao_master.html", active="administracao", admin_tab=tab,
                           usuarios=usuarios, alvo=alvo, catalogo_guias=GUIAS,
                           guias_selecionadas=guias_efetivas(alvo),
                           ocultar_seletor_ambiente=True)


@app.route("/administracao/usuarios/<uid>/guias", methods=["POST"])
@master_required
def salvar_guias_master(uid):
    alvo = get_user(uid)
    if not alvo:
        abort(404)
    if eh_master(alvo):
        abort(403)
    acao = request.form.get("acao", "salvar")
    if acao != "salvar":
        abort(400)
    guias = request.form.getlist("guias")
    if any(guia not in IDS_GUIAS for guia in guias):
        abort(400)
    salvar_guias_usuario(current_user()["id"], uid, guias)
    registrar_evento_usuario("guias_atualizadas", alvo,
                            "Guias: " + (", ".join(sorted(set(guias))) or "nenhuma"))
    flash("Guias de acesso atualizadas.", "ok")
    return redirect(url_for_sessao("administracao_master", tab="guias", uid=uid))


@app.route("/usuarios")
@admin_required
def usuarios():
    data = load_data()
    lista_usuarios = [u for u in load_users() if eh_master(current_user()) or
                      (not eh_master(u) and u["id"] in usuarios_do_ambiente(contexto_ambiente()))]
    agora = datetime.now()
    limite_30d = agora - timedelta(days=30)
    ids_usuarios = {u.get("id") for u in lista_usuarios if u.get("id")}
    ids_dashboards = None if eh_master(current_user()) else _ids_dashboards_permitidos(current_user(), data)

    resumo_atividade = resumo_usuarios_acessos(
        ids_dashboards, ids_usuarios, limite_30d.strftime("%Y-%m-%d 00:00:00")
    )
    ativos_ids = resumo_atividade["ativos"]

    total = len(lista_usuarios)
    total_master = sum(1 for u in lista_usuarios if u.get("papel") == "master")
    admins = sum(1 for u in lista_usuarios if u.get("papel") == "admin")
    viewers = sum(1 for u in lista_usuarios if u.get("papel") == "viewer")
    total_inativos_30d = max(0, total - len(ativos_ids))
    sem_permissao_lista = [
        u for u in lista_usuarios
        if u.get("papel") == "viewer"
        and not u.get("pastas") and not u.get("subpastas") and not u.get("dashboards")
    ]

    # Datas auxiliares usadas pelos indicadores e gráficos.
    def _como_datetime(valor):
        if isinstance(valor, datetime):
            return valor
        if not valor:
            return None
        texto = str(valor).strip()
        for formato in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d"):
            try:
                return datetime.strptime(texto[:19] if "%H" in formato else texto[:10], formato)
            except (TypeError, ValueError):
                pass
        return None

    nomes_mes = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"]
    inicio_mes_atual = datetime(agora.year, agora.month, 1)
    meses_base = []
    for deslocamento in range(5, -1, -1):
        ano = inicio_mes_atual.year
        mes = inicio_mes_atual.month - deslocamento
        while mes <= 0:
            mes += 12
            ano -= 1
        meses_base.append(datetime(ano, mes, 1))

    def _proximo_mes(mes_ref):
        return datetime(mes_ref.year + (1 if mes_ref.month == 12 else 0), 1 if mes_ref.month == 12 else mes_ref.month + 1, 1)

    # Novos usuários nos últimos seis meses.
    novos_por_mes = []
    for mes_ref in meses_base:
        proximo = _proximo_mes(mes_ref)
        qtd = 0
        for usuario in lista_usuarios:
            criado = _como_datetime(usuario.get("criado_em"))
            if criado and mes_ref <= criado < proximo:
                qtd += 1
        novos_por_mes.append({"label": nomes_mes[mes_ref.month - 1], "valor": qtd})
    max_novos = max((item["valor"] for item in novos_por_mes), default=0) or 1
    for item in novos_por_mes:
        item["percentual"] = round(item["valor"] * 100 / max_novos, 2)
    novos_mes_atual = novos_por_mes[-1]["valor"] if novos_por_mes else 0

    # Último acesso de cada usuário em todo o histórico, respeitando o escopo.
    _, ultimos_globais = visao_global_acessos(ids_dashboards)
    ultimo_por_usuario = {
        item.get("usuario_id"): _como_datetime(item.get("data_hora"))
        for item in ultimos_globais
        if item.get("usuario_id") in ids_usuarios
    }

    usuarios_tabela = []
    for usuario in sorted(
        lista_usuarios,
        key=lambda item: (str(item.get("nome") or "").casefold(), str(item.get("usuario") or "").casefold()),
    ):
        papel = usuario.get("papel") or "viewer"
        nome = usuario.get("nome") or usuario.get("usuario") or "Usuário"
        partes = [parte for parte in nome.split() if parte]
        iniciais = ((partes[0][:1] if partes else "U") + (partes[-1][:1] if len(partes) > 1 else "")).upper()
        ultimo_dt = ultimo_por_usuario.get(usuario.get("id"))
        usuarios_tabela.append({
            "id": usuario.get("id"),
            "nome": nome,
            "login": usuario.get("usuario") or "—",
            "email": usuario.get("email") or "—",
            "papel": papel,
            "perfil": nome_perfil(papel),
            "iniciais": iniciais,
            "ativo_30d": usuario.get("id") in ativos_ids,
            "ultimo_acesso": _data_curta(ultimo_dt) if ultimo_dt else "—",
            "ultimo_acesso_sort": ultimo_dt.strftime("%Y-%m-%d %H:%M:%S") if ultimo_dt else "",
        })

    # Atividade de acesso dos últimos seis meses para os três gráficos da segunda linha.
    inicio_atividade = meses_base[0]
    contagem_mes = {(m.year, m.month): 0 for m in meses_base}
    contagem_semana = [0] * 7  # Seg..Dom
    heatmap_contagem = [[0 for _ in range(8)] for _ in range(7)]  # blocos de 3 horas

    filtros_atividade = {"de": inicio_atividade.strftime("%Y-%m-%d"), "status": "sucesso"}
    try:
        for acesso in iterar_acessos(filtros_atividade, ids_dashboards, tamanho_lote=1000):
            usuario_id = acesso.get("usuario_id")
            if usuario_id not in ids_usuarios:
                continue
            dt = _como_datetime(acesso.get("data_hora"))
            if not dt:
                continue
            chave_mes = (dt.year, dt.month)
            if chave_mes in contagem_mes:
                contagem_mes[chave_mes] += 1
            dia_semana = dt.weekday()
            contagem_semana[dia_semana] += 1
            faixa_hora = min(7, max(0, dt.hour // 3))
            heatmap_contagem[dia_semana][faixa_hora] += 1
    except Exception:
        # A tela continua disponível mesmo se o histórico de auditoria estiver indisponível.
        app.logger.exception("Falha ao montar gráficos de atividade da tela de usuários")

    acessos_por_mes = [
        {"label": nomes_mes[m.month - 1], "valor": contagem_mes[(m.year, m.month)]}
        for m in meses_base
    ]
    max_mes = max((item["valor"] for item in acessos_por_mes), default=0) or 1
    for item in acessos_por_mes:
        item["percentual"] = round(item["valor"] * 100 / max_mes, 2)

    dias_rotulo = ["Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom"]
    atividade_semana = [
        {"label": dias_rotulo[indice], "valor": valor}
        for indice, valor in enumerate(contagem_semana)
    ]
    max_semana = max(contagem_semana, default=0) or 1
    for item in atividade_semana:
        item["percentual"] = round(item["valor"] * 100 / max_semana, 2)

    max_heat = max((valor for linha in heatmap_contagem for valor in linha), default=0) or 1
    heatmap = []
    for indice, linha in enumerate(heatmap_contagem):
        heatmap.append({
            "label": dias_rotulo[indice],
            "celulas": [
                {
                    "valor": valor,
                    "intensidade": round(8 + (valor * 84 / max_heat), 1) if valor else 6,
                }
                for valor in linha
            ],
        })

    return render_template(
        "usuarios.html",
        active="usuarios",
        estado=get_estado_paineis(),
        total_usuarios=total,
        total_master=total_master,
        total_administradores=admins,
        total_viewers=viewers,
        total_ativos_30d=len(ativos_ids),
        total_inativos_30d=total_inativos_30d,
        total_sem_permissao=len(sem_permissao_lista),
        pct_master=(total_master * 100 / total) if total else 0,
        pct_administradores=(admins * 100 / total) if total else 0,
        pct_viewer=(viewers * 100 / total) if total else 0,
        pct_ativos=(len(ativos_ids) * 100 / total) if total else 0,
        pct_inativos=(total_inativos_30d * 100 / total) if total else 0,
        novos_mes_atual=novos_mes_atual,
        novos_por_mes=novos_por_mes,
        acessos_por_mes=acessos_por_mes,
        atividade_semana=atividade_semana,
        heatmap=heatmap,
        usuarios_tabela=usuarios_tabela,
    )


@app.route("/usuarios/administracao")
@admin_required
def usuarios_administracao():
    ator = current_user()
    data_completa = load_data()
    todos_usuarios = load_users()
    lista_usuarios = [u for u in todos_usuarios if pode_gerenciar_usuario(ator, u)]

    # Cada conta aparece uma única vez. Os ambientes associados ficam dentro
    # da seta da linha e não geram cópias do mesmo usuário na lista.
    usuarios_por_id = _ambientes_atribuidos_por_usuario(u.get("id") for u in lista_usuarios)
    lista_unica = []
    ids_vistos = set()
    for usuario in lista_usuarios:
        uid_usuario = usuario.get("id")
        if not uid_usuario or uid_usuario in ids_vistos:
            continue
        ids_vistos.add(uid_usuario)
        item = dict(usuario)
        ambientes_usuario = usuarios_por_id.get(uid_usuario, [])
        if not eh_master(ator) and contexto_ambiente():
            ambientes_usuario = [a for a in ambientes_usuario if a["id"] == contexto_ambiente()]
        item["ambientes_atribuidos"] = ambientes_usuario
        lista_unica.append(item)
    lista_usuarios = lista_unica

    uid = request.args.get("uid", "").strip()
    usuario_selecionado = next((u for u in lista_usuarios if u["id"] == uid), None)
    if usuario_selecionado is None and lista_usuarios:
        usuario_selecionado = lista_usuarios[0]

    # Para o Master, a ficha sempre começa no primeiro ambiente atribuído ao
    # usuário. A troca por outro ambiente ocorre somente pelo item expandido
    # da seta, sem alterar o ambiente da sessão do Master.
    ambiente_usuario = request.args.get("ambiente_usuario", "").strip()
    if usuario_selecionado and eh_master(ator):
        ambientes_usuario = usuario_selecionado.get("ambientes_atribuidos", [])
        ids_ambientes_usuario = {a["id"] for a in ambientes_usuario}
        if ambiente_usuario and ambiente_usuario not in ids_ambientes_usuario:
            abort(404)
        if not ambiente_usuario and ambientes_usuario:
            ambiente_usuario = ambientes_usuario[0]["id"]

    if eh_master(ator) and ambiente_usuario:
        data = _dados_do_ambiente(data_completa, ambiente_usuario)
    else:
        data = _dados_no_escopo_admin(ator, data_completa)

    # Também resolve o padrão ao abrir a Administração de Usuários. Assim um
    # Visualizador legado sem permissões já aparece como "Selecionar todos"
    # na primeira abertura da sua ficha.
    if usuario_selecionado and eh_master(ator) and aplicar_padrao_visualizador_se_necessario(usuario_selecionado, todos_usuarios):
        lista_usuarios = [u for u in load_users() if pode_gerenciar_usuario(ator, u)]
        ambientes_por_id = _ambientes_atribuidos_por_usuario(u.get("id") for u in lista_usuarios)
        lista_unica = []
        ids_vistos = set()
        for usuario in lista_usuarios:
            uid_usuario = usuario.get("id")
            if not uid_usuario or uid_usuario in ids_vistos:
                continue
            ids_vistos.add(uid_usuario)
            item = dict(usuario)
            item["ambientes_atribuidos"] = ambientes_por_id.get(uid_usuario, [])
            lista_unica.append(item)
        lista_usuarios = lista_unica
        usuario_selecionado = next(
            (u for u in lista_usuarios if u.get("id") == usuario_selecionado.get("id")),
            None,
        )
        if usuario_selecionado and not ambiente_usuario and usuario_selecionado.get("ambientes_atribuidos"):
            ambiente_usuario = usuario_selecionado["ambientes_atribuidos"][0]["id"]
            data = _dados_do_ambiente(data_completa, ambiente_usuario)

    dashboards_bloqueados = (
        carregar_dashboards_bloqueados(usuario_selecionado.get("id"))
        if usuario_selecionado else set()
    )
    subpastas_bloqueadas = (
        carregar_subpastas_bloqueadas(usuario_selecionado.get("id"))
        if usuario_selecionado else set()
    )
    return render_template(
        "usuarios_administracao.html",
        usuarios=lista_usuarios,
        usuario_selecionado=usuario_selecionado,
        dashboards_bloqueados=dashboards_bloqueados,
        subpastas_bloqueadas=subpastas_bloqueadas,
        pastas=data["pastas"],
        grupos=agrupar(data),
        active="usuarios_administracao",
        estado=get_estado_paineis(),
        ambiente_usuario_selecionado=ambiente_usuario,
        ocultar_seletor_ambiente=True,
    )


@app.route("/usuarios/cadastro")
@admin_required
def usuarios_cadastro():
    return _tela_cadastro_usuarios()


def _tela_cadastro_usuarios(**contexto):
    data = _dados_no_escopo_admin(current_user(), load_data())
    contexto.setdefault("ocultar_seletor_ambiente", eh_master(current_user()))
    return render_template("usuarios_cadastro.html",
                           pastas=data["pastas"], grupos=agrupar(data),
                           active="usuarios_cadastro", estado=get_estado_paineis(),
                           limite_importacao=LIMITE_USUARIOS, **contexto)


@app.get("/usuarios/cadastro/modelo.xlsx")
@admin_required
def modelo_importacao_usuarios():
    return send_file(modelo_usuarios_em_memoria(permite_admin=eh_master(current_user())),
                     as_attachment=True, download_name="modelo_usuarios.xlsx",
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


@app.post("/usuarios/cadastro/importar")
@admin_required
def importar_usuarios():
    arquivo = request.files.get("arquivo")
    if not arquivo or not (arquivo.filename or "").lower().endswith(".xlsx"):
        return _tela_cadastro_usuarios(erro_importacao="Selecione uma planilha .xlsx."), 400
    try:
        linhas, erros = ler_importacao(arquivo.stream.read(LIMITE_ARQUIVO + 1), load_users(),
                                      permite_admin=eh_master(current_user()))
    except ValueError as exc:
        return _tela_cadastro_usuarios(erro_importacao=str(exc)), 400
    except Exception:
        app.logger.exception("Falha ao ler planilha de cadastro de usuários")
        return _tela_cadastro_usuarios(erro_importacao="Arquivo inválido. Baixe novamente o modelo e preencha os dados."), 400
    if erros:
        return _tela_cadastro_usuarios(erros_importacao=erros,
            erro_importacao="Nenhum usuário foi cadastrado. Corrija as linhas indicadas e importe novamente."), 400
    novos = [_nova_conta(linha["nome"], linha["usuario"], linha["papel"], linha.get("email")) for linha in linhas]
    try:
        inserir_novos_usuarios(novos, current_user(), origem="Importação XLSX")
    except PermissionError:
        abort(403, description="Somente o Master pode cadastrar Administradores.")
    except ValueError as exc:
        return _tela_cadastro_usuarios(erro_importacao=str(exc)), 409
    except IntegrityError:
        return _tela_cadastro_usuarios(erro_importacao="Os dados foram alterados durante a importação ou um login já existe. Nenhum usuário foi cadastrado. Revise a planilha e tente novamente."), 409
    except MySQLError:
        app.logger.exception("Falha na transação de importação de usuários")
        return _tela_cadastro_usuarios(erro_importacao="Não foi possível concluir a importação. Consulte os usuários cadastrados antes de tentar novamente."), 503
    # O resultado assinado pertence ao autor do cadastro. Não armazena senhas
    # atuais nem depende de dados editáveis enviados de volta pelo navegador.
    token = _exportacao_usuarios_serializer().dumps({
        "ator_id": current_user()["id"], "ambiente_id": contexto_ambiente(), "linhas": linhas, "senha_inicial": SENHA_INICIAL,
    })
    return _tela_cadastro_usuarios(usuarios_importados=linhas,
        exportacao_usuarios_token=token, senha_inicial=SENHA_INICIAL)


def _exportacao_usuarios_serializer():
    return URLSafeTimedSerializer(app.secret_key, salt="portal-bi-exportacao-usuarios-v1")


@app.post("/usuarios/cadastro/exportar.xlsx")
@admin_required
def exportar_usuarios_importados():
    try:
        lote = _exportacao_usuarios_serializer().loads(request.form.get("lote", ""))
    except BadSignature:
        abort(400, description="Resultado de importação inválido. Use o botão na tabela de usuários cadastrados.")
    if not isinstance(lote, dict) or lote.get("ator_id") != current_user()["id"]:
        abort(403)
    if not eh_master(current_user()) and lote.get("ambiente_id", "inicial") != contexto_ambiente():
        abort(403)
    linhas = lote.get("linhas")
    if not isinstance(linhas, list) or not 1 <= len(linhas) <= LIMITE_USUARIOS:
        abort(400)
    wb = Workbook()
    ws = wb.active
    ws.title = "Usuários cadastrados"
    ws.append(["Linha", "Nome completo", "Login", "E-mail", "Perfil", "Senha inicial"])
    larguras = [9, 42, 32, 48, 21, 23]
    for item in linhas:
        ws.append([item["linha"], item["nome"], item["usuario"], item.get("email") or "",
                   nome_perfil(item["papel"]), lote["senha_inicial"]])
    for row in ws:
        for cell in row:
            if isinstance(cell.value, str):
                # Dados do cadastro são texto, inclusive endereços começados com '+'.
                cell.data_type = "s"
                cell.number_format = "@"
            cell.alignment = Alignment(vertical="center", wrap_text=True)
            cell.font = Font(name="Calibri", size=11, color="263447")
            if cell.row > 1 and cell.row % 2 == 0:
                cell.fill = PatternFill("solid", fgColor="F2F5FA")
        linhas_texto = max((len(str(c.value or "")) + max(1, int(larguras[i] * .85)) - 1)
                           // max(1, int(larguras[i] * .85)) for i, c in enumerate(row))
        ws.row_dimensions[row[0].row].height = max(34, 16 * linhas_texto + 8)
    for cell in ws[1]:
        cell.font = Font(name="Calibri", size=11, bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="1C2536")
    for i, largura in enumerate(larguras, 1):
        ws.column_dimensions[ws.cell(1, i).column_letter].width = largura
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    nota = ws.max_row + 3
    ws.merge_cells(start_row=nota, start_column=1, end_row=nota, end_column=6)
    ws.cell(nota, 1, "Senha inicial fornecida no cadastro. A troca é obrigatória no primeiro acesso; após a troca, vale a senha definida pelo usuário.")
    ws.cell(nota, 1).alignment = Alignment(wrap_text=True, vertical="center")
    ws.cell(nota, 1).font = Font(name="Calibri", size=10, color="667085")
    ws.row_dimensions[nota].height = 32
    arquivo = io.BytesIO()
    wb.save(arquivo)
    wb.close()
    arquivo.seek(0)
    return send_file(arquivo, as_attachment=True,
                     download_name="usuarios_cadastrados.xlsx",
                     mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


def filtrar_acessos(registros, args):
    """Aplica os mesmos filtros da tela (texto, periodo, usuario, pasta,
    dashboard, status) usando parametros de querystring. Usado tanto para
    exibir quanto para exportar exatamente o que esta filtrado."""
    q = (args.get("q") or "").strip().lower()
    de = (args.get("de") or "").strip()
    ate = (args.get("ate") or "").strip()
    usuario = (args.get("usuario") or "").strip()
    pasta = (args.get("pasta") or "").strip()
    dashboard = (args.get("dashboard") or "").strip()
    status = (args.get("status") or "").strip()

    def bate(a):
        if q:
            alvo = f"{a['usuario_nome']} {a['usuario_login']} {a['dashboard_nome']} {a['pasta_nome']}".lower()
            if q not in alvo:
                return False
        data_registro = a["data_hora"][:10]
        if de and data_registro < de:
            return False
        if ate and data_registro > ate:
            return False
        if usuario and a["usuario_login"] != usuario:
            return False
        if pasta and a["pasta_nome"] != pasta:
            return False
        if dashboard and a["dashboard_nome"] != dashboard:
            return False
        if status and a.get("status", "sucesso") != status:
            return False
        return True

    return [a for a in registros if bate(a)]


def _rotulo_dashboard_acessos(pasta_nome, dashboard_nome):
    """Mesmo formato de identificação usado nos favoritos da barra lateral."""
    return f"{pasta_nome} - {dashboard_nome}" if pasta_nome else dashboard_nome


def estatisticas_periodo(registros, data=None):
    """Estatisticas que respeitam TODOS os filtros ativos no topo da
    pagina (texto, periodo, usuario, pasta, dashboard): total de
    acessos, usuarios unicos, tentativas bloqueadas, acessos hoje,
    acessos nos ultimos 7 dias, dashboard mais acessado e ranking."""
    sucessos = [a for a in registros if a.get("status", "sucesso") == "sucesso"]
    negados = [a for a in registros if a.get("status") == "negado"]

    hoje = datetime.now().date()
    hoje_str = hoje.strftime("%Y-%m-%d")
    semana_str = (hoje - timedelta(days=7)).strftime("%Y-%m-%d")
    acessos_hoje = sum(1 for a in sucessos if a["data_hora"][:10] == hoje_str)
    acessos_semana = sum(1 for a in sucessos if a["data_hora"][:10] >= semana_str)

    usuarios_unicos = {a["usuario_login"] for a in sucessos}
    dashboards = {d["id"]: d for d in (data or {}).get("dashboards", [])}
    pastas = {p["id"]: p["nome"] for p in (data or {}).get("pastas", [])}
    contagem_dash = {}
    ultimo_por_dash = {}
    for a in sucessos:
        # Nomes repetidos não identificam o mesmo dashboard. O fallback só
        # atende registros legados sem ID e mantém as pastas separadas.
        chave = ("id", a["dashboard_id"]) if a.get("dashboard_id") else (
            "legado", a.get("pasta_nome", ""), a["dashboard_nome"]
        )
        contagem_dash[chave] = contagem_dash.get(chave, 0) + 1
        if chave not in ultimo_por_dash or a["data_hora"] > ultimo_por_dash[chave]["data_hora"]:
            ultimo_por_dash[chave] = a
    ranking = []
    for chave, qtd in sorted(contagem_dash.items(), key=lambda x: x[1], reverse=True)[:10]:
        acesso = ultimo_por_dash[chave]
        dashboard = dashboards.get(acesso.get("dashboard_id"))
        nome = dashboard["nome"] if dashboard else acesso["dashboard_nome"]
        pasta_nome = pastas.get(dashboard.get("pasta_id"), acesso.get("pasta_nome", "")) if dashboard else acesso.get("pasta_nome", "")
        ranking.append((_rotulo_dashboard_acessos(pasta_nome, nome), qtd))
    dash_mais_acessado = ranking[0][0] if ranking else "—"

    return {
        "total": len(sucessos),
        "total_negados": len(negados),
        "usuarios_unicos": len(usuarios_unicos),
        "acessos_hoje": acessos_hoje,
        "acessos_semana": acessos_semana,
        "dash_mais_acessado": dash_mais_acessado,
        "ranking": ranking,
    }


def estatisticas_globais(todos, data):
    """Estatisticas sempre calculadas sobre o historico completo, sem
    depender dos filtros: dashboards nunca acessados e ultimo acesso de
    cada usuario (informacoes que perdem o sentido se restritas a um
    recorte arbitrario de filtros)."""
    sucessos = [a for a in todos if a.get("status", "sucesso") == "sucesso"]

    acessados_ids = {a["dashboard_id"] for a in sucessos}
    pastas = {p["id"]: p["nome"] for p in data.get("pastas", [])}
    nunca_acessados = [
        dict(d, nome_exibicao=_rotulo_dashboard_acessos(
            pastas.get(d.get("pasta_id"), ""), d["nome"]
        ))
        for d in data["dashboards"] if d["id"] not in acessados_ids
    ]

    ultimo_por_usuario = {}
    for a in sucessos:
        login = a["usuario_login"]
        if login not in ultimo_por_usuario or a["data_hora"] > ultimo_por_usuario[login]["data_hora"]:
            ultimo_por_usuario[login] = a
    ultimos_acessos = sorted(ultimo_por_usuario.values(), key=lambda a: a["data_hora"], reverse=True)
    for u in ultimos_acessos:
        u["data_hora_exibicao"] = formatar_data_hora(u["data_hora"])

    return {
        "nunca_acessados": nunca_acessados,
        "ultimos_acessos": ultimos_acessos,
    }


def calcular_grafico(registros_filtrados, de, ate):
    """Monta os dados do grafico de acessos por dia, respeitando os
    filtros ativos (o registros_filtrados ja vem filtrado por texto,
    usuario, pasta e dashboard). Se um periodo (De/Ate) estiver
    selecionado, o grafico passa a mostrar exatamente esse intervalo
    (limitado a 60 dias, para nao ficar ilegivel); sem periodo, mostra
    os ultimos 14 dias, como padrao."""
    hoje = datetime.now().date()
    fim = datetime.strptime(ate, "%Y-%m-%d").date() if ate else hoje
    if de:
        inicio = datetime.strptime(de, "%Y-%m-%d").date()
    else:
        inicio = fim - timedelta(days=13)
    if (fim - inicio).days > 59:
        inicio = fim - timedelta(days=59)
    if inicio > fim:
        inicio, fim = fim, inicio

    dias = []
    d = inicio
    while d <= fim:
        dias.append(d)
        d += timedelta(days=1)

    contagem_dia = {d.strftime("%Y-%m-%d"): 0 for d in dias}
    sucessos = [a for a in registros_filtrados if a.get("status", "sucesso") == "sucesso"]
    for a in sucessos:
        chave = a["data_hora"][:10]
        if chave in contagem_dia:
            contagem_dia[chave] += 1

    grafico = [{"label": d.strftime("%d/%m"), "valor": contagem_dia[d.strftime("%Y-%m-%d")]} for d in dias]
    grafico_max = max([g["valor"] for g in grafico] + [1])
    return grafico, grafico_max


def estatisticas_acessos_agregadas(data, filtros, dashboard_ids=None):
    """Monta a mesma visão de Acessos usando agregações do banco.

    Os registros individuais deixam de atravessar o Flask; somente totais e
    listas pequenas (top 10, dias do gráfico e último acesso por usuário)
    chegam à camada de apresentação.
    """
    hoje = datetime.now().date()
    hoje_texto = hoje.strftime("%Y-%m-%d")
    semana_texto = (hoje - timedelta(days=7)).strftime("%Y-%m-%d")
    resumo = resumo_acessos(filtros, dashboard_ids, hoje_texto, semana_texto)
    ranking_bruto = ranking_acessos(filtros, dashboard_ids)
    dashboards_por_id = {d["id"]: d for d in data.get("dashboards", [])}
    pastas_por_id = {p["id"]: p["nome"] for p in data.get("pastas", [])}
    ranking = []
    for item in ranking_bruto:
        dashboard = dashboards_por_id.get(item.get("dashboard_id"))
        nome = dashboard.get("nome") if dashboard else item.get("dashboard_nome", "")
        pasta_nome = (pastas_por_id.get(dashboard.get("pasta_id")) if dashboard else None) or item.get("pasta_nome", "")
        ranking.append((_rotulo_dashboard_acessos(pasta_nome, nome), int(item.get("quantidade") or 0)))

    acessados, ultimos = visao_global_acessos(dashboard_ids)
    nunca_acessados = [
        dict(d, nome_exibicao=_rotulo_dashboard_acessos(pastas_por_id.get(d.get("pasta_id"), ""), d["nome"]))
        for d in data.get("dashboards", []) if d.get("id") not in acessados
    ]
    for item in ultimos:
        item["data_hora_exibicao"] = formatar_data_hora(item.get("data_hora", ""))

    fim = datetime.strptime(filtros["ate"], "%Y-%m-%d").date() if filtros.get("ate") else hoje
    inicio = datetime.strptime(filtros["de"], "%Y-%m-%d").date() if filtros.get("de") else fim - timedelta(days=13)
    if (fim - inicio).days > 59:
        inicio = fim - timedelta(days=59)
    if inicio > fim:
        inicio, fim = fim, inicio
    agrupados = {
        item["dia"]: int(item.get("quantidade") or 0)
        for item in grafico_acessos(filtros, dashboard_ids, inicio.strftime("%Y-%m-%d"), fim.strftime("%Y-%m-%d"))
    }
    grafico = []
    dia = inicio
    while dia <= fim:
        chave = dia.strftime("%Y-%m-%d")
        grafico.append({"label": dia.strftime("%d/%m"), "valor": agrupados.get(chave, 0)})
        dia += timedelta(days=1)

    return {
        "total": int(resumo.get("total") or 0),
        "usuarios_unicos": int(resumo.get("usuarios_unicos") or 0),
        "total_negados": int(resumo.get("total_negados") or 0),
        "acessos_hoje": int(resumo.get("acessos_hoje") or 0),
        "acessos_semana": int(resumo.get("acessos_semana") or 0),
        "ranking": ranking,
        "dash_mais_acessado": ranking[0][0] if ranking else "—",
        "nunca_acessados": nunca_acessados,
        "ultimos_acessos": ultimos,
        "grafico": grafico,
        "grafico_max": max([item["valor"] for item in grafico] + [1]),
    }


@app.route("/acessos")
@admin_required
def acessos():
    abas_validas = {"visao-geral", "historico", "usuarios", "dashboards"}
    aba = (request.args.get("aba") or "visao-geral").strip().lower()
    if aba not in abas_validas:
        aba = "visao-geral"

    filtros = {
        "q": (request.args.get("q") or "").strip(),
        "de": (request.args.get("de") or "").strip(),
        "ate": (request.args.get("ate") or "").strip(),
        "usuario": (request.args.get("usuario") or "").strip(),
        "ambiente": (request.args.get("ambiente") or "").strip(),
        "dashboard": (request.args.get("dashboard") or "").strip(),
        "status": (request.args.get("status") or "").strip(),
    }
    filtro_ativo = any(filtros.values())
    usuario_atual = current_user()
    ambientes_filtro = listar_ambientes() if eh_master(usuario_atual) else ambientes_disponiveis(usuario_atual)
    ambiente_contexto = contexto_ambiente()
    if ambiente_contexto:
        ambientes_filtro = [a for a in ambientes_filtro if a.get("id") == ambiente_contexto]
    try:
        pagina_atual = max(1, int(request.args.get("pagina", "1")))
    except (TypeError, ValueError):
        pagina_atual = 1
    tamanho_pagina = 50
    total_paginas = 1

    if aba == "historico":
        # A aba de auditoria pode crescer indefinidamente. Ela consulta só a
        # página visível no banco, mantendo o mesmo filtro e escopo efetivo
        # que a versão anterior aplicava em memória.
        ids_dashboards = None if eh_master(current_user()) else _ids_dashboards_permitidos(current_user())
        registros, total_registros = pagina_acessos(
            filtros, ids_dashboards, pagina_atual, tamanho_pagina
        )
        total_paginas = max(1, (total_registros + tamanho_pagina - 1) // tamanho_pagina)
        if pagina_atual > total_paginas:
            pagina_atual = total_paginas
            registros, total_registros = pagina_acessos(
                filtros, ids_dashboards, pagina_atual, tamanho_pagina
            )
        usuarios_opcoes, ambientes_opcoes, dashboards_opcoes = opcoes_acessos(ids_dashboards, ambientes_filtro)
        stats = {}
    else:
        data = _dados_no_escopo_admin(current_user(), load_data())
        ids_dashboards = None if eh_master(current_user()) else _ids_dashboards_permitidos(current_user(), data)
        stats = estatisticas_acessos_agregadas(data, filtros, ids_dashboards)
        # As abas analíticas não exibem a tabela de eventos; manter essa lista
        # vazia evita transferir todo o histórico apenas para montar o layout.
        registros = []
        total_registros = stats["total"]
        usuarios_opcoes, ambientes_opcoes, dashboards_opcoes = opcoes_acessos(ids_dashboards, ambientes_filtro)

    for r in registros:
        r["data_hora_exibicao"] = formatar_data_hora(r["data_hora"])

    # monta o link de exportacao ja com todos os filtros ativos aplicados
    export_params = {k: v for k, v in filtros.items() if v}
    export_href = url_for_sessao("exportar_acessos", **export_params)
    pagina_params = dict(export_params, aba="historico")
    pagina_anterior_href = url_for_sessao("acessos", pagina=pagina_atual - 1, **pagina_params) if pagina_atual > 1 else None
    pagina_proxima_href = url_for_sessao("acessos", pagina=pagina_atual + 1, **pagina_params) if pagina_atual < total_paginas else None

    return render_template("acessos.html", registros=registros, active="acessos",
                           estado=get_estado_paineis(), stats=stats,
                           aba=aba,
                           filtros=filtros, filtro_ativo=filtro_ativo,
                           export_href=export_href,
                           usuarios_opcoes=usuarios_opcoes,
                           ambientes_opcoes=ambientes_opcoes,
                           dashboards_opcoes=dashboards_opcoes,
                           total_registros=total_registros,
                           pagina_atual=pagina_atual,
                           total_paginas=total_paginas,
                           pagina_anterior_href=pagina_anterior_href,
                           pagina_proxima_href=pagina_proxima_href)


@app.route("/acessos/exportar")
@admin_required
def exportar_acessos():
    usuario_atual = current_user()
    ids_dashboards = None if eh_master(usuario_atual) else _ids_dashboards_permitidos(usuario_atual)
    cabecalho = ["Data/Hora", "Usuário", "Perfil", "Dashboard", "Ambiente", "Status", "IP"]
    larguras = [20, 32, 20, 40, 32, 14, 24]
    arquivo_temporario = NamedTemporaryFile(prefix="portalbi_acessos_", suffix=".xlsx", delete=False)
    caminho_arquivo = arquivo_temporario.name
    arquivo_temporario.close()

    try:
        wb = Workbook(write_only=True)

        def nova_planilha(numero):
            planilha = wb.create_sheet(title=f"Acessos {numero}" if numero > 1 else "Acessos")
            planilha.freeze_panes = "A2"
            for coluna, largura in zip("ABCDEFG", larguras):
                planilha.column_dimensions[coluna].width = largura
            celulas = []
            for titulo in cabecalho:
                celula = WriteOnlyCell(planilha, value=titulo)
                celula.font = Font(bold=True, color="FFFFFF")
                celula.fill = PatternFill("solid", fgColor="1F4E78")
                celulas.append(celula)
            planilha.append(celulas)
            return planilha

        planilha = nova_planilha(1)
        linhas_na_planilha = 0
        numero_planilha = 1
        # O limite físico de uma planilha Excel é 1.048.576 linhas, incluindo
        # o cabeçalho. Arquivos maiores continuam completos em novas abas.
        limite_linhas = 1_048_575
        for acesso in iterar_acessos(request.args, ids_dashboards):
            if linhas_na_planilha >= limite_linhas:
                numero_planilha += 1
                planilha = nova_planilha(numero_planilha)
                linhas_na_planilha = 0
            planilha.append([
                formatar_data_hora(acesso.get("data_hora", "")),
                acesso.get("usuario_login", ""),
                nome_perfil(acesso.get("usuario_papel", "viewer")),
                acesso.get("dashboard_nome", ""),
                acesso.get("ambiente_nome") or acesso.get("ambiente_id") or "",
                "Sucesso" if acesso.get("status", "sucesso") == "sucesso" else "Negado",
                acesso.get("ip", ""),
            ])
            linhas_na_planilha += 1

        wb.save(caminho_arquivo)
        wb.close()
    except Exception:
        if os.path.exists(caminho_arquivo):
            os.remove(caminho_arquivo)
        raise

    nome_arquivo = f"acessos_portal_bi_{datetime.now().strftime('%Y%m%d_%H%M')}.xlsx"
    resposta = send_file(
        caminho_arquivo, as_attachment=True, download_name=nome_arquivo,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )
    resposta.call_on_close(lambda: os.path.exists(caminho_arquivo) and os.remove(caminho_arquivo))
    return resposta


# ===========================================================================
# Acoes: pastas (admin)
# ===========================================================================
def _preparar_estrutura_master():
    """Retira o filtro de ambiente ao alterar a estrutura como Master.

    O Master pode abrir uma tela com ``?ambiente=...`` para consultar um
    cliente. A gravação de uma pasta/subpasta, porém, precisa validar o
    snapshot completo; caso contrário o filtro da consulta faz o banco
    interpretar os demais ambientes como itens removidos ou fora do escopo.
    """
    if eh_master(current_user()):
        g._portal_ambiente_id = None


def _ambiente_destino_cadastro(chave_form="ambiente_id"):
    """Resolve o destino informado pelo formulário da tela Cadastro."""
    # Em ações POST, o valor enviado pelo seletor no instante do envio é a
    # fonte correta. A query string só representa o estado usado para renderizar
    # a página e pode estar desatualizada se o formulário tiver sido alterado.
    if chave_form in request.form:
        return (request.form.get(chave_form) or "").strip()
    if "ambiente_cadastro" in request.args:
        return (request.args.get("ambiente_cadastro") or "").strip()
    return (contexto_ambiente() or "").strip()


def _redirecionar_estrutura(rota, ambiente_id=None, cadastro_id=None):
    valores = {}
    usuario = current_user()
    if eh_master(usuario):
        if rota == "cadastro":
            # O parâmetro global preserva a árvore lateral. O filtro da guia
            # Cadastro segue em uma chave independente.
            if "ambiente" in request.args:
                valores["ambiente"] = request.args.get("ambiente", "")
            elif contexto_ambiente():
                valores["ambiente"] = contexto_ambiente()
            if "ambiente_cadastro" in request.args:
                valores["ambiente_cadastro"] = request.args.get("ambiente_cadastro", "")
            elif ambiente_id:
                valores["ambiente_cadastro"] = ambiente_id
        elif ambiente_id:
            valores["ambiente"] = ambiente_id
    if rota == "cadastro" and cadastro_id:
        valores["cadastro_id"] = cadastro_id
    return redirect(url_for_sessao(rota, **valores))


@app.route("/pasta/criar", methods=["POST"])
@admin_required
def criar_pasta():
    nome = request.form.get("nome_pasta", "").strip()
    retorno = request.form.get("retorno", "").strip()
    ambiente_id = (request.form.get("ambiente_id") or "").strip()
    solicitacao_async = _solicitacao_assincrona_json()
    mensagem = ""
    categoria = "erro"
    status = 400
    pasta_id = None
    ambiente_nome = ""
    ja_existia = False
    folder_submission_id = (request.form.get("folder_submission_id") or "").strip().lower()
    if not re.fullmatch(r"[0-9a-f]{32}", folder_submission_id):
        mensagem = "O formulário ficou desatualizado. Atualize a página e tente criar a pasta novamente."
    elif not nome:
        mensagem = "Informe o nome da pasta."
    elif len(nome) > 255:
        mensagem = "O nome da pasta deve ter no máximo 255 caracteres."
    else:
        try:
            usuario = current_user()
            if eh_master(usuario):
                ambientes = listar_ambientes()
                # O Master precisa informar explicitamente o ambiente no
                # seletor da tela de Cadastro. Nunca silenciosamente jogue a
                # nova pasta no Ambiente inicial.
                ambiente_id = _ambiente_destino_cadastro()
                ambiente = next((a for a in ambientes if a["id"] == ambiente_id), None)
                if not ambiente:
                    ambiente_id = None
                    raise ValueError("Selecione um ambiente válido para criar a pasta.")
                ambiente_nome = ambiente.get("nome") or ambiente_id
                _preparar_estrutura_master()
            else:
                ambiente_id = contexto_ambiente()
                if not ambiente_id or ambiente_id == "__sem_ambiente__":
                    raise ValueError("Selecione um ambiente antes de criar a pasta.")
                ambientes = listar_ambientes(usuario_id=usuario.get("id"))
                ambiente = next((a for a in ambientes if a["id"] == ambiente_id), None)
                ambiente_nome = (ambiente or {}).get("nome") or ambiente_id
            pasta_id, ja_existia = inserir_pasta(
                nome, ambiente_id,
                usuario_id=usuario.get("id"), papel=usuario.get("papel"),
                idempotency_id=folder_submission_id, retornar_status=True,
            )
        except (ValueError, PermissionError, ConflitoGravacao) as exc:
            mensagem = str(exc) if str(exc) else "Não foi possível criar a pasta."
            status = 409 if isinstance(exc, ConflitoGravacao) else 400
        except IntegrityError:
            app.logger.exception("Conflito ao criar pasta no banco")
            mensagem = "O banco rejeitou a pasta. Verifique se já existe uma pasta com esse nome neste ambiente."
            status = 409
        except MySQLError:
            app.logger.exception("Falha ao criar pasta")
            mensagem = "Não foi possível criar a pasta. Confira a conexão com o banco e tente novamente."
            status = 500
        except Exception as exc:
            if isinstance(exc, HTTPException):
                raise
            app.logger.exception("Erro inesperado ao criar pasta")
            mensagem = "O servidor encontrou um erro inesperado ao criar a pasta. Tente novamente."
            status = 500
        else:
            mensagem = (
                f'A pasta "{nome}" já havia sido gravada no ambiente "{ambiente_nome}". Não houve duplicidade.'
                if ja_existia else f'Pasta "{nome}" criada no ambiente "{ambiente_nome}".'
            )
            categoria = "ok"
            status = 200 if ja_existia else 201

    if solicitacao_async:
        return jsonify(
            ok=categoria == "ok",
            mensagem=mensagem,
            pasta_id=pasta_id,
            ambiente_id=ambiente_id,
            ja_existia=ja_existia,
        ), status

    flash(mensagem, categoria)
    rota_retorno = "cadastro" if retorno == "cadastro" else "dashboards_administracao"
    return _redirecionar_estrutura(rota_retorno, ambiente_id)


def _redirecionar_estrutura_admin(token, retorno):
    """Volta para a tela que iniciou a edição da estrutura."""
    return redirect(url_for_sessao("dashboards_administracao", tab="dashboards", estrutura=token))


@app.route("/pasta/renomear/<pasta_id>", methods=["POST"])
@admin_required
def renomear_pasta(pasta_id):
    novo = request.form.get("nome_pasta", "").strip()
    retorno = request.form.get("retorno", "")
    if novo:
        renomear_pasta_pontual(pasta_id, novo)
        flash(f"Pasta renomeada para \"{novo}\" com sucesso.", "ok")
    return _redirecionar_estrutura_admin(f"p:{pasta_id}", retorno)


@app.route("/pasta/excluir/<pasta_id>", methods=["POST"])
@admin_required
def excluir_pasta(pasta_id):
    usuario = current_user()
    retorno = request.form.get("retorno", "").strip().lower()
    data = (
        _dados_cadastro_master_da_requisicao()
        if eh_master(usuario) and retorno == "cadastro" else load_data()
    )
    pasta = next((p for p in data["pastas"] if p["id"] == pasta_id), None)
    if not pasta:
        abort(404, description="Pasta não encontrada neste ambiente.")
    nome_pasta = pasta.get("nome", "Pasta")
    ambiente_id = pasta.get("ambiente_id") or INICIAL
    ambiente = next((a for a in listar_ambientes() if a.get("id") == ambiente_id), None)
    nome_ambiente = ambiente.get("nome") if ambiente else ambiente_id
    # ids dos dashboards/subpastas que serao removidos junto com a pasta
    dash_ids = {d["id"] for d in data["dashboards"] if d.get("pasta_id") == pasta_id}
    sub_ids = {sp["id"] for sp in data.get("subpastas", []) if sp.get("pasta_id") == pasta_id}
    excluir_pasta_pontual(pasta_id, sub_ids, dash_ids)
    remover_bloqueios_dashboard(dash_ids)
    remover_bloqueios_subpasta(sub_ids)
    flash(f'Pasta "{nome_pasta}" excluída com sucesso do ambiente "{nome_ambiente}".', "ok")
    return redirect(url_for_sessao("dashboards_administracao", tab="dashboards"))


# ===========================================================================
# Acoes: subpastas (admin)
# ===========================================================================
@app.route("/subpasta/criar", methods=["POST"])
@admin_required
def criar_subpasta():
    nome = request.form.get("nome_subpasta", "").strip()
    pasta_id = request.form.get("pasta_id", "").strip()
    parent_subpasta_id = request.form.get("parent_subpasta_id", "").strip() or None
    retorno = request.form.get("retorno", "").strip()
    usuario = current_user()
    ambiente_selecionado = (request.form.get("ambiente_id") or "").strip()
    ambiente_master_invalido = False
    if eh_master(usuario):
        ambientes = listar_ambientes()
        ids_ambientes = {a["id"] for a in ambientes}
        ambiente_selecionado = _ambiente_destino_cadastro()
        ambiente_master_invalido = ambiente_selecionado not in ids_ambientes
        if ambiente_master_invalido:
            flash("Selecione um ambiente válido antes de criar a subpasta.", "erro")
        _preparar_estrutura_master()
    data = load_data()

    pasta = next((p for p in data["pastas"] if p["id"] == pasta_id), None)
    pasta_ambiente = (pasta.get("ambiente_id") or INICIAL) if pasta else None
    pasta_valida = (
        pasta is not None
        and not ambiente_master_invalido
        and (not eh_master(usuario) or pasta_ambiente == ambiente_selecionado)
    )
    sub_por_id = {sp["id"]: sp for sp in data.get("subpastas", [])}
    parent = sub_por_id.get(parent_subpasta_id) if parent_subpasta_id else None
    parent_valido = parent_subpasta_id is None or (
        parent is not None
        and parent.get("pasta_id") == pasta_id
        and _subpasta_nivel(parent_subpasta_id, sub_por_id) < 3
    )

    if nome and pasta_valida and parent_valido:
        try:
            inserir_subpasta(nome, pasta_id, parent_subpasta_id)
        except (ValueError, PermissionError, ConflitoGravacao, IntegrityError) as exc:
            flash(str(exc) if str(exc) else "Não foi possível criar a subpasta.", "erro")
        except MySQLError:
            app.logger.exception("Falha ao criar subpasta")
            flash("Não foi possível criar a subpasta. Confira a conexão com o banco e tente novamente.", "erro")
        else:
            novo_nivel = 1 if not parent_subpasta_id else _subpasta_nivel(parent_subpasta_id, sub_por_id) + 1
            tipo = {1: "Divisão", 2: "Tema", 3: "Subnível"}.get(novo_nivel, "Subpasta")
            flash(f'{tipo} "{nome}" criado com sucesso.', "ok")
    else:
        if not ambiente_master_invalido:
            flash("Confira a pasta, o nível superior escolhido e o nome da subpasta.", "erro")
    rota_retorno = "cadastro" if retorno == "cadastro" else "dashboards_administracao"
    ambiente_id = (
        ambiente_selecionado if eh_master(usuario) and not ambiente_master_invalido
        else (None if eh_master(usuario) else pasta_ambiente)
    )
    return _redirecionar_estrutura(rota_retorno, ambiente_id)


@app.route("/subpasta/renomear/<subpasta_id>", methods=["POST"])
@admin_required
def renomear_subpasta(subpasta_id):
    novo = request.form.get("nome_subpasta", "").strip()
    retorno = request.form.get("retorno", "")
    data = load_data()
    subpasta = next((sp for sp in data.get("subpastas", []) if sp["id"] == subpasta_id), None)
    if subpasta and novo:
        renomear_subpasta_pontual(subpasta_id, novo)
        flash(f"Subpasta renomeada para \"{novo}\" com sucesso.", "ok")
    return _redirecionar_estrutura_admin(f"s:{subpasta_id}", retorno)



@app.route("/subpasta/editar-estrutura/<subpasta_id>", methods=["POST"])
@admin_required
def editar_estrutura_subpasta(subpasta_id):
    """Renomeia e/ou move uma subpasta preservando seu nivel hierarquico."""
    retorno = request.form.get("retorno", "")
    data = load_data()
    subpastas = data.get("subpastas", [])
    sub_por_id = {sp["id"]: sp for sp in subpastas}
    alvo = sub_por_id.get(subpasta_id)
    if not alvo:
        flash("Subpasta não encontrada.", "erro")
        return _redirecionar_estrutura_admin(f"s:{subpasta_id}", retorno)

    novo_nome = request.form.get("nome_subpasta", "").strip()
    destino = request.form.get("destino", "").strip()
    nivel = _subpasta_nivel(subpasta_id, sub_por_id)
    novo_parent = alvo.get("parent_subpasta_id") or None
    nova_pasta_id = alvo.get("pasta_id")

    if destino:
        if nivel == 1 and destino.startswith("p:"):
            candidato_pasta = destino.split(":", 1)[1]
            if any(p["id"] == candidato_pasta for p in data.get("pastas", [])):
                novo_parent = None
                nova_pasta_id = candidato_pasta
            else:
                flash("Destino inválido para a divisão.", "erro")
                return _redirecionar_estrutura_admin(f"s:{subpasta_id}", retorno)
        elif nivel in {2, 3} and destino.startswith("s:"):
            candidato_id = destino.split(":", 1)[1]
            candidato = sub_por_id.get(candidato_id)
            nivel_esperado = nivel - 1
            if candidato and _subpasta_nivel(candidato_id, sub_por_id) == nivel_esperado and candidato_id != subpasta_id:
                novo_parent = candidato_id
                nova_pasta_id = candidato.get("pasta_id")
            else:
                flash("Destino inválido para esta subpasta.", "erro")
                return _redirecionar_estrutura_admin(f"s:{subpasta_id}", retorno)

    # Ao mover para outro cliente, toda a subárvore acompanha a nova pasta.
    ids_subarvore = _descendentes_subpasta(subpasta_id, subpastas)
    dashboards_subarvore = [d["id"] for d in data.get("dashboards", []) if d.get("subpasta_id") in ids_subarvore]
    mover_subpasta_pontual(
        subpasta_id, novo_nome or alvo.get("nome", ""), novo_parent, nova_pasta_id,
        ids_subarvore, dashboards_subarvore,
    )
    flash(f'Estrutura "{novo_nome or alvo.get("nome", "Subpasta")}" atualizada com sucesso.', "ok")
    return _redirecionar_estrutura_admin(f"s:{subpasta_id}", retorno)


@app.route("/subpasta/excluir/<subpasta_id>", methods=["POST"])
@admin_required
def excluir_subpasta(subpasta_id):
    usuario = current_user()
    retorno = request.form.get("retorno", "").strip().lower()
    data = (
        _dados_cadastro_master_da_requisicao()
        if eh_master(usuario) and retorno == "cadastro" else load_data()
    )
    sub_por_id = {sp["id"]: sp for sp in data.get("subpastas", [])}
    subpasta = sub_por_id.get(subpasta_id)
    if subpasta:
        parent_id = subpasta.get("parent_subpasta_id") or None

        ids_removidos = {subpasta_id}
        mudou = True
        while mudou:
            mudou = False
            for sp in data.get("subpastas", []):
                if sp["id"] not in ids_removidos and sp.get("parent_subpasta_id") in ids_removidos:
                    ids_removidos.add(sp["id"])
                    mudou = True

        # Dashboards do nível removido (e descendentes) sobem um nível.
        movidos = sum(1 for d in data["dashboards"] if d.get("subpasta_id") in ids_removidos)
        excluir_subpastas_pontual(ids_removidos, parent_id)
        remover_bloqueios_subpasta(ids_removidos)

        destino_txt = "o nível superior" if parent_id else "a pasta principal"
        sufixo = f" {movidos} dashboard(s) foram movidos para {destino_txt}." if movidos else ""
        flash(f'Subpasta "{subpasta["nome"]}" excluída.{sufixo}', "ok")
    return redirect(url_for_sessao("dashboards_administracao"))


# ===========================================================================
# Acoes: dashboards (admin)
# ===========================================================================
@app.route("/cadastrar", methods=["POST"])
@admin_required
def cadastrar():
    usuario = current_user()
    nome = request.form.get("nome", "").strip()
    embed_url = request.form.get("embed_url", "").strip()
    descricao = request.form.get("descricao", "").strip()
    pasta_id = request.form.get("pasta_id", "").strip()
    ambiente_id = (request.form.get("ambiente_id") or "").strip()
    cadastro_id_enviado = (request.form.get("dashboard_submission_id") or "").strip().lower()
    dashboard_id_valido = bool(re.fullmatch(r"[0-9a-f]{32}", cadastro_id_enviado))
    dashboard_id = cadastro_id_enviado if dashboard_id_valido else ""
    divisao_id = request.form.get("subpasta_id", "").strip() or None
    tema_id = request.form.get("tema_id", "").strip() or None
    subnivel_id = request.form.get("subnivel_id", "").strip() or None
    try:
        ordem_exibicao = max(0, int(request.form.get("ordem_exibicao", "0") or 0))
    except (TypeError, ValueError):
        ordem_exibicao = 0
    ambiente_master_invalido = False
    try:
        if eh_master(usuario):
            ambientes = listar_ambientes()
            ambiente_por_id = {a["id"]: a for a in ambientes}
            ambiente_id = _ambiente_destino_cadastro()
            ambiente = ambiente_por_id.get(ambiente_id)
            ambiente_master_invalido = ambiente is None
            ambiente_nome = (ambiente or {}).get("nome") or ambiente_id
            data = _dados_cadastro_master(None if ambiente_master_invalido else ambiente_id)
        else:
            ambiente_id = contexto_ambiente() or ""
            ambiente_nome = next(
                (a.get("nome") for a in ambientes_disponiveis(usuario) if a.get("id") == ambiente_id),
                ambiente_id or "ambiente atual",
            )
            data = load_data()
    except MySQLError:
        app.logger.exception("Falha ao carregar a estrutura para cadastrar dashboard")
        flash("Não foi possível carregar o ambiente e a árvore de pastas. Nenhum dashboard foi enviado; atualize e tente novamente.", "erro")
        return _redirecionar_estrutura(
            "cadastro", ambiente_id if eh_master(usuario) else None,
            cadastro_id=dashboard_id if dashboard_id_valido else None,
        )
    except Exception as exc:
        if isinstance(exc, HTTPException):
            raise
        app.logger.exception("Erro ao preparar o cadastro do dashboard")
        flash("Não foi possível preparar o cadastro. Nenhum dashboard foi enviado; atualize e tente novamente.", "erro")
        return _redirecionar_estrutura(
            "cadastro", ambiente_id if eh_master(usuario) else None,
            cadastro_id=dashboard_id if dashboard_id_valido else None,
        )

    pasta = next((p for p in data["pastas"] if p["id"] == pasta_id), None)
    pasta_ambiente = (pasta.get("ambiente_id") or INICIAL) if pasta else None
    pasta_valida = (
        pasta is not None
        and not ambiente_master_invalido
        and pasta_ambiente == ambiente_id
    )
    sub_por_id = {sp["id"]: sp for sp in data.get("subpastas", [])}
    divisao = sub_por_id.get(divisao_id) if divisao_id else None
    tema = sub_por_id.get(tema_id) if tema_id else None
    subnivel = sub_por_id.get(subnivel_id) if subnivel_id else None

    divisao_valida = divisao is not None and divisao.get("pasta_id") == pasta_id and not divisao.get("parent_subpasta_id")
    tema_valido = tema is not None and tema.get("pasta_id") == pasta_id and tema.get("parent_subpasta_id") == divisao_id
    subnivel_valido = subnivel is not None and subnivel.get("pasta_id") == pasta_id and subnivel.get("parent_subpasta_id") == tema_id

    hierarquia_valida = (
        (not divisao_id and not tema_id and not subnivel_id)
        or (divisao_valida and not tema_id and not subnivel_id)
        or (divisao_valida and tema_valido and not subnivel_id)
        or (divisao_valida and tema_valido and subnivel_valido)
    )
    destino_subpasta_id = subnivel_id or tema_id or divisao_id
    try:
        partes_embed = urlsplit(embed_url)
        link_powerbi_valido = (
            partes_embed.scheme == "https"
            and partes_embed.hostname == "app.powerbi.com"
            and partes_embed.port in (None, 443)
            and bool(partes_embed.path and partes_embed.path != "/")
            and not partes_embed.username
            and not partes_embed.password
        )
    except ValueError:
        link_powerbi_valido = False

    ambiente_retorno = ambiente_id if eh_master(usuario) and not ambiente_master_invalido else None

    def retornar_cadastro(cadastro_id=None):
        return _redirecionar_estrutura("cadastro", ambiente_retorno, cadastro_id=cadastro_id)

    if not dashboard_id_valido:
        flash("O formulário ficou desatualizado. Atualize a página antes de cadastrar o dashboard.", "erro")
    elif not nome or len(nome) > 160:
        flash("Informe o nome do dashboard, com até 160 caracteres.", "erro")
    elif len(descricao) > 300:
        flash("A descrição do dashboard deve ter no máximo 300 caracteres.", "erro")
    elif len(embed_url) > 2048 or not link_powerbi_valido:
        flash("Informe uma URL válida do Power BI em app.powerbi.com, com até 2048 caracteres.", "erro")
    elif eh_master(usuario) and ambiente_master_invalido:
        flash("Selecione um ambiente válido antes de cadastrar o dashboard.", "erro")
    elif not pasta_valida or not hierarquia_valida:
        flash("A pasta ou subpasta mudou desde que a página foi aberta. Atualize a árvore e selecione novamente.", "erro")
    else:
        dashboard_novo = {
            "id": dashboard_id,
            "nome": nome,
            "descricao": descricao,
            "embed_url": embed_url,
            "pasta_id": pasta_id,
            "ambiente_id": ambiente_id,
            "subpasta_id": destino_subpasta_id,
            # Cadastro simplificado: novos dashboards nascem ativos e
            # favoritados; essas opcoes seguem editaveis na Administracao.
            "ativo": True,
            "permitir_favoritar": True,
            "ordem_exibicao": ordem_exibicao,
            "cadastrado_por": current_user()["id"],
        }
        try:
            criado = salvar_dashboard_pontual(dashboard_novo, criar=True)
        except ConflitoGravacao as exc:
            flash(str(exc), "erro")
            return retornar_cadastro()
        except (ValueError, PermissionError) as exc:
            flash(str(exc) if str(exc) else "A pasta escolhida não está mais disponível.", "erro")
            return retornar_cadastro()
        except IntegrityError:
            app.logger.exception("Conflito ao cadastrar dashboard id=%s pasta=%s", dashboard_id, pasta_id)
            flash("O banco encontrou um conflito ao cadastrar o dashboard. Atualize a árvore e confira se ele já aparece.", "erro")
            return retornar_cadastro()
        except MySQLError:
            app.logger.exception("Falha de banco ao cadastrar dashboard id=%s pasta=%s", dashboard_id, pasta_id)
            flash("Não foi possível confirmar a gravação. Reenvie os mesmos dados; o portal impedirá duplicidade deste envio.", "erro")
            return retornar_cadastro(cadastro_id=dashboard_id)
        except Exception as exc:
            if isinstance(exc, HTTPException):
                raise
            app.logger.exception("Erro inesperado ao cadastrar dashboard id=%s pasta=%s", dashboard_id, pasta_id)
            flash("Ocorreu um erro durante o cadastro. Reenvie os mesmos dados; o portal verificará a solicitação antes de gravar.", "erro")
            return retornar_cadastro(cadastro_id=dashboard_id)

        sub_por_id = {sp["id"]: sp for sp in data.get("subpastas", [])}
        caminho = [pasta.get("nome", "Pasta")] + _caminho_subpasta(destino_subpasta_id, sub_por_id)
        destino_texto = " › ".join(parte for parte in [ambiente_nome, *caminho] if parte)
        if criado is False:
            flash(f'Dashboard "{nome}" já havia sido gravado em {destino_texto}. Não houve duplicidade.', "ok")
        else:
            flash(f'Dashboard "{nome}" gravado em {destino_texto}.', "ok")

    return retornar_cadastro()


@app.route("/editar/<dash_id>", methods=["POST"])
@admin_required
def editar(dash_id):
    nome = request.form.get("nome", "").strip()
    embed_url = request.form.get("embed_url", "").strip()
    descricao = request.form.get("descricao", "").strip()
    pasta_id = request.form.get("pasta_id", "").strip()
    divisao_id = request.form.get("subpasta_id", "").strip() or None
    tema_id = request.form.get("tema_id", "").strip() or None
    subnivel_id = request.form.get("subnivel_id", "").strip() or None
    ativo = request.form.get("ativo") == "1"
    permitir_favoritar = request.form.get("permitir_favoritar") == "1"
    try:
        ordem_exibicao = max(0, int(request.form.get("ordem_exibicao", "0") or 0))
    except (TypeError, ValueError):
        ordem_exibicao = 0
    data = load_data()

    pasta_valida = any(p["id"] == pasta_id for p in data["pastas"])
    sub_por_id = {sp["id"]: sp for sp in data.get("subpastas", [])}
    divisao = sub_por_id.get(divisao_id) if divisao_id else None
    tema = sub_por_id.get(tema_id) if tema_id else None
    subnivel = sub_por_id.get(subnivel_id) if subnivel_id else None

    divisao_valida = divisao is not None and divisao.get("pasta_id") == pasta_id and not divisao.get("parent_subpasta_id")
    tema_valido = tema is not None and tema.get("pasta_id") == pasta_id and tema.get("parent_subpasta_id") == divisao_id
    subnivel_valido = subnivel is not None and subnivel.get("pasta_id") == pasta_id and subnivel.get("parent_subpasta_id") == tema_id
    hierarquia_valida = (
        (not divisao_id and not tema_id and not subnivel_id)
        or (divisao_valida and not tema_id and not subnivel_id)
        or (divisao_valida and tema_valido and not subnivel_id)
        or (divisao_valida and tema_valido and subnivel_valido)
    )
    destino_subpasta_id = subnivel_id or tema_id or divisao_id
    link_powerbi_valido = embed_url.startswith("https://app.powerbi.com/")
    dash = next((d for d in data["dashboards"] if d["id"] == dash_id), None)

    if dash and nome and link_powerbi_valido and pasta_valida and hierarquia_valida:
        dashboard_atualizado = dict(dash, **{
            "nome": nome,
            "descricao": descricao,
            "embed_url": embed_url,
            "pasta_id": pasta_id,
            "subpasta_id": destino_subpasta_id,
            "ativo": ativo,
            "permitir_favoritar": permitir_favoritar,
            "ordem_exibicao": ordem_exibicao,
        })
        salvar_dashboard_pontual(dashboard_atualizado)
        flash(f'Dashboard "{nome}" atualizado.', "ok")
    else:
        if embed_url and not link_powerbi_valido:
            flash("Informe uma URL de incorporação válida do Power BI (https://app.powerbi.com/...).", "erro")
        else:
            flash("Não foi possível atualizar o dashboard. Confira os dados e a hierarquia.", "erro")
    return redirect(url_for_sessao("dashboards_administracao", tab="dashboards", dash=dash_id))


@app.route("/mover-dashboard/<dash_id>", methods=["POST"])
@admin_required
def mover_dashboard(dash_id):
    """Move somente a localização, preservando os demais dados do dashboard."""
    pasta_id = request.form.get("pasta_id", "").strip()
    subpasta_id = request.form.get("subpasta_id", "").strip() or None
    data = load_data()
    dashboard = next((d for d in data.get("dashboards", []) if d.get("id") == dash_id), None)
    pasta_por_id = {p.get("id"): p for p in data.get("pastas", [])}
    sub_por_id = {sp.get("id"): sp for sp in data.get("subpastas", [])}
    pasta = pasta_por_id.get(pasta_id)
    subpasta = sub_por_id.get(subpasta_id) if subpasta_id else None

    if not dashboard:
        flash("Dashboard não encontrado no ambiente atual.", "erro")
    elif not pasta or (subpasta_id and (not subpasta or subpasta.get("pasta_id") != pasta_id)):
        flash("Selecione uma localização válida para mover o dashboard.", "erro")
    elif (dashboard.get("pasta_id") == pasta_id
          and (dashboard.get("subpasta_id") or None) == subpasta_id):
        flash("O dashboard já está nessa localização.", "erro")
    else:
        mover_dashboard_pontual(dash_id, pasta_id, subpasta_id)
        caminho = [pasta.get("nome", "Pasta")] + _caminho_subpasta(subpasta_id, sub_por_id)
        flash(f'Dashboard "{dashboard.get("nome", "Dashboard")}" movido para {" › ".join(caminho)}.', "ok")

    return redirect(url_for_sessao("dashboards_administracao", tab="dashboards", dash=dash_id))


@app.route("/excluir/<dash_id>", methods=["POST"])
@admin_required
def excluir(dash_id):
    retorno = request.form.get("retorno", "").strip().lower()
    usuario = current_user()
    data = (
        _dados_cadastro_master_da_requisicao()
        if eh_master(usuario) and retorno == "cadastro" else load_data()
    )
    dashboard = next((d for d in data["dashboards"] if d["id"] == dash_id), None)
    if not dashboard:
        flash("Dashboard não encontrado no ambiente atual.", "erro")
        if retorno == "cadastro":
            return _redirecionar_estrutura("cadastro", contexto_ambiente())
        return redirect(url_for_sessao("dashboards_administracao"))

    nome_dash = dashboard.get("nome", "Dashboard")
    ambiente_id = dashboard.get("ambiente_id") or contexto_ambiente() or INICIAL
    excluir_dashboard_pontual(dash_id)
    remover_bloqueios_dashboard([dash_id])
    flash(f"Dashboard \"{nome_dash}\" excluído com sucesso.", "ok")
    if retorno == "cadastro":
        return _redirecionar_estrutura("cadastro", ambiente_id)
    return redirect(url_for_sessao("dashboards_administracao"))


# ===========================================================================
# Acoes: usuarios (admin)
# ===========================================================================
def _perms_do_form(papel):
    """Retorna as seleções positivas exatamente como marcadas na interface.

    Não removemos mais permissões redundantes: uma seleção inferior pode ser
    necessária para reabrir um ramo bloqueado em um nível superior.
    """
    data = load_data()
    pastas_validas = {p["id"] for p in data.get("pastas", [])}
    subpastas_validas = {sp["id"] for sp in data.get("subpastas", [])}
    dashboards_validos = {d["id"] for d in data.get("dashboards", [])}

    pastas = list(dict.fromkeys(x for x in request.form.getlist("pastas") if x in pastas_validas))
    subpastas = list(dict.fromkeys(x for x in request.form.getlist("subpastas") if x in subpastas_validas))
    dashboards = list(dict.fromkeys(x for x in request.form.getlist("dashboards") if x in dashboards_validos))
    return pastas, subpastas, dashboards


def _bloqueios_dashboards_do_form():
    """Valida os dashboards explicitamente bloqueados na tela de permissoes."""
    data = load_data()
    validos = {d["id"] for d in data.get("dashboards", [])}
    return [
        x for x in request.form.getlist("dashboards_bloqueados")
        if x in validos
    ]


def _bloqueios_subpastas_do_form():
    """Valida Divisões/Temas explicitamente bloqueados."""
    data = load_data()
    validos = {sp["id"] for sp in data.get("subpastas", [])}
    return list(dict.fromkeys(
        x for x in request.form.getlist("subpastas_bloqueadas")
        if x in validos
    ))


def _nova_conta(nome, login, papel, email=None):
    return {
        "id": uuid.uuid4().hex,
        "nome": nome,
        "usuario": login,
        "email": validar_email(email, obrigatorio=True),
        "senha_hash": generate_password_hash(SENHA_INICIAL),
        "troca_senha_obrigatoria": True,
        "papel": papel,
    }


@app.route("/usuarios/criar", methods=["POST"])
@admin_required
def criar_usuario():
    nome = " ".join(request.form.get("nome", "").split())
    papel = request.form.get("papel", "viewer")
    if papel not in ("admin", "viewer") or (papel == "admin" and not eh_master(current_user())):
        abort(403)
    try:
        # A prévia do navegador nunca substitui a geração no servidor.
        usuario = gerar_login(nome)
        if any(u["usuario"].casefold() == usuario for u in load_users()):
            raise ValueError(f"O login {usuario} já existe. Confira o nome completo informado.")
        inserir_novos_usuarios([_nova_conta(nome, usuario, papel, request.form.get("email"))], current_user())
    except PermissionError:
        abort(403, description="Somente o Master pode cadastrar Administradores.")
    except ValueError as exc:
        flash(str(exc), "erro")
    except IntegrityError:
        flash("O login já existe ou os dados foram alterados durante o cadastro. Confira e tente novamente.", "erro")
    except MySQLError:
        app.logger.exception("Falha no cadastro de usuário")
        flash("Não foi possível concluir o cadastro. Consulte os usuários cadastrados antes de tentar novamente.", "erro")
    else:
        orientacao = " Associe esta conta em Permissão de Ambiente para liberar a entrada." if eh_master(current_user()) and not contexto_ambiente() else ""
        flash(f'Usuário "{nome}" criado. Login: {usuario}. Senha inicial: {SENHA_INICIAL}. A troca será obrigatória no primeiro acesso.' + orientacao, "ok")
    return redirect(url_for_sessao("usuarios_cadastro"))


@app.route("/usuarios/editar/<uid>", methods=["POST"])
@admin_required
def editar_usuario(uid):
    """Edita somente os dados da conta. Permissoes ficam em fluxo separado."""
    nome = request.form.get("nome", "").strip()
    usuario = request.form.get("usuario", "").strip()
    senha = request.form.get("senha", "")
    papel = request.form.get("papel", "viewer")
    if papel not in ("admin", "viewer") or (papel == "admin" and not eh_master(current_user())):
        abort(403)

    users = load_users()
    alvo = next((u for u in users if u["id"] == uid), None)
    if not alvo:
        return redirect(url_for_sessao("usuarios_administracao"))
    if not pode_gerenciar_usuario(current_user(), alvo):
        abort(403)

    if alvo["papel"] == "admin" and papel != "admin" and total_admins(users) <= 1:
        flash("Não é possível rebaixar o último administrador.", "erro")
        return redirect(url_for_sessao("usuarios_administracao", uid=uid))

    if usuario and any(u["id"] != uid and u["usuario"].lower() == usuario.lower() for u in users):
        flash("Nome de usuário já está em uso.", "erro")
        return redirect(url_for_sessao("usuarios_administracao", uid=uid))

    if not eh_master(current_user()) and ambientes_do_usuario(uid) != {contexto_ambiente()}:
        flash("Esta conta participa de outros ambientes. O Master deve alterar seus dados ou redefinir sua senha.", "erro")
        return redirect(url_for_sessao("usuarios_administracao", uid=uid))

    nome_anterior = alvo.get("nome", "")
    usuario_anterior = alvo.get("usuario", "")
    papel_anterior = alvo.get("papel", "viewer")
    email_anterior = alvo.get("email")
    try:
        email = validar_email(request.form.get("email"), obrigatorio=True)
    except ValueError as exc:
        flash(str(exc), "erro")
        return redirect(url_for_sessao("usuarios_administracao", uid=uid))
    if email.casefold() != (email_anterior or "").strip().casefold() and any(
        outro["id"] != uid
        and isinstance(outro.get("email"), str)
        and outro["email"].strip().casefold() == email.casefold()
        for outro in users
    ):
        flash("Este e-mail já está associado a outro usuário.", "erro")
        return redirect(url_for_sessao("usuarios_administracao", uid=uid))

    if nome:
        alvo["nome"] = nome
    if usuario:
        alvo["usuario"] = usuario
    alvo["papel"] = papel
    alvo["email"] = email
    # Alterar dados ou perfil preserva as permissões e exceções já definidas.
    if senha:
        if not senha_valida(senha):
            flash(SENHA_REGRA, "erro")
            return redirect(url_for_sessao("usuarios_administracao", uid=uid))
        alvo["senha_hash"] = generate_password_hash(senha)
        # Qualquer senha redefinida por Master/Administrador é provisória.
        # No próximo login, o usuário sempre verá o modal/tela de troca
        # obrigatória, independentemente do valor informado no reset.
        alvo["troca_senha_obrigatoria"] = True
    try:
        campos_atualizacao = ("nome", "usuario", "email", "senha_hash", "papel")
        if senha:
            campos_atualizacao += ("troca_senha_obrigatoria",)
        atualizar_usuario_pontual(
            uid,
            {campo: alvo[campo] for campo in campos_atualizacao if campo in alvo},
            versao_esperada=alvo.get("versao"),
            ator_id=current_user()["id"],
        )
    except PermissionError:
        abort(403, description="Somente o Master pode atribuir o perfil Administrador.")
    if papel in {"admin", "viewer"}:
        marcar_permissoes_inicializadas(alvo["id"])
    mudancas = []
    if alvo.get("nome") != nome_anterior:
        mudancas.append("nome")
    if alvo.get("usuario") != usuario_anterior:
        mudancas.append("login")
    if alvo.get("papel") != papel_anterior:
        mudancas.append("perfil")
    if alvo.get("email") != email_anterior:
        mudancas.append("e-mail")
    if senha:
        mudancas.append("senha com troca obrigatória no próximo login")
    registrar_evento_usuario(
        "usuario_editado", alvo,
        "Campos alterados: " + ", ".join(mudancas) if mudancas else "Dados revisados sem alteração de campos",
    )
    flash(f"Usuário \"{alvo['nome']}\" atualizado com sucesso.", "ok")
    return redirect(url_for_sessao("usuarios_administracao", uid=uid))


@app.route("/usuarios/permissoes/<uid>", methods=["POST"])
@admin_required
def salvar_permissoes_usuario(uid):
    users = load_users()
    alvo = next((u for u in users if u["id"] == uid), None)
    if not alvo:
        return redirect(url_for_sessao("usuarios_administracao"))
    if not pode_gerenciar_usuario(current_user(), alvo):
        abort(403)

    ambiente_usuario = request.form.get("ambiente_usuario", "").strip()
    escopo_ambiente = None
    if ambiente_usuario and eh_master(current_user()):
        if ambiente_usuario not in ambientes_do_usuario(uid):
            abort(403, description="Este usuário não está associado ao ambiente selecionado.")
        escopo_ambiente = _dados_do_ambiente(load_data(), ambiente_usuario)

    pastas, subpastas, dashboards = _perms_do_form(alvo["papel"])
    dashboards_bloqueados = _bloqueios_dashboards_do_form()
    subpastas_bloqueadas = _bloqueios_subpastas_do_form()
    if escopo_ambiente is not None:
        # O formulário contém apenas o ambiente escolhido. Mesclamos o novo
        # recorte com as permissões de todos os demais ambientes para que uma
        # alteração individual nunca apague acessos já configurados em outra
        # associação do mesmo usuário.
        ids_pastas_ambiente = {p["id"] for p in escopo_ambiente.get("pastas", [])}
        ids_subpastas_ambiente = {sp["id"] for sp in escopo_ambiente.get("subpastas", [])}
        ids_dashboards_ambiente = {d["id"] for d in escopo_ambiente.get("dashboards", [])}
        pastas = list(dict.fromkeys(
            [x for x in alvo.get("pastas", []) if x not in ids_pastas_ambiente]
            + [x for x in pastas if x in ids_pastas_ambiente]
        ))
        subpastas = list(dict.fromkeys(
            [x for x in alvo.get("subpastas", []) if x not in ids_subpastas_ambiente]
            + [x for x in subpastas if x in ids_subpastas_ambiente]
        ))
        dashboards = list(dict.fromkeys(
            [x for x in alvo.get("dashboards", []) if x not in ids_dashboards_ambiente]
            + [x for x in dashboards if x in ids_dashboards_ambiente]
        ))
        bloqueios_atuais_dash = carregar_dashboards_bloqueados(uid)
        bloqueios_atuais_sub = carregar_subpastas_bloqueadas(uid)
        dashboards_bloqueados = sorted(
            (bloqueios_atuais_dash - ids_dashboards_ambiente)
            | ({x for x in dashboards_bloqueados if x in ids_dashboards_ambiente})
        )
        subpastas_bloqueadas = sorted(
            (bloqueios_atuais_sub - ids_subpastas_ambiente)
            | ({x for x in subpastas_bloqueadas if x in ids_subpastas_ambiente})
        )
    elif contexto_ambiente():
        data = load_data()
        pastas += [x for x in alvo.get("pastas", []) if x not in {p["id"] for p in data["pastas"]}]
        subpastas += [x for x in alvo.get("subpastas", []) if x not in {p["id"] for p in data["subpastas"]}]
        dashboards += [x for x in alvo.get("dashboards", []) if x not in {p["id"] for p in data["dashboards"]}]
        dashboards_bloqueados += list(carregar_dashboards_bloqueados(uid) - {p["id"] for p in data["dashboards"]})
        subpastas_bloqueadas += list(carregar_subpastas_bloqueadas(uid) - {p["id"] for p in data["subpastas"]})
    alvo["pastas"] = pastas
    alvo["subpastas"] = subpastas
    alvo["dashboards"] = dashboards
    if current_user().get("papel") == "admin":
        # Os ramos ocultos pelo Master não podem ser liberados por omissão no formulário.
        dados_escopo = load_data()
        bloqueios_dash_ator = carregar_dashboards_bloqueados(current_user()["id"]) & {d["id"] for d in dados_escopo["dashboards"]}
        bloqueios_sub_ator = carregar_subpastas_bloqueadas(current_user()["id"]) & {sp["id"] for sp in dados_escopo["subpastas"]}
        dashboards_bloqueados = sorted(set(dashboards_bloqueados) | bloqueios_dash_ator)
        subpastas_bloqueadas = sorted(set(subpastas_bloqueadas) | bloqueios_sub_ator)
        if not _permissoes_dentro_do_escopo(current_user(), alvo, set(subpastas_bloqueadas), set(dashboards_bloqueados)):
            abort(403, description="Você só pode conceder permissões dentro do acesso liberado pelo Master.")
    flash(f"Permissões de \"{alvo['nome']}\" atualizadas com sucesso.", "ok")

    salvar_permissoes_usuario_pontual(
        alvo["id"], pastas, subpastas, dashboards, dashboards_bloqueados,
        subpastas_bloqueadas, versao_esperada=alvo.get("versao"), ator_id=current_user()["id"],
    )

    qtd_dash_bloqueados = len(dashboards_bloqueados)
    qtd_sub_bloqueadas = len(subpastas_bloqueadas)
    registrar_evento_usuario(
        "permissoes_atualizadas", alvo,
        f"{len(alvo.get('pastas', []))} cliente(s), {len(alvo.get('subpastas', []))} divisão/tema(s), "
        f"{len(alvo.get('dashboards', []))} dashboard(s) marcado(s); {qtd_sub_bloqueadas} exceção(ões) de estrutura e "
        f"{qtd_dash_bloqueados} dashboard(s) bloqueado(s)",
    )
    valores_retorno = {"uid": uid}
    if ambiente_usuario:
        valores_retorno["ambiente_usuario"] = ambiente_usuario
    return redirect(url_for_sessao("usuarios_administracao", **valores_retorno))


@app.route("/usuarios/excluir/<uid>", methods=["POST"])
@admin_required
def excluir_usuario(uid):
    ator = current_user()
    users = load_users()
    alvo = next((u for u in users if u["id"] == uid), None)
    if not alvo:
        return redirect(url_for_sessao("usuarios_administracao"))
    if not pode_gerenciar_usuario(ator, alvo):
        abort(403)
    # O Administrador só pode excluir contas dentro do ambiente que está
    # administrando. A conta, porém, será removida globalmente quando a ação
    # for confirmada.
    if not eh_master(ator) and not contexto_ambiente():
        abort(403)
    if ator and alvo["id"] == ator["id"]:
        flash("Você não pode excluir a si mesmo.", "erro")
        return redirect(url_for_sessao("usuarios_administracao"))
    if alvo["papel"] == "admin" and total_admins(users) <= 1:
        flash("Não é possível excluir o último administrador.", "erro")
        return redirect(url_for_sessao("usuarios_administracao"))

    try:
        remover_usuario_pontual(uid, versao_esperada=alvo.get("versao"))
    except PermissionError:
        abort(403)
    except (ValueError, ConflitoGravacao) as exc:
        flash(str(exc), "erro")
        return redirect(url_for_sessao("usuarios_administracao"))

    perfil_ator = "Administrador" if not eh_master(ator) else "Master"
    registrar_evento_usuario(
        "usuario_excluido", alvo,
        f"Conta removida definitivamente pelo {perfil_ator}",
    )
    flash(f"Usuário \"{alvo['nome']}\" excluído definitivamente com sucesso.", "ok")
    return redirect(url_for_sessao("usuarios_administracao"))


@app.route("/primeiro-acesso", methods=["GET", "POST"])
@login_required
def primeiro_acesso():
    usuario = current_user()
    if not usuario.get("troca_senha_obrigatoria"):
        return redirect(url_for_sessao("index"))
    erro = None
    if request.method == "POST":
        nova = request.form.get("senha_nova", "")
        confirma = request.form.get("senha_confirma", "")
        if not senha_valida(nova):
            erro = SENHA_REGRA
        elif nova != confirma:
            erro = "A confirmação não confere com a nova senha."
        elif nova == SENHA_INICIAL or check_password_hash(usuario["senha_hash"], nova):
            erro = "Escolha uma senha diferente da senha inicial e da senha atual."
        else:
            nova_hash = generate_password_hash(nova)
            if not concluir_primeiro_acesso(usuario["id"], usuario["senha_hash"], nova_hash):
                g._portal_nao_renovar_auth = True
                flash("Sua conta foi atualizada em outro acesso. Entre novamente.", "erro")
                return redirect(url_for("login"))
            usuario = dict(usuario, senha_hash=nova_hash, troca_senha_obrigatoria=False)
            g._portal_current_user = usuario
            registrar_evento_usuario("primeira_senha_alterada", usuario, "Troca obrigatória concluída")
            return redirect(url_for_sessao("index"))
    return render_template("primeiro_acesso.html", erro=erro), (400 if erro else 200)


@app.route("/minha-conta")
@login_required
def minha_conta():
    return render_template("conta.html", active="conta")


@app.get("/minha-conta/foto")
@login_required
def foto_perfil():
    """Entrega somente a foto da conta autenticada, sem expor fotos por ID."""
    foto = carregar_foto_usuario(current_user()["id"])
    if not foto or not foto.get("dados") or foto.get("mime") != FOTO_USUARIO_MIME:
        abort(404)
    resposta = send_file(
        io.BytesIO(foto["dados"]),
        mimetype=foto["mime"],
        as_attachment=False,
        download_name=foto.get("nome") or "foto-perfil.jpg",
        max_age=0,
    )
    resposta.headers["Cache-Control"] = "no-store, private"
    return resposta


@app.post("/minha-conta/foto")
@login_required
def enviar_foto_perfil():
    usuario = current_user()
    try:
        dados, mime, nome = _ler_foto_usuario(request.files.get("foto"))
        salvar_foto_usuario(usuario["id"], dados, mime, nome)
    except ValueError as exc:
        flash(str(exc), "erro")
    else:
        flash("Foto do perfil atualizada com sucesso.", "ok")
    return redirect(url_for_sessao("minha_conta"))


@app.post("/minha-conta/foto/remover")
@login_required
def remover_foto_perfil():
    if remover_foto_usuario(current_user()["id"]):
        flash("Foto do perfil removida.", "ok")
    else:
        flash("Não havia foto cadastrada para remover.", "erro")
    return redirect(url_for_sessao("minha_conta"))


@app.route("/minha-conta/senha", methods=["POST"])
@login_required
def trocar_senha():
    u = current_user()
    atual = request.form.get("senha_atual", "")
    nova = request.form.get("senha_nova", "")
    confirma = request.form.get("senha_confirma", "")

    if not check_password_hash(u["senha_hash"], atual):
        flash("Senha atual incorreta.", "erro")
    elif not senha_valida(nova):
        flash(SENHA_REGRA, "erro")
    elif nova != confirma:
        flash("A confirmação não confere com a nova senha.", "erro")
    else:
        atualizar_usuario_pontual(
            u["id"], {"senha_hash": generate_password_hash(nova)},
            versao_esperada=u.get("versao"), permitir_master=eh_master(u),
        )
        flash("Senha alterada com sucesso.", "ok")
    return redirect(url_for_sessao("minha_conta"))


if __name__ == "__main__":
    # O debug pode mostrar erros detalhados na máquina local, mas o
    # recarregador automático do Flask é desativado. Em algumas instalações
    # Windows ele observa até módulos da biblioteca padrão e reinicia o
    # processo durante uma operação SMTP, derrubando a conexão do navegador.
    # Nunca use debug em produção: ele expõe um console interativo.
    modo_debug = os.environ.get("FLASK_DEBUG", "false").lower() == "true"
    print("=" * 55)
    print("  Portal BI está no ar e pronto para ser utilizado!")
    print("  Acesse: http://127.0.0.1:5000")
    if modo_debug:
        print("  [!] Rodando em modo DEBUG -- nunca use assim em producao.")
    print("  Para encerrar, pressione CTRL+C")
    print("=" * 55)
    app.run(debug=modo_debug, use_reloader=False, port=5000)
