"""Execute localmente, uma vez, para criar a conta exclusiva do desenvolvedor."""
from pathlib import Path
from getpass import getpass
import sys
from dotenv import load_dotenv
from werkzeug.security import generate_password_hash
from cadastro_usuarios import validar_email


def main():
    load_dotenv(Path(__file__).resolve().with_name('.env'))
    from db import criar_tabelas, criar_master_local
    print('Criar a conta Master do Portal BI')
    print('Use um login exclusivo. A senha digitada nao sera exibida nem salva em texto.')
    nome = input('Seu nome: ').strip()
    login = input('Login do Master [master]: ').strip() or 'master'
    if not nome or len(nome) > 255 or len(login) > 100 or any(c.isspace() for c in login):
        print('Informe um nome e um login sem espacos (ate 100 caracteres).')
        return 1
    try:
        email = validar_email(input('E-mail do Master: '), obrigatorio=True)
    except ValueError as erro:
        print(str(erro))
        return 1
    senha = getpass('Senha exclusiva (minimo 12 caracteres, maiuscula, numero e especial): ')
    if not (len(senha) >= 12 and any(c.isupper() for c in senha) and any(c.isdigit() for c in senha)
            and any(not c.isalnum() and not c.isspace() for c in senha)):
        print('A senha nao atende aos requisitos. Nenhuma conta foi criada.')
        return 1
    if senha != getpass('Confirme a senha: '):
        print('As senhas nao conferem. Nenhuma conta foi criada.')
        return 1
    try:
        criar_tabelas()
        criar_master_local(nome, login, generate_password_hash(senha), email)
    except ValueError as erro:
        print(str(erro))
        return 1
    except Exception:
        print('Nao foi possivel criar a conta. Confira o servico MySQL e a configuracao do .env.')
        return 1
    print('Master criado com sucesso. Entre no portal com o login definido e sua senha.')
    print('O e-mail informado será usado para a recuperação de senha quando o SMTP estiver configurado.')
    print('A guia Administracao estara disponivel apenas para essa conta.')
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (EOFError, KeyboardInterrupt):
        print('\nOperacao cancelada.')
        sys.exit(1)
