# Portal BI — documentação e continuidade do projeto

Atualizado em **12 de setembro de 2026**.

## 1. Como usar este documento

Este arquivo consolida a visão do projeto, a arquitetura, os módulos, as regras de acesso, as decisões visuais aprovadas e as últimas alterações desta conversa. Pode ser lido em outro computador ou entregue a outro assistente para continuar o trabalho.

É documentação de continuidade, não uma cópia integral do código ou do banco de dados. Para executar ou modificar o sistema em outra máquina, leve também os arquivos do projeto e configure um banco apropriado. Credenciais, tokens, dados pessoais, conteúdo do banco e valores do `.env` não foram incluídos.

Referência local da instalação documentada:

`C:\Users\RodrigoMazzetto\OneDrive - GNX Group\Área de Trabalho\Portal BI\Principal`

## 2. O que é o Portal BI

Aplicação web em Python/Flask para organizar e disponibilizar dashboards Power BI com autenticação, ambientes por cliente, estrutura de pastas e subpastas, permissões individuais, gestão de usuários, auditoria de acessos e avisos.

O armazenamento principal é **MySQL/MariaDB**, não os arquivos JSON existentes na pasta. Há páginas renderizadas com Jinja, CSS compartilhado e JavaScript embutido em diversos templates.

O projeto possui três perfis principais: Master, Administrador e Visualizador. A autorização combina perfil, guias liberadas, associação a ambientes e permissões de conteúdo.

## 3. Tecnologias e dependências

Dependências declaradas em `requirements.txt`:

| Dependência | Uso principal |
| --- | --- |
| Flask >= 3.0 | Aplicação web e rotas |
| Jinja, como dependência do Flask | Renderização dos templates |
| PyMySQL >= 1.1 | Acesso ao MySQL/MariaDB |
| python-dotenv >= 1.0 | Configuração por variáveis de ambiente |
| Flask-WTF >= 1.3 | Proteção de formulários/CSRF |
| Flask-Limiter >= 4.1 | Limitação de requisições |
| redis >= 5.0 | Backend compartilhado para limitação de requisições |
| openpyxl >= 3.1 | Importações e exportações Excel |
| waitress >= 3.0 | Servidor de produção |

O ambiente relatado pelo usuário é Windows, com referência a Python 3.14. O interpretador efetivamente usado para executar o portal deve ser identificado na máquina de destino; não presumir que qualquer comando `python` aponta para a instalação com as dependências corretas.

## 4. Organização do código

| Arquivo ou diretório | Responsabilidade |
| --- | --- |
| `app.py` | Aplicação principal, autenticação, rotas, controles de acesso e integração dos módulos |
| `db.py` | Persistência, consultas, inicialização e migrações do banco |
| `ambientes.py` | Ambientes, associações e operações relacionadas |
| `permissoes_guias.py` | Catálogo de guias e regras de autorização por função |
| `cadastro_usuarios.py` | Apoio ao cadastro de usuários |
| `email_portal.py` | Envio de e-mails do portal |
| `criar_master.py` | Criação controlada da conta Master |
| `serve.py` | Execução com Waitress |
| `reiniciar_portal.py` | Rotina local de reinicialização; revisar antes de usar em outra máquina |
| `migrar_json_para_mysql.py` | Migração do armazenamento JSON legado |
| `templates/` | Páginas Jinja e JavaScript das interfaces |
| `static/css/style.css` | Identidade visual, componentes, temas e responsividade |
| `.env.exemplo` | Referência de configuração, sem usar como credenciais reais |
| `.env` | Configuração privada da instalação; não está reproduzida aqui |
| `SQL/` | Scripts e dump existentes; não executar automaticamente |
| `app_embedded.py` | Modelo alternativo de Power BI Embedded; não confundir com a aplicação principal |

Há também arquivos antigos com sufixos como `_renomeie_para_...`, JSON legados e prévias HTML/PNG. Sua presença não significa que sejam os arquivos ativos da aplicação.

### Templates principais

- Estrutura global: `base.html`, `base_app.html`.
- Autenticação: `login.html`, `primeiro_acesso.html`, `recuperar.html`, `recuperar_redefinir.html`.
- Conta pessoal: `conta.html`.
- Ambientes: `ambientes.html`, `ambiente_seletor.html`, `permissoes_ambiente.html`.
- Administração exclusiva do Master: `administracao_master.html`.
- Usuários: `usuarios.html`, `usuarios_cadastro.html`, `usuarios_administracao.html`.
- Conteúdo: `index.html`, `dashboards.html`, `cadastro.html`, `dashboards_administracao.html`, `view.html`, `embed.html`, `portal.html`.
- Auditoria: `acessos.html`.
- Avisos: `aviso.html`, `aviso_modal.html`, `aviso_eventos.html`, `aviso_eventos_consolidado.html`, `aviso_dashboard.html`.
- Restrição de navegação: `sem_guias.html`.

## 5. Perfis e regras de acesso

### Master

- Acesso às funções administrativas globais e aos ambientes.
- Gerencia Administradores e Visualizadores.
- Configura guias disponíveis por usuário na aba **Administração de Guias**.
- Cria, edita, ativa, desativa e exclui ambientes pelas operações exclusivas do Master.
- Pode gerenciar imagem e associações do ambiente.
- A conta Master não deve ser criada, promovida, rebaixada ou excluída pelos formulários comuns de usuários.

### Administrador

- Na área **Administração**, tem somente a aba **Permissão de Ambiente**.
- **Administração de Guias** continua exclusiva do Master, inclusive nas rotas do servidor.
- Na Permissão de Ambiente, pode navegar entre os ambientes ativos associados à própria conta.
- Gerencia associações de Visualizadores nesses ambientes; não altera associações de Administradores ou Master.
- O novo seletor local não concede acesso a ambientes fora do escopo autorizado.
- Essa restrição de abas diz respeito à área Administração: não significa remover todas as outras guias normais do portal.

### Visualizador e guias personalizadas

- Sem personalização, o Visualizador tem Dashboards e Minha conta.
- As guias personalizadas influenciam menu e autorização dos endpoints relacionados; algumas funções podem ser delegadas, conforme as verificações do código.
- Minha conta é preservada nas configurações personalizadas atuais.
- As restrições exclusivas do Master e as permissões de conteúdo continuam sendo verificadas separadamente.

### Camadas que não devem ser confundidas

1. Perfil: define capacidades e restrições gerais.
2. Guias: define quais áreas e endpoints são liberados.
3. Ambiente: define o escopo de clientes associado à conta.
4. Pastas, subpastas e dashboards: define o conteúdo acessível dentro do ambiente.

Ocultar controles no HTML não substitui validação no servidor.

## 6. Módulos funcionais

### Dashboards e estrutura

Organização de dashboards por ambiente, pasta e subpasta. Há áreas de visualização, cadastro e administração, além de favoritos e registro de acessos. A estrutura e as operações devem respeitar o escopo permitido ao usuário.

### Administração de Usuários

Layout aprovado com seletor de usuário em painel no canto superior direito e duas abas principais:

- **Permissões de Dashboards**: controle por ambiente e estrutura.
- **Edição do Usuário**: dados da conta e alteração de senha.

O botão antigo de editar usuário no cabeçalho e o botão “Voltar às permissões” não fazem parte da proposta aprovada. A edição é acessada pela própria aba.

Comportamentos aprovados para permissões:

- Checkbox para habilitar pastas, subpastas e dashboards.
- Marcar uma pasta marca os itens abaixo dela; desmarcar remove a seleção daquele ramo.
- Busca por nome de pasta, subpasta ou dashboard.
- Seleção de ambiente por abas compactas e destaque visual do ambiente selecionado.
- Preservar a coerência entre seleção visual, permissões efetivas e gravação no servidor.

A implementação antiga trabalhava com herança e exceções, com o nível mais específico prevalecendo. Não eliminar regras persistidas sem verificar a conversão para a interface atual.

### Senha e recuperação

- Há autenticação, troca obrigatória de senha e recuperação por e-mail.
- Na edição de usuário, cadastrar a senha inicial padrão configurada no projeto deve exigir a criação de uma senha pessoal no próximo acesso.
- Cadastrar outra senha válida deve permitir o uso direto da senha definida.
- Deixar o campo de nova senha vazio mantém a senha existente.
- O sinalizador persistido relevante é `troca_senha_obrigatoria`.
- Recuperação exige configuração de SMTP e URL pública do portal.
- O valor da senha padrão e as credenciais reais não são reproduzidos neste documento.

### Acessos

Guia de auditoria e acompanhamento do uso dos dashboards, com filtros e exportação XLSX. Seu padrão visual é a referência oficial para novas abas do projeto.

Áreas de referência: **Visão geral**, **Histórico**, **Usuários** e **Dashboards**. A troca de abas deve ser estável, sem piscar, ampliar conteúdo ou deslocar a tela desnecessariamente.

### Avisos

A documentação de continuidade existente registra a remodelação aprovada em cinco áreas:

- Visão geral.
- Novo aviso.
- Avisos ativos.
- Aceites.
- Histórico.

Há publicação por ambiente, escopo consolidado para o Master, filtros de período, exportações XLSX e atualização por Server-Sent Events. Edição/publicação e retirada de avisos devem preservar a auditoria histórica. O documento específico detalha o comportamento e as validações realizadas em uma etapa anterior; os módulos de Avisos não foram retestados nesta última alteração de ambientes.

## 7. Última implementação: Permissão de Ambiente

### Aparência e navegação

O dropdown de ambiente foi substituído pelo mesmo padrão de abas usado na Administração de Usuários.

- Até **quatro ambientes por página**.
- Duas setas discretas, uma de cada lado.
- Setas desativadas quando não há outra página naquela direção.
- Ambiente selecionado com gradiente azul translúcido.
- Nome e indicação de ambiente ativo/inativo.
- Ao carregar a tela, a paginação abre na página que contém o ambiente selecionado.
- Os botões de edição/status/exclusão permanecem ligados ao ambiente em gestão e exclusivos do Master.
- O mesmo seletor paginado é exibido para Administrador, com a lista restrita aos ambientes disponíveis à conta.

### Arquivos e identificadores

- `templates/permissoes_ambiente.html`: estrutura das abas e JavaScript da paginação.
- `static/css/style.css`: estilos compartilhados e ajustes específicos `.env-environment-navigation`.
- `templates/base.html`: versão do CSS para atualização do cache.
- `app.py`: seleção autorizada do ambiente na rota `permissoes_ambiente`.

Elementos: `envEnvironmentList`, `envPreviousPage`, `envNextPage`. A variável local `pageSize` está em **4**.

Classes visuais reaproveitadas: `users-permissions-modern-page`, `users-permission-environment`, `users-permission-environment-tabs`, `users-permission-environment-list`, `users-permission-environment-chip` e `users-environment-page-button`.

### Rotas e autorização

- `GET /ambientes/permissoes`: renderiza a tela, usando `ambiente_id` na query para a escolha local.
- Para Master, a lista vem de `listar_ambientes()`.
- Para Administrador, vem de `ambientes_disponiveis(ator)`, limitada aos ambientes associados e ativos.
- Sem escolha explícita, o Administrador usa o contexto atual como padrão.
- Um identificador fora da lista disponível é rejeitado com 404.
- `POST /ambientes/<ambiente_id>/associacoes`: valida ambiente autorizado e os usuários que podem ser alterados.
- `/administracao` e a operação de salvar guias continuam protegidas por `master_required`.

O seletor da tela usa navegação por links para carregar os dados do ambiente escolhido. Não foi implementada nesta etapa uma troca AJAX de todo o conteúdo nem uma mudança automática do contexto global da sessão.

## 8. Padrão visual aprovado

### Abas principais — referência Acessos

Para este projeto, toda nova navegação por abas deve seguir a guia **Acessos**:

- Barra em cartão com borda discreta e cantos arredondados.
- Itens bem distribuídos, com espaço entre eles.
- Ícone, título e subtítulo.
- Item ativo com fundo inteiro em gradiente azul translúcido, borda azul e ícone destacado.
- Espaço vertical entre a barra de abas e os demais cartões.
- A documentação visual anterior registra raio de 14px, padding de 7px, gap de 8px e respiro vertical de 18px como referência.
- Não voltar ao grupo compacto de botões nem destacar somente o ícone.
- Usar fontes legíveis: o usuário pediu aumentos sucessivos porque os textos estavam pequenos.

As abas de ambientes são uma variante compacta com nome/subtítulo centralizados e paginação lateral, conforme o componente de Administração de Usuários.

### Temas

O amarelo deixou de ser a cor primária. Botões, abas e itens selecionados usam azul translúcido em gradiente nos dois temas.

Referência aprovada do dark:

`rgba(24, 74, 162, .68) → rgba(31, 95, 202, .44) → rgba(76, 157, 255, .23)`

Referência aprovada do light:

`rgba(31, 85, 186, .32) → rgba(47, 111, 237, .22) → rgba(75, 145, 245, .12)`

Reutilizar as variáveis existentes no CSS, especialmente os tokens de gradiente e contraste. Alertas e estados de risco mantêm suas cores próprias.

Trocar de tema deve mudar as cores e preservar o estado visual: aba ativa, painel aberto, seletor expandido, filtros e seleção. Não reconstruir a tela de maneira que feche controles ou cause piscadas.

### Login e marca

- Fundo em tela cheia inspirado em ciência de dados: grade discreta, duas séries temporais, pontos pulsantes, varredura vertical e brilhos azuis.
- Animação decorativa e compatível com `prefers-reduced-motion`.
- Formulário de login à direita, com o título “Bem-vindo de volta”.
- Marca **Portal BI** e frase **ANÁLISE DE DADOS EM MOVIMENTO** no espaço à esquerda do formulário, centralizadas dentro desse espaço e translúcidas.
- Sem caixa, quadrado ou moldura em volta da marca no estado final aprovado.
- Foram removidos os textos antigos “Inteligência conectada”, “Transforme dados em decisões” e a explicação do painel.
- A marca interna no canto superior esquerdo também teve o quadrado removido.
- Várias fontes foram testadas; não retornar automaticamente às propostas Saira Stencil One rejeitadas. O estado recente do CSS utiliza Bahnschrift com fallback Arial Narrow/sans-serif.
- O tamanho recente da marca do login usa `clamp(46px, 3.6vw, 58px)` e a frase `clamp(15px, 1.12vw, 18px)`, com ajustes para telas menores.
- O posicionamento recente do grupo no desktop utiliza `left: 40%` e `top: 50%`; revisar responsividade ao alterar largura do formulário ou layout.

## 9. Persistência e histórico

Grupos de tabelas identificados no código de inicialização:

- Conteúdo: `pastas`, `subpastas`, `dashboards`.
- Usuários: `usuarios`, `usuario_fotos`, `usuario_guias`, `portal_master_controle`.
- Permissões: `usuario_pastas`, `usuario_subpastas`, `usuario_dashboards`.
- Favoritos: `favoritos`.
- Auditoria: `usuario_eventos`, `acessos`.
- Avisos: `aviso_fixado`, `avisos_publicacoes`, `avisos_estado`, `avisos_destinatarios`, `avisos_eventos`.
- O módulo de ambientes também mantém entidades de ambientes e associações, incluindo `ambiente_usuarios`.

Esta relação é um mapa funcional, não um dump completo do schema. Consultar `db.py`, `ambientes.py` e o banco efetivo antes de qualquer migração.

Há inicialização e migrações aditivas automáticas. Não apagar banco, recriar tabelas ou executar scripts de reset para resolver ajustes visuais. O diretório SQL contém material antigo que pode incluir dados sensíveis e operações destrutivas.

## 10. Executar em outro computador

### Arquivos necessários

Copiar a pasta do projeto com os arquivos Python, `templates/`, `static/`, `requirements.txt` e documentação. Não é necessário copiar `__pycache__` ou um ambiente virtual de outra máquina.

O código sozinho não leva os dados do MySQL. Decidir se a nova máquina acessará o banco existente ou um banco separado restaurado de backup. Para testes e desenvolvimento, preferir uma cópia de homologação.

### Preparação local

No PowerShell, dentro da pasta do projeto:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

Criar um `.env` a partir da estrutura de `.env.exemplo`, com os valores apropriados da nova instalação. Não sobrescrever um `.env` existente sem revisar sua configuração.

Configurar MySQL/MariaDB e as credenciais do banco. Para iniciar em desenvolvimento:

```powershell
.\.venv\Scripts\python.exe app.py
```

Confirmar a porta e o endereço mostrados no terminal. A URL local usada durante esta conversa foi `http://127.0.0.1:5000`.

Não presumir que as credenciais iniciais descritas em documentos antigos sejam válidas. Se a instalação for realmente nova e ainda não tiver Master, revisar `MASTER.md` e executar `criar_master.py` com o mesmo ambiente Python do portal.

### Configuração disponível

Nomes de variáveis presentes no exemplo de configuração:

- Banco: `DB_HOST`, `DB_PORT`, `DB_USER`, `DB_PASSWORD`, `DB_NAME`.
- Pool: `DB_POOL_MAX_CONEXOES`, `DB_POOL_TEMPO_ESPERA`, `DB_CONNECT_TIMEOUT`.
- Sessão e aplicação: `SECRET_KEY`, `HTTPS_ATIVO`, `PROXY_CONFIAVEL`, `INATIVIDADE_MINUTOS`, `FORMULARIO_MINUTOS`, `PORTAL_URL`, `FLASK_DEBUG`.
- Limites: `RATE_LIMIT_STORAGE_URI`.
- E-mail: `SMTP_HOST`, `SMTP_PORT`, `SMTP_USUARIO`, `SMTP_SENHA`, `SMTP_REMETENTE`, `SMTP_USAR_TLS`, `SMTP_USAR_SSL`, `RECUPERACAO_SENHA_MINUTOS`.

`serve.py` também aceita `PORTAL_HOST`, `PORTAL_PORT` e `PORTAL_THREADS`.

### Produção

O projeto fornece Waitress, com padrão local em `127.0.0.1:8000` e 16 threads, para uso atrás de proxy. Consultar `DEPLOY_APACHE_WINDOWS.md` e `OPERACAO_ESCALA.md` para implantação; configurar HTTPS e desabilitar debug. Em vários processos, manter chaves compatíveis e backend compartilhado de limitação de requisições.

## 11. Validação e limitações conhecidas

Nas últimas alterações foi feita uma checagem isolada da função de seleção de ambiente, extraída por AST e executada com dependências simuladas. Ela confirmou:

- Uso do contexto padrão pelo Administrador.
- Troca para outro ambiente autorizado.
- Rejeição de ambiente fora do escopo.
- Presença de `master_required` nas rotas de Administração de Guias.

Essa checagem não é um teste HTTP completo nem uma validação conectada ao banco.

As tentativas recentes de validar Jinja no Python acessível às ferramentas encontraram `ModuleNotFoundError: jinja2`. Isso não prova que o servidor do usuário esteja sem a dependência; pode ser outro interpretador. Identificar o ambiente Python usado pelo processo real antes de instalar ou alterar dependências.

A pasta consultada não foi reconhecida como repositório Git. Não há commit registrado para estas alterações nesta sessão.

O usuário aprovou visualmente as abas de ambiente e pediu a replicação para Administrador. A última restrição confirmada foi manter apenas Permissão de Ambiente dentro da Administração desse perfil.

### Conferência recomendada ao continuar

1. Entrar com Master e verificar as duas abas administrativas.
2. Entrar com Administrador e verificar apenas Permissão de Ambiente nessa área.
3. Conferir quatro ambientes por página, setas e abertura na página do ambiente selecionado.
4. Conferir escopo de ambientes e associação somente de Visualizadores pelo Administrador.
5. Testar permissões por pasta/subpasta/dashboard e busca.
6. Testar edição de usuário e os dois casos de redefinição de senha.
7. Alternar temas com controles abertos e conferir preservação do estado.
8. Conferir login em desktop e celular, inclusive redução de movimento.
9. Validar recuperação por e-mail e avisos em ambiente de testes quando esses módulos forem alterados.

## 12. Documentação complementar e divergências

- `README.md`: instalação e visão geral antiga.
- `MASTER.md`: criação do Master e histórico das regras de guias.
- `CONFIGURAR_EMAIL_RECUPERACAO.md`: configuração de recuperação de senha.
- `DEPLOY_APACHE_WINDOWS.md`: implantação.
- `OPERACAO_ESCALA.md`: operação, pool, limites, monitoramento e backup.
- `CONTINUIDADE_AVISOS_CODEX.md`: detalhes da remodelação de Avisos e convenções visuais.

Alguns documentos anteriores refletem estados antigos. Exemplo: o texto antigo do Master menciona possibilidade de remover todas as guias, mas o código atual preserva Minha conta. Referências a pacotes ZIP e diretórios temporários de sessões anteriores não garantem que esses arquivos estejam disponíveis nesta máquina.

Quando houver divergência, verificar o código atual e as decisões aprovadas registradas aqui; não restaurar uma implementação antiga apenas porque consta em um README.

## 13. Instrução pronta para continuidade

> Leia PROJETO_PORTAL_BI_CONTINUIDADE.md e confira o código atual antes de alterar. Este é o Portal BI em Flask com MySQL/MariaDB. Preserve os temas azul translúcido em gradiente, o padrão de abas da guia Acessos, a animação de ciência de dados do login e os controles de acesso por perfil, guia, ambiente e conteúdo. Na Administração, o Master tem Permissão de Ambiente e Administração de Guias; o Administrador tem somente Permissão de Ambiente. O seletor local de ambientes usa quatro itens por página, setas laterais e apenas ambientes autorizados. Preserve dados, histórico e configurações privadas. Para mudanças visuais maiores, prepare uma prévia quando solicitada e só implemente a proposta aprovada. Identifique o Python e o banco reais antes de testes que dependam deles.

## 14. Preferências de colaboração

- Comunicação em português, direta e objetiva.
- Inspecionar os arquivos reais antes de mudar o projeto.
- Respeitar as propostas visuais aprovadas e reutilizar seus componentes.
- Não considerar uma alteração concluída apenas por remover elementos antigos: conferir estilo, espaçamento, destaque ativo e funcionamento.
- Não abrir ou iniciar o portal automaticamente sem necessidade acordada.
- Não alterar permissões de perfis para resolver um problema visual.
- Preservar trabalhos existentes e evitar alterações destrutivas.

Fim do documento.
