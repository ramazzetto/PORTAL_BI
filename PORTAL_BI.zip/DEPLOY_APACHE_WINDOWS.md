# Colocando o Portal BI no ar: Apache no Windows Server

Este guia explica como publicar o portal no servidor Windows da empresa,
por trás do Apache que vocês já usam.

## Por que NÃO usar mod_wsgi no Windows

A forma "clássica" de rodar Flask no Apache é o módulo `mod_wsgi`. No
Windows, porém, ele é notoriamente problemático: exige um binário
compilado que bate **exatamente** com a versão do Apache, a versão do
Python e a arquitetura (32/64 bits) instaladas — qualquer divergência
gera erros difíceis de diagnosticar.

**A alternativa recomendada, mais simples e mais robusta no Windows:**
rodar o Flask com um servidor de produção próprio (**waitress**, feito
em Python puro, sem dependências de compilação) como um serviço do
Windows, e fazer o Apache atuar apenas como **proxy reverso** —
recebendo as requisições do usuário e repassando para o waitress.
Assim, Apache e Python nunca precisam ser compatíveis no nível binário.

```
Usuário (navegador)
      │  HTTPS
      ▼
   Apache (na porta 443, com certificado SSL)
      │  proxy reverso (HTTP, só na própria máquina)
      ▼
  Waitress servindo o Flask (ex.: 127.0.0.1:8000)
      │
      ▼
   MySQL/MariaDB
```

## Passo 1 — Preparar o Python e as dependências no servidor

1. Instale o Python 3.11+ no servidor (se ainda não tiver).
2. Copie a pasta do projeto (`Portal/`) para o servidor, por exemplo em
   `C:\PortalBI`.
3. Crie um ambiente virtual e instale as dependências:
   ```powershell
   cd C:\PortalBI
   python -m venv venv
   venv\Scripts\activate
   pip install -r requirements.txt
   ```
4. Crie o arquivo `.env` (baseado no `.env.exemplo`) com os dados reais
   do banco MySQL/MariaDB do servidor e uma `SECRET_KEY` forte.
   Configure também `DB_POOL_MAX_CONEXOES` por processo: para o exemplo
   abaixo com 16 threads, comece com `12`. Se houver mais de um processo do
   portal, some os pools de todos eles e mantenha o total abaixo de
   `max_connections` do MySQL/MariaDB.
5. Garanta que `debug=True` está **desligado** no `app.py` (veja a
   seção de segurança mais abaixo — isso é obrigatório antes de expor
   o portal na rede).

## Passo 2 — Rodar o Flask com o waitress

O projeto já inclui o arquivo `serve.py`. Ele usa Waitress com 16 threads
por padrão e aceita `PORTAL_THREADS`, `PORTAL_HOST` e `PORTAL_PORT` no `.env`.
Não exponha o Waitress diretamente: mantenha-o em `127.0.0.1` atrás do proxy.

Teste rodando manualmente primeiro:
```powershell
venv\Scripts\activate
python serve.py
```
Para o teste HTTP direto, use temporariamente `HTTPS_ATIVO=false` e
`PROXY_CONFIAVEL=false`, reinicie o processo e acesse `http://127.0.0.1:8000`.
Depois de configurar o Apache, aplique o perfil HTTPS abaixo e reinicie novamente.

## Passo 3 — Transformar em um Serviço do Windows (para rodar sozinho)

Use o **NSSM** (Non-Sucking Service Manager), gratuito, para registrar
o `serve.py` como serviço do Windows (assim ele inicia sozinho com o
servidor, sem precisar de ninguém logado):

1. Baixe o NSSM: https://nssm.cc/download
2. No PowerShell (como administrador):
   ```powershell
   nssm install PortalBI
   ```
3. Na janela que abrir:
   - **Path**: `C:\PortalBI\venv\Scripts\python.exe`
   - **Startup directory**: `C:\PortalBI`
   - **Arguments**: `serve.py`
4. Inicie o serviço:
   ```powershell
   nssm start PortalBI
   ```
5. Confirme pelo endereço correspondente ao perfil em uso (HTTP de teste ou domínio HTTPS).

## Passo 4 — Configurar o Apache como proxy reverso

No `httpd.conf` (ou num arquivo de configuração de site incluído por
ele), habilite os módulos de proxy (geralmente já vêm instalados,
só precisam ser descomentados):

```apache
LoadModule proxy_module modules/mod_proxy.so
LoadModule proxy_http_module modules/mod_proxy_http.so
LoadModule headers_module modules/mod_headers.so
```

Depois, adicione o bloco do site (ajuste o domínio/caminho conforme o
padrão da empresa):

```apache
<VirtualHost *:443>
    ServerName portal-bi.empresa.local

    SSLEngine on
    SSLCertificateFile "C:/caminho/para/certificado.crt"
    SSLCertificateKeyFile "C:/caminho/para/chave-privada.key"

    RequestHeader set X-Forwarded-Proto "https"
    ProxyPreserveHost On
    ProxyPass "/" "http://127.0.0.1:8000/"
    ProxyPassReverse "/" "http://127.0.0.1:8000/"
</VirtualHost>

<VirtualHost *:80>
    ServerName portal-bi.empresa.local
    Redirect permanent / https://portal-bi.empresa.local/
</VirtualHost>
```

Reinicie o Apache e acesse pelo domínio configurado. O Apache cuida do
HTTPS "de fora"; internamente, ele fala com o waitress via HTTP simples
— isso é seguro porque esse tráfego nunca sai da própria máquina.

> Se a empresa preferir usar o **IIS** em vez do Apache, o princípio é
> o mesmo: IIS com o módulo **Application Request Routing (ARR)**
> fazendo proxy reverso para o waitress na porta 8000.

## Antes de expor na rede: checklist de segurança

- [ ] `debug=False` no `app.py` (ou removido, já que quem sobe o app
      agora é o `serve.py`)
- [ ] `SECRET_KEY` forte e única, definida no `.env` do servidor (não a
      do código)
- [ ] Senha do banco forte, `.env` com permissão de leitura restrita
- [ ] HTTPS configurado no Apache (certificado válido)
- [ ] Senha do usuário `admin` padrão trocada
- [ ] Backup automático do banco (rotina do MySQL/MariaDB) configurado
- [ ] Firewall do Windows liberando só a porta 443 (não a 8000, que deve
      ficar acessível só localmente)


## Atualizacao de sessao: mesmos arquivos nos dois ambientes

Substitua `app.py` na raiz e `base.html`, `base_app.html` e `login.html`
na pasta `templates/`. O pacote ZIP entrega os arquivos sem pastas.
`.env.exemplo` e este guia ficam na raiz. Nao substitua seu `.env` existente
pelo exemplo: preserve as credenciais do banco e a chave secreta.
Nao e necessario executar SQL nem instalar novas dependencias para esta atualizacao.

No localhost com HTTP, adicione/ajuste no `.env`:

```dotenv
HTTPS_ATIVO=false
PROXY_CONFIAVEL=false
INATIVIDADE_MINUTOS=5
FORMULARIO_MINUTOS=30
```

No servidor HTTPS com **um** Apache/Nginx na frente da aplicacao:

```dotenv
HTTPS_ATIVO=true
PROXY_CONFIAVEL=true
INATIVIDADE_MINUTOS=5
FORMULARIO_MINUTOS=30
FLASK_DEBUG=false
```

Para múltiplos processos do portal, use Redis para que o limite de tentativas
de login seja único entre todos eles:

```dotenv
RATE_LIMIT_STORAGE_URI=redis://:senha-forte@redis.empresa.local:6379/0
PORTAL_THREADS=16
DB_POOL_MAX_CONEXOES=12
```

O endpoint interno `GET /saude` retorna `200` somente se o portal conseguir
consultar o MySQL/MariaDB. Use-o no monitoramento do proxy, sem publicá-lo
para a internet caso a política da empresa não permita.

Reinicie o processo/servico depois de alterar o `.env`. As variaveis definidas
no ambiente do processo prevalecem sobre o arquivo. O `.env` e carregado a
partir da pasta de `app.py`, independentemente do diretorio de inicializacao.
Mantenha a `SECRET_KEY` forte, estavel entre reinicializacoes e igual entre
processos da mesma instalacao. Use uma chave propria no servidor.

`PROXY_CONFIAVEL=true` confia em um intermediario para protocolo e IP, e so
deve ser usado com o backend restrito a esse proxy. O exemplo do Waitress
acima escuta apenas em loopback e preserva somente os cabecalhos necessarios.
Para HTTPS direto, sem intermediario, use `HTTPS_ATIVO=true` e
`PROXY_CONFIAVEL=false`. Cadeias com mais proxies exigem configuracao especifica.
O aplicativo nao instala certificados: configure-os no servidor HTTPS.

Se optar por Nginx, preserve `Host`, sobrescreva `X-Forwarded-Proto` com `$scheme`
e encaminhe `X-Forwarded-For` adequadamente. Restrinja a porta do backend e
redirecione HTTP para HTTPS no servidor de entrada.

### Comportamento apos a atualizacao

- Cookie exclusivo `portal_bi_session` para formularios (padrao: 30 minutos).
- CSRF permanece ativo. O login atualiza o token antes de enviar as credenciais.
  Se JavaScript estiver desabilitado, o envio normal continua protegido;
  um formulario expirado e reapresentado com explicacao e senha vazia.
- Paginas dinamicas e respostas de sessao usam `Cache-Control: no-store`.
- A autenticacao por aba vence por inatividade (padrao: 5 minutos).
  Interacoes na pagina renovam a autenticacao com intervalo minimo de 1 minuto;
  o botao Continuar conectado confirma a renovacao com o servidor.
  O aviso aparece no ultimo minuto. Uma sessao ja expirada exige novo login.
- Cliques dentro do iframe do Power BI nao sao eventos da pagina do portal.
  O aviso continua necessario durante uso prolongado somente do relatorio.
- Abrir/atualizar a tela de login nao consome o limite de 8 envios por minuto.
  O limite usa memoria de cada processo; varias instancias exigem armazenamento
  compartilhado para um limite global.
- Preferencias das arvores migram dos cookies `det_*` para armazenamento local,
  mantendo escopos independentes por tela. Autenticacao nao vai para localStorage.
- Cookies de autenticacao invalidos/expirados sao limpos em lotes de ate 8 por
  resposta. Contextos validos de outras abas continuam funcionando.
- Falhas CSRF registram apenas endpoint e motivo, sem senhas ou tokens.

Na primeira abertura apos a atualizacao, paginas antigas podem precisar de
recarregamento e novo login. A mudanca do cookie de formularios isola o portal
sem apagar cookies de outros projetos. Se os cookies antigos ja impedirem ate
a abertura da pagina (erro de cabecalho muito grande), remova os cookies do
portal nas configuracoes do navegador uma vez para permitir a migracao.

Referencias: [Flask e proxy](https://flask.palletsprojects.com/en/stable/deploying/proxy_fix/),
[Waitress e proxy](https://docs.pylonsproject.org/projects/waitress/en/latest/reverse-proxy.html),
[seguranca Flask](https://flask.palletsprojects.com/en/stable/web-security/).


### Acompanhamento ao vivo dos avisos

A guia Avisos usa uma conexão HTTP de eventos (SSE) por aba administrativa
visível. No Waitress, mantenha `threads=16` no exemplo acima; cada conexão
ativa ocupa uma thread, e é necessário reservar threads para login e respostas
dos usuários. Dimensione esse número conforme a quantidade de administradores
simultâneos. As conexões são fechadas quando a aba fica oculta e reabertas
quando ela volta a ser usada. O histórico permanece no MySQL.

Se houver proxy com buffering de respostas, desative o buffering para a rota
`/aviso/<id>/fluxo` e permita respostas `text/event-stream`. A aplicação envia
`X-Accel-Buffering: no` e reabre periodicamente a conexão para revalidar o acesso.
Verifique o recebimento dos eventos através do proxy ao configurar produção.
