-- Portal BI: limpar somente os registros de testes dos avisos.
-- Execute o script inteiro na conexao MySQL/MariaDB do portal.
-- Feche as abas do portal antes de executar, para evitar novos eventos durante a limpeza.
-- Avisos publicados, assuntos, usuarios e dashboards serao preservados.

USE portal_bi;

START TRANSACTION;

-- Mesmo bloqueio usado pelo portal para registrar as respostas.
SELECT aviso_id FROM avisos_estado WHERE id = 1 FOR UPDATE;

DELETE FROM avisos_eventos;

-- Permite que os usuarios recebam e respondam novamente ao aviso atual.
UPDATE avisos_destinatarios
SET visualizado_em = NULL,
    aceito_em = NULL,
    recusado_em = NULL;

COMMIT;

-- Os dois resultados abaixo devem ser zero antes de novos acessos ao portal.
SELECT COUNT(*) AS eventos_restantes FROM avisos_eventos;
SELECT COUNT(*) AS respostas_restantes
FROM avisos_destinatarios
WHERE visualizado_em IS NOT NULL
   OR aceito_em IS NOT NULL
   OR recusado_em IS NOT NULL;
