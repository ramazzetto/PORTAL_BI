-- MySQL dump 10.13  Distrib 8.0.19, for Win64 (x86_64)
--
-- Host: localhost    Database: portal_bi
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `acessos`
--

DROP TABLE IF EXISTS `acessos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `acessos` (
  `id` varchar(32) NOT NULL,
  `data_hora` varchar(19) NOT NULL,
  `usuario_id` varchar(32) DEFAULT NULL,
  `usuario_nome` varchar(255) DEFAULT NULL,
  `usuario_login` varchar(100) DEFAULT NULL,
  `usuario_papel` varchar(20) DEFAULT NULL,
  `dashboard_id` varchar(32) DEFAULT NULL,
  `dashboard_nome` varchar(255) DEFAULT NULL,
  `pasta_nome` varchar(255) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `ip` varchar(64) DEFAULT NULL,
  `ambiente_id` varchar(32) NOT NULL DEFAULT 'inicial',
  PRIMARY KEY (`id`),
  KEY `idx_data_hora` (`data_hora`),
  KEY `idx_ambiente` (`ambiente_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acessos`
--

LOCK TABLES `acessos` WRITE;
/*!40000 ALTER TABLE `acessos` DISABLE KEYS */;
INSERT INTO `acessos` VALUES ('019b3164','2026-09-02 17:23:05','6afac0da400348f4b35ebf9c64a29fbe','rodrigo.mazzetto','login.master','master','288c7bee','Painel de Assiduidade','Mawwal','sucesso','127.0.0.1','inicial'),('0304485d','2026-09-01 16:16:12','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('039235b3','2026-09-01 09:08:10','60cd6f66','Rodrigo Augusto Mazzetto','rodrigo.mazzetto','viewer','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('09be25a1','2026-08-30 16:33:39','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('0bdec143','2026-09-03 15:01:32','ee4bfd02','Administrador','admin','admin','81f9fabf','teste','teste','sucesso','127.0.0.1','459565b333e94f6fb2b118b80520fd4b'),('0c243772','2026-08-31 11:03:47','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('0c428d68','2026-08-30 20:53:55','95b7377b','teste1','teste1','viewer','1d4be6de','Painel de Assiduidade','Flora','sucesso','127.0.0.1','inicial'),('0e3f0b01','2026-08-31 22:48:44','ee4bfd02','Administrador','admin','admin','f142e019','teste','Teste','sucesso','127.0.0.1','inicial'),('102af184','2026-09-01 16:20:39','ee4bfd02','Administrador','admin','admin','288c7bee','Painel de Assiduidade','Mawwal','sucesso','127.0.0.1','inicial'),('1102fe2c','2026-09-03 14:16:18','ee4bfd02','Administrador','admin','admin','8c2d9f3f','teste','Nestlé','sucesso','127.0.0.1','139fec16091c410cae525b696fd400f4'),('1110e5d7','2026-09-02 13:42:36','6afac0da400348f4b35ebf9c64a29fbe','rodrigo.mazzetto','login.master','master','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('13a0a563','2026-09-01 16:20:34','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('1641aa27','2026-08-31 17:11:26','ee4bfd02','Administrador','admin','admin','dcd59548','Painel de Execução','Nestlé','sucesso','127.0.0.1','inicial'),('1a4bb6c9','2026-09-02 10:19:33','6afac0da400348f4b35ebf9c64a29fbe','rodrigo.mazzetto','login.master','master','288c7bee','Painel de Assiduidade','Mawwal','sucesso','127.0.0.1','inicial'),('1dbceee8','2026-09-02 22:51:22','5ff1f9abf4ee49298bdd0a2f4d95b892','Samaly Aghata Constantino','samaly.constantino','viewer','1d4be6de','Painel de Assiduidade','Flora','sucesso','127.0.0.1','inicial'),('1e148a0a','2026-08-31 11:09:06','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('1e67846e','2026-08-30 14:14:53','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('260f8e8b','2026-08-30 16:31:54','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('28cfd8f5','2026-08-31 16:40:09','ee4bfd02','Administrador','admin','admin','dcd59548','Painel de Execução','Nestlé','sucesso','127.0.0.1','inicial'),('2a7a0679','2026-09-02 08:36:00','6afac0da400348f4b35ebf9c64a29fbe','rodrigo.mazzetto','login.master','master','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('2bd71cf4','2026-08-30 13:53:53','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('2bf2218c','2026-08-31 14:38:06','ee4bfd02','Administrador','admin','admin','3337f5ac','Painel de Assiduidade','Puratos','sucesso','127.0.0.1','inicial'),('2da7002e','2026-08-30 16:37:11','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('2fba5c59','2026-09-03 14:14:29','ee4bfd02','Administrador','admin','admin','8c2d9f3f','teste','Nestlé','sucesso','127.0.0.1','139fec16091c410cae525b696fd400f4'),('37a53ada','2026-08-30 16:41:00','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('3992cb4d','2026-09-01 16:16:31','ee4bfd02','Administrador','admin','admin','3337f5ac','Painel de Assiduidade','Puratos','sucesso','127.0.0.1','inicial'),('39a8e904','2026-08-30 13:35:34','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('3ae8071d','2026-09-02 09:52:23','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('3ea58ccb','2026-08-31 10:37:05','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('3f214e12','2026-08-30 17:27:51','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('3ff21a3c','2026-08-30 21:06:29','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('42115a22','2026-08-30 20:40:41','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('434b7199','2026-09-01 00:02:25','ee4bfd02','Administrador','admin','admin','dcd59548','Painel de Execução','Nestlé','sucesso','127.0.0.1','inicial'),('488f9b8c','2026-09-01 20:23:01','ee4bfd02','Administrador','admin','admin','288c7bee','Painel de Assiduidade','Mawwal','sucesso','127.0.0.1','inicial'),('48987dc3','2026-08-31 16:40:26','ee4bfd02','Administrador','admin','admin','dcd59548','Painel de Execução','Nestlé','sucesso','127.0.0.1','inicial'),('538122d7','2026-09-01 14:44:52','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('543e0f3c','2026-08-31 17:57:41','ee4bfd02','Administrador','admin','admin','3337f5ac','Painel de Assiduidade','Puratos','sucesso','127.0.0.1','inicial'),('55448245','2026-08-31 17:58:29','ee4bfd02','Administrador','admin','admin','dcd59548','Painel de Execução','Nestlé','sucesso','127.0.0.1','inicial'),('555d52ab','2026-09-02 09:52:47','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('559adddf','2026-08-31 23:58:50','ee4bfd02','Administrador','admin','admin','dcd59548','Painel de Execução','Nestlé','sucesso','127.0.0.1','inicial'),('56af39c1','2026-08-30 16:32:43','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('5bc59f38','2026-09-01 20:59:35','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('5dd56521','2026-08-30 13:40:08','ee4bfd02','Administrador','admin','admin','1d4be6de','Painel de Assiduidade','Flora','sucesso','127.0.0.1','inicial'),('5e18568e','2026-09-02 13:42:42','6afac0da400348f4b35ebf9c64a29fbe','rodrigo.mazzetto','login.master','master','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('6063b478','2026-09-01 12:46:12','ee4bfd02','Administrador','admin','admin','288c7bee','Painel de Assiduidade','Mawwal','sucesso','127.0.0.1','inicial'),('629ef583','2026-09-01 15:17:58','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('62c7a8fd','2026-08-31 10:05:23','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('62d95245','2026-08-31 17:07:50','ee4bfd02','Administrador','admin','admin','6f096245','Faturamento','Nestlé','sucesso','127.0.0.1','inicial'),('65151c87','2026-08-30 16:37:05','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('6520c400','2026-08-31 15:51:34','ee4bfd02','Administrador','admin','admin','1d4be6de','Painel de Assiduidade','Flora','sucesso','127.0.0.1','inicial'),('654d555f','2026-08-31 17:10:23','60cd6f66','Rodrigo Augusto Mazzetto','rodrigo.mazzetto','viewer','6f096245','Faturamento','Nestlé','sucesso','127.0.0.1','inicial'),('675865b7','2026-08-30 16:34:02','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('6b293360','2026-08-31 15:14:23','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('6d8ee870','2026-08-31 10:16:38','ee4bfd02','Administrador','admin','admin','1d4be6de','Painel de Assiduidade','Flora','sucesso','127.0.0.1','inicial'),('6ff8c2e9','2026-08-30 16:32:09','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('718c2a09','2026-09-03 14:18:11','7becc38bd3464e7991dfd56add38bed1','Rodrigo Augusto','rodrigo.augusto','viewer','8c2d9f3f','teste','Nestlé','sucesso','127.0.0.1','139fec16091c410cae525b696fd400f4'),('72d24db4','2026-08-31 17:09:06','ee4bfd02','Administrador','admin','admin','9ffde92c','Acompanhamento Técnico','Nestlé','sucesso','127.0.0.1','inicial'),('744000d5','2026-08-31 15:42:38','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('749b9b48','2026-09-02 13:49:01','6afac0da400348f4b35ebf9c64a29fbe','rodrigo.mazzetto','login.master','master','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('788cac44','2026-08-30 20:35:34','ee4bfd02','Administrador','admin','admin','288c7bee','Painel de Assiduidade','Mawwal','sucesso','127.0.0.1','inicial'),('7c76911d','2026-08-31 10:10:48','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('7cf90c58','2026-08-31 15:45:04','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('7e10b050','2026-08-31 17:27:03','60cd6f66','Rodrigo Augusto Mazzetto','rodrigo.mazzetto','viewer','288c7bee','Painel de Assiduidade','Mawwal','sucesso','127.0.0.1','inicial'),('7e6a0901','2026-09-01 09:11:41','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('80916604','2026-08-31 11:35:32','ee4bfd02','Administrador','admin','admin','288c7bee','Painel de Assiduidade','Mawwal','sucesso','127.0.0.1','inicial'),('83621d0f','2026-09-01 12:46:18','ee4bfd02','Administrador','admin','admin','288c7bee','Painel de Assiduidade','Mawwal','sucesso','127.0.0.1','inicial'),('8a8be79d','2026-08-31 11:01:21','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('8b28b41d','2026-09-01 17:59:50','60cd6f66','Rodrigo Augusto Mazzetto','rodrigo.mazzetto','viewer','dcd59548','Painel de Execução','Nestlé','sucesso','127.0.0.1','inicial'),('981d09e6','2026-09-02 11:16:26','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('98a7233f','2026-08-31 17:04:24','ee4bfd02','Administrador','admin','admin','dcd59548','Painel de Execução','Nestlé','sucesso','127.0.0.1','inicial'),('99250ce8','2026-09-02 10:49:14','6afac0da400348f4b35ebf9c64a29fbe','rodrigo.mazzetto','login.master','master','288c7bee','Painel de Assiduidade','Mawwal','sucesso','127.0.0.1','inicial'),('99ece46a','2026-09-02 13:49:02','6afac0da400348f4b35ebf9c64a29fbe','rodrigo.mazzetto','login.master','master','288c7bee','Painel de Assiduidade','Mawwal','sucesso','127.0.0.1','inicial'),('9b0cba09','2026-08-31 11:35:17','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('9b95c3ee','2026-09-02 10:49:13','6afac0da400348f4b35ebf9c64a29fbe','rodrigo.mazzetto','login.master','master','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('9c0b4db5','2026-08-31 14:03:24','ee4bfd02','Administrador','admin','admin','3337f5ac','Painel de Assiduidade','Puratos','sucesso','127.0.0.1','inicial'),('9e7838f1','2026-09-01 20:18:10','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('9f66d7ef','2026-09-01 16:16:26','ee4bfd02','Administrador','admin','admin','1d4be6de','Painel de Assiduidade','Flora','sucesso','127.0.0.1','inicial'),('a46dc5bb','2026-09-02 10:11:01','6afac0da400348f4b35ebf9c64a29fbe','rodrigo.mazzetto','login.master','master','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('a50799cf','2026-09-02 22:50:19','5ff1f9abf4ee49298bdd0a2f4d95b892','Samaly Aghata Constantino','samaly.constantino','viewer','1d4be6de','Painel de Assiduidade','Flora','sucesso','127.0.0.1','inicial'),('a59baad1','2026-09-02 13:42:51','6afac0da400348f4b35ebf9c64a29fbe','rodrigo.mazzetto','login.master','master','1d4be6de','Painel de Assiduidade','Flora','sucesso','127.0.0.1','inicial'),('a6721c0e','2026-08-31 16:40:40','ee4bfd02','Administrador','admin','admin','3337f5ac','Painel de Assiduidade','Puratos','sucesso','127.0.0.1','inicial'),('a7960133','2026-08-31 11:35:07','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('ac9c6a80','2026-09-01 12:46:05','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('ad4a0a69','2026-09-01 12:50:06','ee4bfd02','Administrador','admin','admin','1d4be6de','Painel de Assiduidade','Flora','sucesso','127.0.0.1','inicial'),('ad5d0c14','2026-08-30 16:34:46','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('aed41ea6','2026-08-31 10:37:10','ee4bfd02','Administrador','admin','admin','288c7bee','Painel de Assiduidade','Mawwal','sucesso','127.0.0.1','inicial'),('b0acbd2a','2026-08-31 16:40:34','ee4bfd02','Administrador','admin','admin','3337f5ac','Painel de Assiduidade','Puratos','sucesso','127.0.0.1','inicial'),('b0b1735c','2026-09-02 09:37:44','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('b31529a5','2026-08-30 16:36:52','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('b5c66061','2026-09-02 13:42:46','6afac0da400348f4b35ebf9c64a29fbe','rodrigo.mazzetto','login.master','master','288c7bee','Painel de Assiduidade','Mawwal','sucesso','127.0.0.1','inicial'),('bb763eb2','2026-08-31 09:26:53','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('bc4efbc0','2026-08-31 16:40:01','ee4bfd02','Administrador','admin','admin','dcd59548','Painel de Execução','Nestlé','sucesso','127.0.0.1','inicial'),('bc5d6973','2026-09-02 13:42:40','6afac0da400348f4b35ebf9c64a29fbe','rodrigo.mazzetto','login.master','master','288c7bee','Painel de Assiduidade','Mawwal','sucesso','127.0.0.1','inicial'),('bce0a32d','2026-09-01 12:45:59','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('c07bba7e','2026-09-02 13:43:27','6afac0da400348f4b35ebf9c64a29fbe','rodrigo.mazzetto','login.master','master','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('c092a51d','2026-08-31 15:14:24','ee4bfd02','Administrador','admin','admin','288c7bee','Painel de Assiduidade','Mawwal','sucesso','127.0.0.1','inicial'),('c0988a4a','2026-08-31 14:03:57','ee4bfd02','Administrador','admin','admin','3337f5ac','Painel de Assiduidade','Puratos','sucesso','127.0.0.1','inicial'),('c6fbc433','2026-08-31 10:10:45','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('c8704c2e','2026-09-01 07:53:06','ee4bfd02','Administrador','admin','admin','dcd59548','Painel de Execução','Nestlé','sucesso','127.0.0.1','inicial'),('caae2236','2026-09-02 10:11:07','6afac0da400348f4b35ebf9c64a29fbe','rodrigo.mazzetto','login.master','master','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('cab58497','2026-08-30 13:18:36','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('cb94b4ff','2026-08-31 22:48:54','ee4bfd02','Administrador','admin','admin','f142e019','teste','Teste','sucesso','127.0.0.1','inicial'),('cb9f5745','2026-09-02 22:50:29','5ff1f9abf4ee49298bdd0a2f4d95b892','Samaly Aghata Constantino','samaly.constantino','viewer','1d4be6de','Painel de Assiduidade','Flora','sucesso','127.0.0.1','inicial'),('ccfe5342','2026-09-02 13:48:55','6afac0da400348f4b35ebf9c64a29fbe','rodrigo.mazzetto','login.master','master','dcd59548','Painel de Execução','Nestlé','sucesso','127.0.0.1','inicial'),('ceb116e3','2026-08-31 15:24:05','ee4bfd02','Administrador','admin','admin','288c7bee','Painel de Assiduidade','Mawwal','sucesso','127.0.0.1','inicial'),('cf50766a','2026-09-01 16:16:22','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('cfb5760f','2026-09-02 09:52:43','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('d357eaab','2026-09-01 12:50:23','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('d3ed1a07','2026-08-30 16:33:29','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('d5afe980','2026-09-01 20:17:02','60cd6f66','Rodrigo Augusto Mazzetto','rodrigo.mazzetto','viewer','288c7bee','Painel de Assiduidade','Mawwal','sucesso','127.0.0.1','inicial'),('d70a8aae','2026-09-01 20:17:35','60cd6f66','Rodrigo Augusto Mazzetto','rodrigo.mazzetto','viewer','288c7bee','Painel de Assiduidade','Mawwal','sucesso','127.0.0.1','inicial'),('d793445e','2026-09-02 22:00:42','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('d84d42f6','2026-08-31 17:03:26','ee4bfd02','Administrador','admin','admin','dcd59548','Painel de Execução','Nestlé','sucesso','127.0.0.1','inicial'),('d869cb00','2026-08-31 22:48:57','ee4bfd02','Administrador','admin','admin','f142e019','teste','Teste','sucesso','127.0.0.1','inicial'),('d9290bf8','2026-09-01 20:18:22','ee4bfd02','Administrador','admin','admin','6f096245','Faturamento','Nestlé','sucesso','127.0.0.1','inicial'),('da80cc17','2026-09-03 14:15:03','ee4bfd02','Administrador','admin','admin','8c2d9f3f','teste','Nestlé','sucesso','127.0.0.1','139fec16091c410cae525b696fd400f4'),('dc8e5c3b','2026-09-02 13:42:53','6afac0da400348f4b35ebf9c64a29fbe','rodrigo.mazzetto','login.master','master','288c7bee','Painel de Assiduidade','Mawwal','sucesso','127.0.0.1','inicial'),('e51c973f','2026-08-31 20:39:42','ee4bfd02','Administrador','admin','admin','dcd59548','Painel de Execução','Nestlé','sucesso','127.0.0.1','inicial'),('e5a06672','2026-08-30 16:49:33','ee4bfd02','Administrador','admin','admin','288c7bee','Painel de Assiduidade','Mawwal','sucesso','127.0.0.1','inicial'),('e5babcd9','2026-09-01 08:53:17','ee4bfd02','Administrador','admin','admin','88406527','teste','TESTE_TESTE','sucesso','127.0.0.1','inicial'),('e613e2ad','2026-08-31 14:08:17','ee4bfd02','Administrador','admin','admin','3337f5ac','Painel de Assiduidade','Puratos','sucesso','127.0.0.1','inicial'),('e86f8a31','2026-09-02 22:43:56','6afac0da400348f4b35ebf9c64a29fbe','rodrigo.mazzetto','login.master','master','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('f045deb4','2026-08-31 11:35:27','ee4bfd02','Administrador','admin','admin','1d4be6de','Painel de Assiduidade','Flora','sucesso','127.0.0.1','inicial'),('f0e325ba','2026-08-31 10:28:56','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('f50c59e2','2026-08-31 15:14:18','ee4bfd02','Administrador','admin','admin','3337f5ac','Painel de Assiduidade','Puratos','sucesso','127.0.0.1','inicial'),('f557c90f','2026-08-30 13:17:54','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('f60ca885','2026-08-30 20:35:25','ee4bfd02','Administrador','admin','admin','288c7bee','Painel de Assiduidade','Mawwal','sucesso','127.0.0.1','inicial'),('fa245e92','2026-08-31 16:39:38','ee4bfd02','Administrador','admin','admin','dcd59548','Painel de Execução','Nestlé','sucesso','127.0.0.1','inicial'),('fad4a76c','2026-08-31 09:25:04','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('fca9eb8b','2026-09-01 20:22:47','ee4bfd02','Administrador','admin','admin','288c7bee','Painel de Assiduidade','Mawwal','sucesso','127.0.0.1','inicial'),('fd413e2c','2026-08-30 16:20:12','ee4bfd02','Administrador','admin','admin','f58d38bd','Pesquisa de Vendas','Mawwal','sucesso','127.0.0.1','inicial'),('fd5f5896','2026-08-31 23:58:35','ee4bfd02','Administrador','admin','admin','3337f5ac','Painel de Assiduidade','Puratos','sucesso','127.0.0.1','inicial'),('ff611ad8','2026-08-31 16:32:29','ee4bfd02','Administrador','admin','admin','1d4be6de','Painel de Assiduidade','Flora','sucesso','127.0.0.1','inicial');
/*!40000 ALTER TABLE `acessos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ambiente_avisos`
--

DROP TABLE IF EXISTS `ambiente_avisos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ambiente_avisos` (
  `ambiente_id` varchar(32) NOT NULL,
  `aviso_id` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`ambiente_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ambiente_avisos`
--

LOCK TABLES `ambiente_avisos` WRITE;
/*!40000 ALTER TABLE `ambiente_avisos` DISABLE KEYS */;
INSERT INTO `ambiente_avisos` VALUES ('139fec16091c410cae525b696fd400f4',NULL),('459565b333e94f6fb2b118b80520fd4b',NULL),('inicial','bdec152c2dcc41e38a10863b186cf650');
/*!40000 ALTER TABLE `ambiente_avisos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ambiente_migracoes`
--

DROP TABLE IF EXISTS `ambiente_migracoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ambiente_migracoes` (
  `id` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ambiente_migracoes`
--

LOCK TABLES `ambiente_migracoes` WRITE;
/*!40000 ALTER TABLE `ambiente_migracoes` DISABLE KEYS */;
INSERT INTO `ambiente_migracoes` VALUES ('ambiente-inicial-v1');
/*!40000 ALTER TABLE `ambiente_migracoes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ambiente_sessoes`
--

DROP TABLE IF EXISTS `ambiente_sessoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ambiente_sessoes` (
  `sessao` varchar(32) NOT NULL,
  `usuario_id` varchar(32) NOT NULL,
  `ambiente_id` varchar(32) NOT NULL,
  `atualizado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`sessao`),
  KEY `idx_ambiente_sessao_usuario` (`usuario_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ambiente_sessoes`
--

LOCK TABLES `ambiente_sessoes` WRITE;
/*!40000 ALTER TABLE `ambiente_sessoes` DISABLE KEYS */;
INSERT INTO `ambiente_sessoes` VALUES ('367ceec38f6844ff','ee4bfd02','459565b333e94f6fb2b118b80520fd4b','2026-09-03 19:17:35'),('e9aab476da5d4f0d','ee4bfd02','139fec16091c410cae525b696fd400f4','2026-09-03 16:10:55');
/*!40000 ALTER TABLE `ambiente_sessoes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ambiente_usuarios`
--

DROP TABLE IF EXISTS `ambiente_usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ambiente_usuarios` (
  `ambiente_id` varchar(32) NOT NULL,
  `usuario_id` varchar(32) NOT NULL,
  `associado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ambiente_id`,`usuario_id`),
  KEY `idx_ambiente_usuario` (`usuario_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ambiente_usuarios`
--

LOCK TABLES `ambiente_usuarios` WRITE;
/*!40000 ALTER TABLE `ambiente_usuarios` DISABLE KEYS */;
INSERT INTO `ambiente_usuarios` VALUES ('139fec16091c410cae525b696fd400f4','7becc38bd3464e7991dfd56add38bed1','2026-09-03 17:16:53'),('139fec16091c410cae525b696fd400f4','ee4bfd02','2026-09-03 14:20:16'),('459565b333e94f6fb2b118b80520fd4b','95b7377b','2026-09-03 14:12:58'),('459565b333e94f6fb2b118b80520fd4b','ee4bfd02','2026-09-03 13:51:23'),('inicial','ee4bfd02','2026-09-03 13:50:36');
/*!40000 ALTER TABLE `ambiente_usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ambientes`
--

DROP TABLE IF EXISTS `ambientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ambientes` (
  `id` varchar(32) NOT NULL,
  `nome` varchar(120) NOT NULL,
  `ativo` tinyint NOT NULL DEFAULT '1',
  `criado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_ambiente_nome` (`nome`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ambientes`
--

LOCK TABLES `ambientes` WRITE;
/*!40000 ALTER TABLE `ambientes` DISABLE KEYS */;
INSERT INTO `ambientes` VALUES ('139fec16091c410cae525b696fd400f4','Nestlé',1,'2026-09-03 14:19:44'),('459565b333e94f6fb2b118b80520fd4b','Mawwal',1,'2026-09-03 13:51:16'),('inicial','Ambiente inicial',0,'2026-09-03 13:50:36');
/*!40000 ALTER TABLE `ambientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `aviso_fixado`
--

DROP TABLE IF EXISTS `aviso_fixado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `aviso_fixado` (
  `id` tinyint NOT NULL DEFAULT '1',
  `texto` text NOT NULL,
  `atualizado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aviso_fixado`
--

LOCK TABLES `aviso_fixado` WRITE;
/*!40000 ALTER TABLE `aviso_fixado` DISABLE KEYS */;
INSERT INTO `aviso_fixado` VALUES (1,'Iremos realizar uma manutenção preventiva na data 05/09/2026, dessa forma o Portal Bi ficará indisponível.','2026-09-03 00:59:04');
/*!40000 ALTER TABLE `aviso_fixado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `avisos_destinatarios`
--

DROP TABLE IF EXISTS `avisos_destinatarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `avisos_destinatarios` (
  `aviso_id` varchar(32) NOT NULL,
  `usuario_id` varchar(32) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `usuario` varchar(100) NOT NULL,
  `papel` varchar(20) NOT NULL,
  `visualizado_em` datetime DEFAULT NULL,
  `aceito_em` datetime DEFAULT NULL,
  `recusado_em` datetime DEFAULT NULL,
  PRIMARY KEY (`aviso_id`,`usuario_id`),
  CONSTRAINT `avisos_destinatarios_ibfk_1` FOREIGN KEY (`aviso_id`) REFERENCES `avisos_publicacoes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `avisos_destinatarios`
--

LOCK TABLES `avisos_destinatarios` WRITE;
/*!40000 ALTER TABLE `avisos_destinatarios` DISABLE KEYS */;
INSERT INTO `avisos_destinatarios` VALUES ('5a73e48282b843c78aa1310029808127','0de52dd703034be19b09306b9f7278db','Rodrigo Augusto Mazzetto','rodrigo.mazzetto','viewer',NULL,NULL,NULL),('5a73e48282b843c78aa1310029808127','5ff1f9abf4ee49298bdd0a2f4d95b892','Samaly Aghata Constantino','samaly.constantino','viewer','2026-09-02 22:48:47','2026-09-02 22:48:54',NULL),('5a73e48282b843c78aa1310029808127','6afac0da400348f4b35ebf9c64a29fbe','rodrigo.mazzetto','login.master','master',NULL,NULL,NULL),('5a73e48282b843c78aa1310029808127','95b7377b','teste1','teste1','viewer',NULL,NULL,NULL),('5a73e48282b843c78aa1310029808127','ee4bfd02','Administrador','admin','admin','2026-09-02 21:59:31','2026-09-02 21:59:36',NULL),('966ca61f3b154c7cb19c3a29518df6b2','6afac0da400348f4b35ebf9c64a29fbe','rodrigo.mazzetto','login.master','master',NULL,NULL,NULL),('966ca61f3b154c7cb19c3a29518df6b2','95b7377b','teste1','teste1','viewer','2026-09-02 09:39:37',NULL,'2026-09-02 09:39:41'),('966ca61f3b154c7cb19c3a29518df6b2','ee4bfd02','Administrador','admin','admin','2026-09-02 08:56:41','2026-09-02 08:56:46',NULL),('a18bbfabeb614abf9817ddc512ccdf1c','95b7377b','teste1','teste1','viewer','2026-09-03 11:18:19','2026-09-03 11:18:22',NULL),('a18bbfabeb614abf9817ddc512ccdf1c','ee4bfd02','Administrador','admin','admin',NULL,NULL,NULL),('ba1cc413cafb4082824304149117d43a','95b7377b','teste1','teste1','viewer',NULL,NULL,NULL),('ba1cc413cafb4082824304149117d43a','ee4bfd02','Administrador','admin','admin','2026-09-03 11:18:52','2026-09-03 11:18:54',NULL),('bdec152c2dcc41e38a10863b186cf650','ee4bfd02','Administrador','admin','admin',NULL,NULL,NULL),('da609ce6d2984fdc858d51a0e0e50428','ee4bfd02','Administrador','admin','admin',NULL,NULL,NULL),('dab582bca931422cb52b8e932711fbbc','60cd6f66','Rodrigo Augusto Mazzetto','rodrigo.mazzetto','viewer','2026-09-01 23:01:51',NULL,'2026-09-01 23:01:52'),('dab582bca931422cb52b8e932711fbbc','6a022513','Samaly','samaly.constantino','viewer',NULL,NULL,NULL),('dab582bca931422cb52b8e932711fbbc','95b7377b','teste1','teste1','viewer',NULL,NULL,NULL),('dab582bca931422cb52b8e932711fbbc','ee4bfd02','Administrador','admin','admin','2026-09-01 23:01:33','2026-09-01 23:01:40',NULL),('f4b20a5290c44c5c88c7c350098b2946','60cd6f66','Rodrigo Augusto Mazzetto','rodrigo.mazzetto','viewer',NULL,NULL,NULL),('f4b20a5290c44c5c88c7c350098b2946','6a022513','Samaly','samaly.constantino','viewer',NULL,NULL,NULL),('f4b20a5290c44c5c88c7c350098b2946','6afac0da400348f4b35ebf9c64a29fbe','rodrigo.mazzetto','login.master','master','2026-09-01 23:42:51','2026-09-01 23:43:01',NULL),('f4b20a5290c44c5c88c7c350098b2946','95b7377b','teste1','teste1','viewer',NULL,NULL,NULL),('f4b20a5290c44c5c88c7c350098b2946','ee4bfd02','Administrador','admin','admin','2026-09-01 23:07:26','2026-09-01 23:07:30',NULL);
/*!40000 ALTER TABLE `avisos_destinatarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `avisos_estado`
--

DROP TABLE IF EXISTS `avisos_estado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `avisos_estado` (
  `id` tinyint NOT NULL,
  `aviso_id` varchar(32) DEFAULT NULL,
  `migrado` tinyint NOT NULL DEFAULT '0',
  `eventos_migrados` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `avisos_estado`
--

LOCK TABLES `avisos_estado` WRITE;
/*!40000 ALTER TABLE `avisos_estado` DISABLE KEYS */;
INSERT INTO `avisos_estado` VALUES (1,'5a73e48282b843c78aa1310029808127',1,1);
/*!40000 ALTER TABLE `avisos_estado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `avisos_eventos`
--

DROP TABLE IF EXISTS `avisos_eventos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `avisos_eventos` (
  `aviso_id` varchar(32) NOT NULL,
  `usuario_id` varchar(32) NOT NULL,
  `evento_id` varchar(40) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `usuario` varchar(100) NOT NULL,
  `papel` varchar(20) NOT NULL,
  `visualizado_em` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `aceito_em` datetime DEFAULT NULL,
  `recusado_em` datetime DEFAULT NULL,
  PRIMARY KEY (`aviso_id`,`usuario_id`,`evento_id`),
  CONSTRAINT `avisos_eventos_ibfk_1` FOREIGN KEY (`aviso_id`) REFERENCES `avisos_publicacoes` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `avisos_eventos`
--

LOCK TABLES `avisos_eventos` WRITE;
/*!40000 ALTER TABLE `avisos_eventos` DISABLE KEYS */;
INSERT INTO `avisos_eventos` VALUES ('5a73e48282b843c78aa1310029808127','5ff1f9abf4ee49298bdd0a2f4d95b892','85fd13ea5f8c2b065a4d369be93d2d81','Samaly Aghata Constantino','samaly.constantino','viewer','2026-09-02 22:48:47','2026-09-02 22:48:54',NULL),('5a73e48282b843c78aa1310029808127','ee4bfd02','7c536b03c367e936232f757ff233644d','Administrador','admin','admin','2026-09-02 21:59:31','2026-09-02 21:59:36',NULL),('966ca61f3b154c7cb19c3a29518df6b2','95b7377b','cf2f05c41f4b997fba01eedd6f1db1fe','teste1','teste1','viewer','2026-09-02 09:39:37',NULL,'2026-09-02 09:39:41'),('966ca61f3b154c7cb19c3a29518df6b2','ee4bfd02','0b18a3bc4c671dd5c3985746a7028ec3','Administrador','admin','admin','2026-09-02 08:56:41','2026-09-02 08:56:46',NULL),('a18bbfabeb614abf9817ddc512ccdf1c','95b7377b','0674d3d12a4fd7e2ab46fc33f2f1bd98','teste1','teste1','viewer','2026-09-03 11:18:19','2026-09-03 11:18:22',NULL),('ba1cc413cafb4082824304149117d43a','ee4bfd02','4f22329e2a5580cf343af92b5feb8d4d','Administrador','admin','admin','2026-09-03 11:18:52','2026-09-03 11:18:54',NULL),('dab582bca931422cb52b8e932711fbbc','60cd6f66','b6406b4f89263c7ace95ecaf250d3fd9','Rodrigo Augusto Mazzetto','rodrigo.mazzetto','viewer','2026-09-01 23:01:51',NULL,'2026-09-01 23:01:52'),('dab582bca931422cb52b8e932711fbbc','ee4bfd02','52ec2ed02a8418c9e97575383b126ca1','Administrador','admin','admin','2026-09-01 23:01:33','2026-09-01 23:01:40',NULL),('f4b20a5290c44c5c88c7c350098b2946','6afac0da400348f4b35ebf9c64a29fbe','1aed808a734de7291d27bdbe99be553f','rodrigo.mazzetto','login.master','master','2026-09-01 23:42:51','2026-09-01 23:43:01',NULL),('f4b20a5290c44c5c88c7c350098b2946','ee4bfd02','67ba37b43e2e4fdac82bc7e42d674ed6','Administrador','admin','admin','2026-09-01 23:07:26','2026-09-01 23:07:30',NULL);
/*!40000 ALTER TABLE `avisos_eventos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `avisos_publicacoes`
--

DROP TABLE IF EXISTS `avisos_publicacoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `avisos_publicacoes` (
  `id` varchar(32) NOT NULL,
  `texto` text NOT NULL,
  `publicado_em` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `assunto` varchar(120) NOT NULL DEFAULT 'Sem assunto',
  `ambiente_id` varchar(32) NOT NULL DEFAULT 'inicial',
  PRIMARY KEY (`id`),
  KEY `idx_ambiente` (`ambiente_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `avisos_publicacoes`
--

LOCK TABLES `avisos_publicacoes` WRITE;
/*!40000 ALTER TABLE `avisos_publicacoes` DISABLE KEYS */;
INSERT INTO `avisos_publicacoes` VALUES ('5a73e48282b843c78aa1310029808127','Iremos realizar uma manutenção preventiva na data 05/09/2026, dessa forma o Portal Bi ficará indisponível.','2026-09-02 21:59:04','Lembrete','inicial'),('966ca61f3b154c7cb19c3a29518df6b2','Iremos realizar uma manutenção preventiva na data 05/09/2026, dessa forma o Portal Bi ficará indisponível.','2026-09-02 08:55:56','Manutenção - 05/09/2026','inicial'),('a18bbfabeb614abf9817ddc512ccdf1c','teste','2026-09-03 11:18:17','teste','459565b333e94f6fb2b118b80520fd4b'),('ba1cc413cafb4082824304149117d43a','teste_2','2026-09-03 11:18:40','teste_2','459565b333e94f6fb2b118b80520fd4b'),('bdec152c2dcc41e38a10863b186cf650','teste','2026-09-03 11:11:48','teste','inicial'),('da609ce6d2984fdc858d51a0e0e50428','Iremos realizar uma manutenção preventiva na data 05/09/2026, dessa forma o Portal Bi ficará indisponível.','2026-09-03 10:58:17','Lembrete','inicial'),('dab582bca931422cb52b8e932711fbbc','teste','2026-09-01 22:15:14','Sem assunto','inicial'),('f4b20a5290c44c5c88c7c350098b2946','teste novamente','2026-09-01 23:07:25','Teste novamente','inicial');
/*!40000 ALTER TABLE `avisos_publicacoes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dashboards`
--

DROP TABLE IF EXISTS `dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dashboards` (
  `id` varchar(32) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `descricao` text,
  `embed_url` text NOT NULL,
  `pasta_id` varchar(32) DEFAULT NULL,
  `subpasta_id` varchar(32) DEFAULT NULL,
  `criado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ativo` tinyint(1) NOT NULL DEFAULT '1',
  `permitir_favoritar` tinyint(1) NOT NULL DEFAULT '1',
  `ordem_exibicao` int NOT NULL DEFAULT '0',
  `cadastrado_por` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pasta_id` (`pasta_id`),
  KEY `fk_dashboards_subpasta` (`subpasta_id`),
  CONSTRAINT `dashboards_ibfk_1` FOREIGN KEY (`pasta_id`) REFERENCES `pastas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_dashboards_subpasta` FOREIGN KEY (`subpasta_id`) REFERENCES `subpastas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboards`
--

LOCK TABLES `dashboards` WRITE;
/*!40000 ALTER TABLE `dashboards` DISABLE KEYS */;
INSERT INTO `dashboards` VALUES ('1d4be6de','Painel de Assiduidade','','https://app.powerbi.com/view?r=eyJrIjoiYThiOTBiNjgtYzllOS00MThlLTg3MWYtMjRmZWZhYjc2MmNmIiwidCI6IjdmNmNhMDNjLTA0OTUtNDUwMy04ZTQ1LTUxZGZjZjZmMzhkZiJ9','cd612645','db1f5ee1','2026-08-30 16:38:17',1,1,0,NULL),('288c7bee','Painel de Assiduidade','','https://app.powerbi.com/view?r=eyJrIjoiMGE0NTY0MGMtNDdlYi00ODg4LTk3MzctYTlkZTFiMmM1ZjE1IiwidCI6IjdmNmNhMDNjLTA0OTUtNDUwMy04ZTQ1LTUxZGZjZjZmMzhkZiJ9','4e971334','dc5e5358','2026-08-30 16:33:00',1,1,0,NULL),('3337f5ac','Painel de Assiduidade','','https://app.powerbi.com/view?r=eyJrIjoiZWJkNTJjZDQtMWIzNC00MjA5LWE4MWQtNzg1NjE3M2U2ZmQxIiwidCI6IjdmNmNhMDNjLTA0OTUtNDUwMy04ZTQ1LTUxZGZjZjZmMzhkZiJ9','fd9f8b5e','e78f6deb','2026-08-31 17:03:20',1,1,0,NULL),('4eaad977','Painel de Assiduidade','','https://app.powerbi.com/view?r=eyJrIjoiOWEyYjNkYjgtMDk5NC00YTI3LWI0ZDAtNzUwZDc5Zjg4YzBlIiwidCI6IjdmNmNhMDNjLTA0OTUtNDUwMy04ZTQ1LTUxZGZjZjZmMzhkZiJ9','b3c2cbf4','f6e0a0be','2026-08-31 20:06:37',1,1,0,NULL),('6f096245','Faturamento','','https://app.powerbi.com/view?r=eyJrIjoiMjkwNDdjZjctNDc0Yy00Mzg1LWE5YzUtYjk2MzI3OGJiNGI5IiwidCI6IjdmNmNhMDNjLTA0OTUtNDUwMy04ZTQ1LTUxZGZjZjZmMzhkZiJ9','b3c2cbf4','34a99ae2','2026-08-31 20:07:46',1,1,0,NULL),('9ffde92c','Acompanhamento Técnico','','https://app.powerbi.com/view?r=eyJrIjoiYmEyZGU5MzEtYzY2Ni00M2E2LWFlMGEtMTBmNGJkZDQyNjJmIiwidCI6IjdmNmNhMDNjLTA0OTUtNDUwMy04ZTQ1LTUxZGZjZjZmMzhkZiJ9','b3c2cbf4','011036fa','2026-08-31 20:09:03',1,1,0,NULL),('dcd59548','Painel de Execução','','https://app.powerbi.com/view?r=eyJrIjoiOWM5NGFjMDEtNTQ1Yy00MjlmLTlkZjctNjBmNDdkYjEzN2FhIiwidCI6IjdmNmNhMDNjLTA0OTUtNDUwMy04ZTQ1LTUxZGZjZjZmMzhkZiJ9','b3c2cbf4','82e9cded','2026-08-31 19:36:18',1,1,0,NULL),('f58d38bd','Pesquisa de Vendas','','https://app.powerbi.com/view?r=eyJrIjoiOWRkNzFkZWMtMjQ4MS00MGQ1LWE5MjQtMjQyODMwZDNiZWNiIiwidCI6IjdmNmNhMDNjLTA0OTUtNDUwMy04ZTQ1LTUxZGZjZjZmMzhkZiJ9','4e971334','1553d63f','2026-08-30 16:17:47',1,1,0,NULL);
/*!40000 ALTER TABLE `dashboards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `favoritos`
--

DROP TABLE IF EXISTS `favoritos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `favoritos` (
  `usuario_id` varchar(32) NOT NULL,
  `dashboard_id` varchar(32) NOT NULL,
  PRIMARY KEY (`usuario_id`,`dashboard_id`),
  KEY `dashboard_id` (`dashboard_id`),
  CONSTRAINT `favoritos_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `favoritos_ibfk_2` FOREIGN KEY (`dashboard_id`) REFERENCES `dashboards` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `favoritos`
--

LOCK TABLES `favoritos` WRITE;
/*!40000 ALTER TABLE `favoritos` DISABLE KEYS */;
INSERT INTO `favoritos` VALUES ('ee4bfd02','1d4be6de'),('6afac0da400348f4b35ebf9c64a29fbe','288c7bee'),('ee4bfd02','288c7bee'),('ee4bfd02','3337f5ac'),('ee4bfd02','6f096245'),('ee4bfd02','9ffde92c'),('6afac0da400348f4b35ebf9c64a29fbe','f58d38bd'),('ee4bfd02','f58d38bd');
/*!40000 ALTER TABLE `favoritos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pastas`
--

DROP TABLE IF EXISTS `pastas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pastas` (
  `id` varchar(32) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `criado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ambiente_id` varchar(32) NOT NULL DEFAULT 'inicial',
  PRIMARY KEY (`id`),
  KEY `idx_ambiente` (`ambiente_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pastas`
--

LOCK TABLES `pastas` WRITE;
/*!40000 ALTER TABLE `pastas` DISABLE KEYS */;
INSERT INTO `pastas` VALUES ('4e971334','Mawwal','2026-08-30 16:17:21','inicial'),('84ad89cb','Nestlé','2026-09-03 17:14:14','139fec16091c410cae525b696fd400f4'),('b3c2cbf4','Nestlé','2026-08-31 19:34:16','inicial'),('cd612645','Flora','2026-08-30 16:38:09','inicial'),('fd9f8b5e','Puratos','2026-08-31 17:03:06','inicial');
/*!40000 ALTER TABLE `pastas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portal_master_controle`
--

DROP TABLE IF EXISTS `portal_master_controle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `portal_master_controle` (
  `id` tinyint NOT NULL,
  `usuario_id` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portal_master_controle`
--

LOCK TABLES `portal_master_controle` WRITE;
/*!40000 ALTER TABLE `portal_master_controle` DISABLE KEYS */;
INSERT INTO `portal_master_controle` VALUES (1,'6afac0da400348f4b35ebf9c64a29fbe');
/*!40000 ALTER TABLE `portal_master_controle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portal_migracoes`
--

DROP TABLE IF EXISTS `portal_migracoes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `portal_migracoes` (
  `chave` varchar(120) NOT NULL,
  `executada_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`chave`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portal_migracoes`
--

LOCK TABLES `portal_migracoes` WRITE;
/*!40000 ALTER TABLE `portal_migracoes` DISABLE KEYS */;
INSERT INTO `portal_migracoes` VALUES ('viewer_todos_clientes_v2','2026-09-01 13:55:20');
/*!40000 ALTER TABLE `portal_migracoes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subpastas`
--

DROP TABLE IF EXISTS `subpastas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `subpastas` (
  `id` varchar(32) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `pasta_id` varchar(32) NOT NULL,
  `parent_subpasta_id` varchar(32) DEFAULT NULL,
  `criado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_subpastas_pasta` (`pasta_id`),
  KEY `fk_subpastas_parent` (`parent_subpasta_id`),
  CONSTRAINT `fk_subpastas_parent` FOREIGN KEY (`parent_subpasta_id`) REFERENCES `subpastas` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_subpastas_pasta` FOREIGN KEY (`pasta_id`) REFERENCES `pastas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subpastas`
--

LOCK TABLES `subpastas` WRITE;
/*!40000 ALTER TABLE `subpastas` DISABLE KEYS */;
INSERT INTO `subpastas` VALUES ('011036fa','Técnico','b3c2cbf4',NULL,'2026-08-31 20:08:47'),('1553d63f','Pesquisa de Vendas','4e971334',NULL,'2026-08-31 19:30:05'),('34a99ae2','Faturamento','b3c2cbf4','6985a61e','2026-08-31 20:07:32'),('6985a61e','Culinarista','b3c2cbf4',NULL,'2026-08-31 19:34:41'),('82e9cded','Painel de Execução','b3c2cbf4','6985a61e','2026-08-31 20:03:08'),('db1f5ee1','Assiduidade','cd612645',NULL,'2026-08-31 19:31:40'),('dc5e5358','Assiduidade','4e971334',NULL,'2026-08-31 19:30:58'),('e78f6deb','Assiduidade','fd9f8b5e',NULL,'2026-08-31 19:32:00'),('f6e0a0be','Painel de Assiduidade','b3c2cbf4','6985a61e','2026-08-31 20:05:53');
/*!40000 ALTER TABLE `subpastas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario_dashboard_bloqueios`
--

DROP TABLE IF EXISTS `usuario_dashboard_bloqueios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario_dashboard_bloqueios` (
  `usuario_id` varchar(32) NOT NULL,
  `dashboard_id` varchar(32) NOT NULL,
  `criado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`usuario_id`,`dashboard_id`),
  KEY `idx_udb_dashboard` (`dashboard_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario_dashboard_bloqueios`
--

LOCK TABLES `usuario_dashboard_bloqueios` WRITE;
/*!40000 ALTER TABLE `usuario_dashboard_bloqueios` DISABLE KEYS */;
/*!40000 ALTER TABLE `usuario_dashboard_bloqueios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario_dashboards`
--

DROP TABLE IF EXISTS `usuario_dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario_dashboards` (
  `usuario_id` varchar(32) NOT NULL,
  `dashboard_id` varchar(32) NOT NULL,
  PRIMARY KEY (`usuario_id`,`dashboard_id`),
  KEY `dashboard_id` (`dashboard_id`),
  CONSTRAINT `usuario_dashboards_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `usuario_dashboards_ibfk_2` FOREIGN KEY (`dashboard_id`) REFERENCES `dashboards` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario_dashboards`
--

LOCK TABLES `usuario_dashboards` WRITE;
/*!40000 ALTER TABLE `usuario_dashboards` DISABLE KEYS */;
INSERT INTO `usuario_dashboards` VALUES ('ee4bfd02','288c7bee'),('ee4bfd02','f58d38bd');
/*!40000 ALTER TABLE `usuario_dashboards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario_eventos`
--

DROP TABLE IF EXISTS `usuario_eventos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario_eventos` (
  `id` varchar(32) NOT NULL,
  `data_hora` varchar(19) NOT NULL,
  `ator_id` varchar(32) DEFAULT NULL,
  `ator_nome` varchar(255) DEFAULT NULL,
  `tipo` varchar(40) NOT NULL,
  `usuario_id` varchar(32) DEFAULT NULL,
  `usuario_nome` varchar(255) DEFAULT NULL,
  `detalhe` varchar(500) DEFAULT NULL,
  `ambiente_id` varchar(32) NOT NULL DEFAULT 'inicial',
  PRIMARY KEY (`id`),
  KEY `idx_usuario_eventos_data` (`data_hora`),
  KEY `idx_usuario_eventos_usuario` (`usuario_id`),
  KEY `idx_ambiente` (`ambiente_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario_eventos`
--

LOCK TABLES `usuario_eventos` WRITE;
/*!40000 ALTER TABLE `usuario_eventos` DISABLE KEYS */;
INSERT INTO `usuario_eventos` VALUES ('01770675','2026-09-02 10:21:26','6afac0da400348f4b35ebf9c64a29fbe','rodrigo.mazzetto','guias_atualizadas','ee4bfd02','Administrador','Guias: cadastro, dashboards, dashboards_administracao, minha_conta, usuarios_administracao, usuarios_cadastro','inicial'),('0c3cf3a2','2026-09-02 08:36:48','6afac0da400348f4b35ebf9c64a29fbe','rodrigo.mazzetto','usuario_excluido','6a022513','Samaly','Conta removida do portal','inicial'),('0eda1cf4','2026-09-03 08:24:02','6afac0da400348f4b35ebf9c64a29fbe','rodrigo.mazzetto','permissoes_atualizadas','ee4bfd02','Administrador','1 cliente(s), 2 divisão/tema(s), 2 dashboard(s) marcado(s); 0 exceção(ões) de estrutura e 0 dashboard(s) bloqueado(s)','inicial'),('10001169','2026-09-01 22:23:57','ee4bfd02','Administrador','usuario_editado','6a022513','Samaly','Campos alterados: senha','inicial'),('155dff26','2026-09-03 08:04:09','6afac0da400348f4b35ebf9c64a29fbe','rodrigo.mazzetto','usuario_editado','95b7377b','teste1','Campos alterados: e-mail','inicial'),('1b968986','2026-09-02 09:05:26','6afac0da400348f4b35ebf9c64a29fbe','rodrigo.mazzetto','guias_atualizadas','ee4bfd02','Administrador','Guias: cadastro, dashboards, dashboards_administracao, minha_conta, usuarios, usuarios_administracao, usuarios_cadastro','inicial'),('25b70edf','2026-09-03 14:55:46','6afac0da400348f4b35ebf9c64a29fbe','rodrigo.mazzetto','usuario_excluido','0de52dd703034be19b09306b9f7278db','Rodrigo Augusto Mazzetto','Conta removida do portal','__global__'),('317b8d29','2026-09-01 16:36:54','9b93866b','teste_1','primeira_senha_alterada','9b93866b','teste_1','Troca obrigatória concluída','inicial'),('429ebb9e','2026-09-01 16:35:52','ee4bfd02','Administrador','usuario_criado','9b93866b','teste_1','Perfil: Visualizador','inicial'),('44e1f42782e4493a9c822e8302ef5b5d','2026-09-02 14:33:27','6afac0da400348f4b35ebf9c64a29fbe','rodrigo.mazzetto','usuario_criado','0de52dd703034be19b09306b9f7278db','Rodrigo Augusto Mazzetto','Importação XLSX. Perfil: Visualizador. Login: rodrigo.mazzetto','inicial'),('620431f8','2026-09-02 14:32:18','6afac0da400348f4b35ebf9c64a29fbe','rodrigo.mazzetto','usuario_excluido','9e8ec7464bc948e48f7ee990a80b621c','Rodrigo Augusto Mazzetto','Conta removida do portal','inicial'),('6cb7caed','2026-09-01 23:44:10','6afac0da400348f4b35ebf9c64a29fbe','rodrigo.mazzetto','guias_atualizadas','ee4bfd02','Administrador','Guias: acessos, cadastro, dashboards, dashboards_administracao, minha_conta, usuarios, usuarios_administracao, usuarios_cadastro','inicial'),('6e176b0d','2026-09-03 08:04:25','6afac0da400348f4b35ebf9c64a29fbe','rodrigo.mazzetto','usuario_editado','95b7377b','teste1','Campos alterados: e-mail','inicial'),('84380ab4','2026-09-02 22:49:56','6afac0da400348f4b35ebf9c64a29fbe','rodrigo.mazzetto','permissoes_atualizadas','5ff1f9abf4ee49298bdd0a2f4d95b892','Samaly Aghata Constantino','1 cliente(s), 1 divisão/tema(s), 1 dashboard(s) marcado(s); 0 exceção(ões) de estrutura e 0 dashboard(s) bloqueado(s)','inicial'),('84569c127dc4443bb1c09eb421bc1757','2026-09-02 22:46:52','6afac0da400348f4b35ebf9c64a29fbe','rodrigo.mazzetto','usuario_criado','5ff1f9abf4ee49298bdd0a2f4d95b892','Samaly Aghata Constantino','Importação XLSX. Perfil: Visualizador. Login: samaly.constantino','inicial'),('9c90bafd7a4d44cd9abeb8b7da5cf62b','2026-09-02 14:19:42','6afac0da400348f4b35ebf9c64a29fbe','rodrigo.mazzetto','usuario_criado','9e8ec7464bc948e48f7ee990a80b621c','Rodrigo Augusto Mazzetto','Importação XLSX. Perfil: Visualizador. Login: rodrigo.mazzetto','inicial'),('a1e66f0f','2026-09-03 14:18:01','7becc38bd3464e7991dfd56add38bed1','Rodrigo Augusto','primeira_senha_alterada','7becc38bd3464e7991dfd56add38bed1','Rodrigo Augusto','Troca obrigatória concluída','__sem_ambiente__'),('b1c5fee0','2026-09-01 20:32:04','ee4bfd02','Administrador','usuario_excluido','9b93866b','teste_1','Conta removida do portal','inicial'),('b4488f08ceaf4ffea88a4ced996c9712','2026-09-03 14:16:53','ee4bfd02','Administrador','usuario_criado','7becc38bd3464e7991dfd56add38bed1','Rodrigo Augusto','Cadastro individual. Perfil: Visualizador. Login: rodrigo.augusto','139fec16091c410cae525b696fd400f4'),('b99dc4c8','2026-09-01 20:32:46','ee4bfd02','Administrador','usuario_criado','6a022513','Samaly','Perfil: Visualizador','inicial'),('be510404','2026-09-02 08:36:43','6afac0da400348f4b35ebf9c64a29fbe','rodrigo.mazzetto','usuario_excluido','60cd6f66','Rodrigo Augusto Mazzetto','Conta removida do portal','inicial'),('c64b07fd','2026-09-03 08:04:42','6afac0da400348f4b35ebf9c64a29fbe','rodrigo.mazzetto','usuario_excluido','5ff1f9abf4ee49298bdd0a2f4d95b892','Samaly Aghata Constantino','Conta removida do portal','inicial'),('e9b275c0','2026-09-02 22:48:45','5ff1f9abf4ee49298bdd0a2f4d95b892','Samaly Aghata Constantino','primeira_senha_alterada','5ff1f9abf4ee49298bdd0a2f4d95b892','Samaly Aghata Constantino','Troca obrigatória concluída','inicial'),('f05f9882','2026-09-01 20:34:16','6a022513','Samaly','primeira_senha_alterada','6a022513','Samaly','Troca obrigatória concluída','inicial');
/*!40000 ALTER TABLE `usuario_eventos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario_guias`
--

DROP TABLE IF EXISTS `usuario_guias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario_guias` (
  `usuario_id` varchar(32) NOT NULL,
  `guias_json` text NOT NULL,
  PRIMARY KEY (`usuario_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario_guias`
--

LOCK TABLES `usuario_guias` WRITE;
/*!40000 ALTER TABLE `usuario_guias` DISABLE KEYS */;
INSERT INTO `usuario_guias` VALUES ('ee4bfd02','[\"cadastro\", \"dashboards\", \"dashboards_administracao\", \"minha_conta\", \"usuarios_administracao\", \"usuarios_cadastro\"]');
/*!40000 ALTER TABLE `usuario_guias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario_pastas`
--

DROP TABLE IF EXISTS `usuario_pastas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario_pastas` (
  `usuario_id` varchar(32) NOT NULL,
  `pasta_id` varchar(32) NOT NULL,
  PRIMARY KEY (`usuario_id`,`pasta_id`),
  KEY `pasta_id` (`pasta_id`),
  CONSTRAINT `usuario_pastas_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `usuario_pastas_ibfk_2` FOREIGN KEY (`pasta_id`) REFERENCES `pastas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario_pastas`
--

LOCK TABLES `usuario_pastas` WRITE;
/*!40000 ALTER TABLE `usuario_pastas` DISABLE KEYS */;
INSERT INTO `usuario_pastas` VALUES ('95b7377b','4e971334'),('ee4bfd02','4e971334'),('7becc38bd3464e7991dfd56add38bed1','84ad89cb'),('ee4bfd02','84ad89cb'),('95b7377b','b3c2cbf4'),('95b7377b','cd612645'),('95b7377b','fd9f8b5e');
/*!40000 ALTER TABLE `usuario_pastas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario_permissoes_estado`
--

DROP TABLE IF EXISTS `usuario_permissoes_estado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario_permissoes_estado` (
  `usuario_id` varchar(32) NOT NULL,
  `inicializado` tinyint(1) NOT NULL DEFAULT '1',
  `atualizado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`usuario_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario_permissoes_estado`
--

LOCK TABLES `usuario_permissoes_estado` WRITE;
/*!40000 ALTER TABLE `usuario_permissoes_estado` DISABLE KEYS */;
INSERT INTO `usuario_permissoes_estado` VALUES ('7becc38bd3464e7991dfd56add38bed1',1,'2026-09-03 17:16:53'),('95b7377b',1,'2026-09-01 13:50:23'),('ee4bfd02',1,'2026-09-03 11:24:02');
/*!40000 ALTER TABLE `usuario_permissoes_estado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario_subpasta_bloqueios`
--

DROP TABLE IF EXISTS `usuario_subpasta_bloqueios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario_subpasta_bloqueios` (
  `usuario_id` varchar(32) NOT NULL,
  `subpasta_id` varchar(32) NOT NULL,
  `criado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`usuario_id`,`subpasta_id`),
  KEY `idx_usb_subpasta` (`subpasta_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario_subpasta_bloqueios`
--

LOCK TABLES `usuario_subpasta_bloqueios` WRITE;
/*!40000 ALTER TABLE `usuario_subpasta_bloqueios` DISABLE KEYS */;
/*!40000 ALTER TABLE `usuario_subpasta_bloqueios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario_subpastas`
--

DROP TABLE IF EXISTS `usuario_subpastas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuario_subpastas` (
  `usuario_id` varchar(32) NOT NULL,
  `subpasta_id` varchar(32) NOT NULL,
  PRIMARY KEY (`usuario_id`,`subpasta_id`),
  KEY `subpasta_id` (`subpasta_id`),
  CONSTRAINT `usuario_subpastas_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE,
  CONSTRAINT `usuario_subpastas_ibfk_2` FOREIGN KEY (`subpasta_id`) REFERENCES `subpastas` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario_subpastas`
--

LOCK TABLES `usuario_subpastas` WRITE;
/*!40000 ALTER TABLE `usuario_subpastas` DISABLE KEYS */;
INSERT INTO `usuario_subpastas` VALUES ('ee4bfd02','1553d63f'),('ee4bfd02','dc5e5358');
/*!40000 ALTER TABLE `usuario_subpastas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id` varchar(32) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `usuario` varchar(100) NOT NULL,
  `senha_hash` varchar(255) NOT NULL,
  `papel` varchar(20) NOT NULL,
  `pergunta` varchar(255) DEFAULT NULL,
  `resposta_hash` varchar(255) DEFAULT NULL,
  `criado_em` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `troca_senha_obrigatoria` tinyint(1) NOT NULL DEFAULT '0',
  `email` varchar(254) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `usuario` (`usuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES ('6afac0da400348f4b35ebf9c64a29fbe','rodrigo.mazzetto','login.master','scrypt:32768:8:1$jcazbtbc08wCwEcv$8a7cba7ad348129a76dacb7b453b765556a84c4d8c7e558f1d5a073bbd8db0c306891eb0e44b60bd2491d7acab69bb05734514d596d02d106410623207a601b0','master',NULL,NULL,'2026-09-02 02:42:16',0,NULL),('7becc38bd3464e7991dfd56add38bed1','Rodrigo Augusto','rodrigo.augusto','scrypt:32768:8:1$Hnx8XvrBBhBjEz47$94bf623310533f839d8a179000af417cf9b480c031a169b60880687f7ae45fd4a824f07435f66435f92c0c15270b9ce5bb1362a03a37507d2f9aa1e3296cd5b4','viewer',NULL,NULL,'2026-09-03 17:16:53',0,NULL),('95b7377b','teste1','teste1','scrypt:32768:8:1$F1mc3bvLLNFHGqbK$70cfc81863b99ef23ef162c92fe27fcd4e49030fc02e1d7d941648e82b5a6e73640fd12c1d2222c8d29a0f9956fc1f83f3b90dc119cfb7f84c9d1fd9044676c0','viewer',NULL,NULL,'2026-08-30 16:19:30',0,'teste_1@gmail.com'),('ee4bfd02','Administrador','admin','scrypt:32768:8:1$y7BD8N9116ldZ27H$aaea1ab81dc15b8aa9b35054b7cfa8a5a7fb5eed2e38518909b2ac35adfacdb93de7f2f7f98a54d3a72ac913874fd9f9f3478ec1aefc3010d75f0e52c2feab5d','admin','admin','scrypt:32768:8:1$7QHrt4lKTDKHe18b$a035b826596914a724f4b82b6f8b8a4dc2750afa2ddc7aaa3fedfaf8a91bd85f7a8bd689977e59b56ccc58bf168abb0641b6c3ff3ef06985b9233f9e2e227837','2026-08-30 16:03:37',0,NULL);
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'portal_bi'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-03 21:06:06
