# Conta Master e controle de guias

O perfil Master tem todas as funções do administrador, gerencia administradores
e visualizadores e possui a guia exclusiva **Administração**, onde configura as
guias de cada usuário. Administradores continuam gerenciando visualizadores;
a criação, promoção, alteração e exclusão de administradores ficam com o Master.
Nenhum formulário do portal cria, promove, rebaixa ou exclui a conta Master.

## Instalar e criar sua conta

1. Coloque os arquivos `.py` na pasta principal do portal, os `.html` em
   `templates/` e `style.css` em `static/css/`. Os arquivos enviados substituem
   os de mesmo nome; os novos arquivos também precisam ser copiados.
2. Na pasta principal, com o mesmo Python e o `.env` usados pelo portal, execute:

   ```powershell
   python criar_master.py
   ```

   Se usar o Python do caminho informado anteriormente:

   ```powershell
   & "C:\Python314\python.exe" criar_master.py
   ```

3. Informe seu nome, um login exclusivo, um e-mail válido e uma senha de pelo
   menos 12 caracteres, com maiúscula, número e caractere especial. A senha
   não aparece na tela e somente seu hash é gravado no banco. A senha padrão
   de novos usuários não é usada para o Master.
4. Reinicie o portal e entre com a nova conta. As tabelas necessárias são criadas
   automaticamente. Contas já existentes não são convertidas em Master.

O script permite somente uma conta Master. Executá-lo novamente não sobrescreve
nem redefine a conta existente. Não compartilhe as credenciais nem acesso aos
arquivos do servidor/banco: esse acesso permite administrar a aplicação fora dos
controles da interface.

## Configurar acessos

Em **Administração**, selecione um usuário, marque suas guias e clique em
**Salvar acessos**. Use **Gerenciar usuário** para editar nome, login, perfil,
senha e permissões de dashboards pela tela de gestão já existente.

A liberação vale para o menu e para as rotas e operações correspondentes.
Liberar uma guia administrativa também libera as funções dessa guia, mesmo
para um visualizador; somente o Master continua podendo gerenciar
administradores e alterar as liberações de guias. As permissões de conteúdo
por pasta/dashboard continuam válidas para a visualização dos dashboards.

Sem uma configuração personalizada, administradores mantêm suas guias atuais e
visualizadores mantêm **Dashboards** e **Minha conta**. Para alterar os acessos,
selecione as guias manualmente e clique em **Salvar acessos**.
Desmarcar tudo bloqueia as telas, mantendo
login, saída e troca obrigatória de senha no primeiro acesso.

A alteração passa a valer na próxima requisição do usuário; uma página já
carregada pode mostrar o menu antigo até ser atualizada, mas suas operações
passam a ser verificadas imediatamente. A conta Master tem acesso fixo a todas
as guias e não pode se bloquear pela interface. Sua senha é alterada em
**Minha conta**. Os e-mails dos demais usuários são atualizados pelo Master em
**Administração de Usuários**. Para
usar **Esqueci minha senha**, configure também o SMTP e o `PORTAL_URL` conforme
o arquivo `CONFIGURAR_EMAIL_RECUPERACAO.md`.

As configurações de guias são preservadas ao editar contas ou trocar senhas.
O histórico existente do portal é mantido. As alterações das guias são
registradas na auditoria de usuários.
