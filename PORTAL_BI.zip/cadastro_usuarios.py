"""Regras comuns ao cadastro individual e à importação de novos usuários."""
import io
import base64
import re
import unicodedata
from zipfile import ZipFile, BadZipFile

from openpyxl import load_workbook

LIMITE_USUARIOS = 200
LIMITE_ARQUIVO = 5 * 1024 * 1024


def sem_acentos(texto):
    return ''.join(c for c in unicodedata.normalize('NFD', texto)
                   if unicodedata.category(c) != 'Mn')


def gerar_login(nome):
    if not isinstance(nome, str):
        raise ValueError('Informe o nome completo como texto.')
    partes = nome.split()
    if len(partes) < 2:
        raise ValueError('Informe pelo menos o primeiro nome e o sobrenome.')
    if len(' '.join(partes)) > 255:
        raise ValueError('O nome completo deve ter no máximo 255 caracteres.')
    if any(not (c.isalpha() or c.isspace() or c in "-'’") for c in nome):
        raise ValueError('O nome deve conter apenas letras, espaços, hífen ou apóstrofo.')
    primeiro, ultimo = [re.sub(r'[^a-z]', '', sem_acentos(p).lower())
                         for p in (partes[0], partes[-1])]
    if not primeiro or not ultimo:
        raise ValueError('O primeiro nome e o último sobrenome devem conter letras de A a Z.')
    login = primeiro + '.' + ultimo
    if len(login) > 100:
        raise ValueError('O login gerado ultrapassa o limite de 100 caracteres.')
    return login


def validar_email(valor, obrigatorio=False):
    """Valida e normaliza um e-mail, sem consultar ou enviar mensagens."""
    if valor is None or (isinstance(valor, str) and not valor.strip()):
        if obrigatorio:
            raise ValueError('O e-mail é obrigatório.')
        return None
    if not isinstance(valor, str):
        raise ValueError('Preencha o e-mail como texto.')
    email = valor.strip()
    if email.count('@') != 1:
        raise ValueError('E-mail inválido. Exemplo: nome@empresa.com.br.')
    local, dominio = email.rsplit('@', 1)
    try:
        dominio = dominio.encode('idna').decode('ascii').lower()
    except UnicodeError:
        raise ValueError('O domínio do e-mail é inválido.') from None
    if (not re.fullmatch(r"[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+", local)
            or len(local) > 64 or local.startswith('.') or local.endswith('.') or '..' in local
            or '.' not in dominio or any(not re.fullmatch(r'[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?', p)
                                         for p in dominio.split('.'))
            or len(local + '@' + dominio) > 254):
        raise ValueError('E-mail inválido. Exemplo: nome@empresa.com.br (até 254 caracteres).')
    return local + '@' + dominio


def ler_importacao(conteudo, usuarios_existentes, permite_admin=False):
    """Retorna linhas válidas e erros; não grava nada no banco."""
    if not conteudo or len(conteudo) > LIMITE_ARQUIVO:
        raise ValueError('Selecione um arquivo .xlsx de até 5 MB.')
    try:
        with ZipFile(io.BytesIO(conteudo)) as arquivo:
            itens = arquivo.infolist()
            if len(itens) > 200 or sum(i.file_size for i in itens) > 20 * 1024 * 1024:
                raise ValueError('A planilha excede o tamanho permitido. Use o modelo do portal.')
            if any(i.flag_bits & 1 for i in itens):
                raise ValueError('Envie uma planilha sem senha.')
    except BadZipFile as exc:
        raise ValueError('Arquivo inválido. Envie uma planilha no formato .xlsx.') from exc
    try:
        wb = load_workbook(io.BytesIO(conteudo), read_only=True, data_only=False, keep_links=False)
    except Exception as exc:
        raise ValueError('Não foi possível ler a planilha. Baixe o modelo e salve como .xlsx sem senha.') from exc
    try:
        if 'Usuarios' not in wb.sheetnames:
            raise ValueError('A aba "Usuarios" não foi encontrada. Use o modelo do portal.')
        ws = wb['Usuarios']
        # Limita a leitura inclusive quando as dimensões do XML estão incorretas.
        ws.reset_dimensions()
        linhas = ws.iter_rows(max_row=LIMITE_USUARIOS + 2, max_col=4)
        cabecalho = next(linhas)
        titulos = [c.value for c in cabecalho]
        if titulos != ['Nome completo', 'Perfil', 'E-mail', None]:
            raise ValueError('Use as colunas "Nome completo", "Perfil" e "E-mail" do modelo na aba Usuarios.')
        ocupados = {u['usuario'].casefold() for u in usuarios_existentes}
        emails_ocupados = {
            u['email'].strip().casefold()
            for u in usuarios_existentes
            if isinstance(u.get('email'), str) and u['email'].strip()
        }
        encontrados, emails_encontrados, validos, erros = {}, {}, [], []
        for numero, cells in enumerate(linhas, start=2):
            valores = [c.value for c in cells]
            if all(v is None or (isinstance(v, str) and not v.strip()) for v in valores):
                continue
            erro = None
            login, nome, papel, email = '', valores[0], None, None
            if numero > LIMITE_USUARIOS + 1:
                erro = f'Use somente as linhas 2 a {LIMITE_USUARIOS + 1} (até {LIMITE_USUARIOS} usuários por arquivo).'
            elif any(c.data_type == 'f' for c in cells):
                erro = 'Preencha os dados como texto, sem fórmulas.'
            elif valores[3] is not None:
                erro = 'Preencha somente as colunas previstas no modelo.'
            else:
                try:
                    login = gerar_login(nome)
                    nome = ' '.join(nome.split())
                    email = validar_email(valores[2], obrigatorio=True)
                except ValueError as exc:
                    erro = str(exc)
                perfil = sem_acentos(str(valores[1] or '')).strip().lower()
                papel = {'visualizador': 'viewer', 'administrador': 'admin'}.get(perfil)
                if not erro and papel is None:
                    erro = 'Perfil inválido. Use Visualizador ou Administrador.'
                if not erro and papel == 'admin' and not permite_admin:
                    erro = 'Somente o Master pode cadastrar Administradores.'
                if not erro and login in ocupados:
                    erro = f'O login {login} já existe no portal.'
                if not erro and login in encontrados:
                    erro = f'Login repetido na planilha (também na linha {encontrados[login]}).'
                if not erro and email.casefold() in emails_ocupados:
                    erro = f'O e-mail {email} já está associado a outro usuário.'
                if not erro and email.casefold() in emails_encontrados:
                    erro = f'E-mail repetido na planilha (também na linha {emails_encontrados[email.casefold()]}).'
            registro = {'linha': numero, 'nome': str(nome or '')[:255], 'usuario': login, 'papel': papel, 'email': email}
            if erro:
                erros.append(dict(registro, erro=erro))
            else:
                encontrados[login] = numero
                emails_encontrados[email.casefold()] = numero
                validos.append(registro)
        # Não ignora dados que tenham sido colocados depois da faixa permitida.
        # A leitura é limitada pelo tamanho descompactado verificado acima.
        from xml.etree import ElementTree as ET
        with ZipFile(io.BytesIO(conteudo)) as arquivo:
            with arquivo.open(ws._worksheet_path.lstrip('/')) as xml:
                for _, elem in ET.iterparse(xml, events=('end',)):
                    if elem.tag.endswith('}row'):
                        if int(elem.attrib.get('r', '0')) > LIMITE_USUARIOS + 2 and any(
                                c.tag.endswith(('}v', '}t', '}f')) and c.text
                                for c in elem.iter()):
                            raise ValueError(f'Use somente as linhas 2 a {LIMITE_USUARIOS + 1} da aba Usuarios.')
                        for cell in elem:
                            coluna = re.sub(r'\d', '', cell.attrib.get('r', ''))
                            if coluna not in {'A', 'B', 'C'} and any(
                                    c.tag.endswith(('}v', '}t', '}f')) and c.text for c in cell.iter()):
                                raise ValueError('Preencha somente as colunas previstas no modelo da aba Usuarios.')
                        elem.clear()
        if not validos and not erros:
            raise ValueError('A planilha está vazia. Preencha os usuários a partir da linha 2.')
        return validos, erros
    finally:
        wb.close()


# Modelo XLSX validado (Nome completo, Perfil e E-mail), incorporado para
# o download funcionar sem instalar um arquivo de planilha separado.
_MODELO_USUARIOS_XLSX = (
    "UEsDBBQAAAAIADxxIl2vdDSN3gAAALYBAAAPAAAAeGwvd29ya2Jvb2sueG1stdGxasMwEAbgVxG315ItY4yJkqVL1kAfQJFP"
    "sYilMzq58eOXpiUpnbp0O/7h5+O/3WGLs3jHzIGSgbpSIDA5GkO6GFiLf+nhsN9tw43y9Ux0FVucEw+bgamUZZCS3YTRckUL"
    "pi3OnnK0hSvKF8lLRjvyhFjiLBulOhltSPDZd0/5cYlkIxp449XmQAzinh5HAzWIPITRwMmObaN047WuXYtnDd+W/BcLeR8c"
    "vpJbI6byhck42xIo8RQWBiF/a46JS14d4U9P8/B0jXa918r1qmu7tv0Hj3wOJZ8/2H8AUEsDBBQAAAAIADxxIl200Uby8AEA"
    "AC8LAAANAAAAeGwvc3R5bGVzLnhtbOWWTY/aMBCG/4rle8kHCVshwpaitdTLXnYPvRriBEtjO7LNNvTXV7EdSKlKoVrErjYX"
    "z4z8PnkTx57M7lsB6IVpw5UscDKKMWJyrUou6wJvbfXpM76fz9qpsTtgTxvGLGoFSDNtC7yxtplGkVlvmKBmpBomWwGV0oJa"
    "M1K6jkyjGS1NJxMQpXE8iQTlEndEuRVEWIPWaittgZNBEfnhW1ngNI4x8silKlmBv2AUzWfRXt+pKiUPoBz3Jef7J3qhUOAk"
    "cbp2KqlgvrSkGrhVPa9X9OPKz/8DsFagNNL1qsAkXJeiTzPTLM8X2SszJ+Msu7vKK7gEHQK/aBzgeNE4QDc21FqmJeEAKMTP"
    "u4YVWCrJ9sQw+Z+iWtNdkuYX64wCXnpf9XL4xMkyzceTnjfQvxKfpCQni+vxHx5ISu5O80PgVmqldMn00U71xcAIM9y3wQCe"
    "usPie3WkaKvBvna7Wu5DDhBCjwqJpw+R/S2G9P/Gt9XhPmcB0r8BaNPA7nErVkwTd1h1D+2rRMlhxgEO2VcHc/lJC8ntLQze"
    "wvhGFtIbWQg96A2ZOOebvvJijD+KBZcvgNdSsMNhRvsC+qFp88xaj/IHVludaTt7R7azt2w7dIlBg3AN46gD7euo+08p8GPn"
    "EX7vA8N+Y1x6+PWd/wJQSwMEFAAAAAgAPHEiXfpcAVkDAwAA2g0AABMAAAB4bC90aGVtZS90aGVtZTEueG1svVfbcpswFPwV"
    "Ru8NN3PzhGQSx24f0mmnyQ/IIECNEB5Jjp2/7yBuAozjNHbsB0tiz9lF57DC17f7nGiviHFc0BCYVwbQEI2KGNM0BFuRfPPB"
    "7c01nIsM5UijMEchWGRQfP/9DLR9TiifwxBkQmzmus6jDOWQXxUbRPc5SQqWQ8GvCpbqMYM7TNOc6JZhuHoOMQVt3iVBOaKC"
    "lwsRYU/RAbLyWvxilj/8jS8I014hCcEO07jYPaO9ABqBXCwIC4EhP0DTb671NoqIiWAlcCU/TWAdEb9YMpCl6zbSWFr+zOwY"
    "JIKIMXDpl98uo0TAKEK0lqOCTcc1fKsBK6hqeCB74Jn2IEBhsMcMgXtvzfoBElUNZ+MbXQXLB6cfIFHV0BkF3BnWfWD3AySq"
    "GrqjgNnyzrOW/QCJygimL2O46/m+28BbTFKQHwfxgesa3kOD72C60mpVAip6jfcrSXCEZN/l8G/BVgUVsspQYKqJtw1KYFQ2"
    "KCR4zbD2iNNMSB44R/AdQMSPAvQBZ47puwKOUB8hbek6Bl3dDLk1uZh8JBNMyJN4I+iRS3G8IDheYULkREa1pdhkC8Iawh4w"
    "ZbAb8zpVyrVNwUNggMlc0kEwFdWa6zVPPZyTbf6ziOumN1s7gHMORXfBcBSfaBnkLOWqhhJ3sg7PntDR0Q112CfqkHdyshDf"
    "/LCQ4KgQXSkPwVSD5SnhzGq75REkKC4LVifolfUsJQ5mU3dkfXZrTygxz2CMmrzGlJKpZuu68AxFVqR4/mElQTAhpNyqSxRZ"
    "H9sBof2Ztiv5vebu/sssNoyLB8izCicvtecrVWgCw/kCGqvcmcvR6MM9REmCIjGx0k0fuaizHLz8WXQ5KbYCsacs3mlrsmV/"
    "YBwCxzMdA2gx5qIpgBZj1rXP+P2iW4dkk8HayXsPbYWX45ZTESvlDKX357Xidbo6y3H1ftTAtabs1pt+Ei9wPgbKuaT4R+B/"
    "1FMrqzz3sanqUOVNGq09Ic++kNF2Xfl1hjps2dJjm9cxORv8gWpWbv4BUEsDBBQAAAAIADxxIl0NHrnoZQAAAHMAAAAUAAAA"
    "eGwvc2hhcmVkU3RyaW5ncy54bWwFwVEKwyAMANCrSP5n3D7GkNqeRdq0CiYWkw2Pv/eWbXJzPxpauyR4+gCOZO9HlSvB187H"
    "B7Z1mVHV3OQmGmeCYnZHRN0LcVbfb5LJ7eyDs6nv40K9B+VDC5Fxw1cIb+RcBRyuf1BLAwQUAAAACAA8cSJdSVRyoY4JAACM"
    "SAAAGAAAAHhsL3dvcmtzaGVldHMvc2hlZXQxLnhtbJWcW28b1xVG/8pgnhuTh3cKloJ09wq0RdAH93kijqxBSI7KGVlqf31x"
    "Ro68P++FI/UpOcvmOpaDFVuaj/r44/PpWH1pL0PXn6/r9GFeV+35tj9058/X9eN498Ou/vHm4/PVU3/5dbhv27F6Ph3Pw9Xz"
    "dX0/jg9Xs9lwe9+emuFD/9Cen0/Hu/5yasbhQ3/5PBseLm1zmF52Os4W8/lmdmq6c52FE/3UtU+DnKrhvn/686U7/K07t8N1"
    "Pa+rfPUvff9r/uG/HiY0u/k4Q8Wfptt/vlSH9q55PI7/7J/+0naf78frOq2n1z1f3fbH6QW3/bE6dfmjrqtT8zz986k7jPfX"
    "9WpXV/fd4dCep+tuH4exP/3r5cfSN83LyxdfX754ffli/X+8fPn15ctvty/fevns20cxfdh/aMYmHy79U3WZflL+iJeL3178"
    "+nsw/dbf5p/zU6qrYfpFj9f1MF6mH/ly84/+1Fa3/enh2I59vufLy22vr/s9v+7n9nLXHekFxi/44w+n5rsXzKYPwH0ci5eP"
    "Y7EtfRyLSf/6H3f6NQIzz8JNy/fctISbgNmydNPqPTet4CZgtirdtH7PTWu4CZitSzdt3nPTBm4CZpvSTdv33LSFm4DZtnTT"
    "7j037eAmYLYr3bR/z017uAmY7Us3pfl7rso/K9xF0ATG29K7bkt0G0ATGG9beOlL7BuVAjSBUbr00iVJAZrAKF156YqkAE1g"
    "lK69dE1SgCYwSjdeuiEpQBMYpVsv3ZIUoAmM0p2X7kgK0ARG6d5L9yQFaALjn2lz/2fXHKQETWCUyh+IiaQATWCU+qIWVBRB"
    "ExilvqgFFUXQBEapL2pBRRE0gVHqi8p/o4tSKkpglPqiFlQUQRMYpb6o/H/bKKWiBEapL2pBRRE0gVHqi1pQUQRNYPy7my9q"
    "SUURNIFRKn/xo6IImsAo9UXlv51HKRUlMEp9UUsqiqAJjFJf1JKKImgCo9QXtaSiCJrAKPVFLakogiYwSn1RSyqKoAmMUl/U"
    "kooiaAKj1Be1pKIImsD4OYovakVFETSBUSqf4FBRBE1glPqiVlQUQRMYpb6o/Ml4lFJRAqPUF7WiogiawCj1Ra2oKIImMEp9"
    "USsqiqAJjFJf1IqKImgCo9QXlb9mE6VUlMAo9UWtqCiCJjB+Lu6LWlNRBE1glMon8lQUQRMYpb6oNRVF0ARGqS9qTUURNIFR"
    "6otaU1EETWCU+qLWVBRBExilvqg1FUXQBEapL2pNRRE0gVHqi1pTUQRNYJT6otZUFEETGL/m5IvaUFEETWCUyhesqCiCJjBK"
    "fVEbKoqgCYxSX9SGiiJoAqPUF7WhogiawCj1RW2oKIImMEp9URsqiqAJjFJf1IaKImgCo9QXtaGiCJrAKPVFbagogiYwfm3V"
    "F7WlogiawCiVL8xSUQRNYJT6orZUFEETGKW+qC0VRdAERqkvaktFETSBUeqL2lJRBE1glPqitlQUQRMYpb6oLRVF0ARGqS9q"
    "S0URNIFR6ovaUlEETWB8huCL2lFRBE1glMoDCCqKoAmMUl/UjooiaAKj1Be1o6IImsAo9UXtqCiCJjBKfVE7KoqgCYxSX9SO"
    "iiJoAqPUF7WjogiawCj1Re2oKIImMEp9UTsqiqAJjM/KfFF7KoqgCYxSedBGRRE0gVHqi9pTUQRNYJT6ovZUFEETGKW+qD0V"
    "RdAERqkvak9FETSBUeqL2lNRBE1glPqi9lQUQRMYpb6oPRVF0ARGqS9qT0URNIHwTNgnlU9Ri9SUglgfKlNXSE0piOVR7xyf"
    "9RI1pSCWx71zfN5L1JSCWB75zvGZL1FTCmJ57DvH575ETSmI5dHvHJ/9EjWlIJbHv3N8/kvUlIJYHgHP8RkwUVMKYnkMPMfn"
    "wERNKewjpLyvY4rvxERNKYh1YIHlETWlIJbyeGXBM4s3dhY6tOClBU8t3tha6NiC1xY8t3hjb6GDC15c8OTijc2Fji54dcGz"
    "izd2Fzq84OUFTy/e2F7o+ILXFzy/eGN/oQMMXmDwBKO8wUgywsgnEOMMQymIpTxcYiA1pSDWeRPvm3jgVC5PBhn5RGIsr7zJ"
    "SDLKyCcSY3nlXUaSYUY+kRjLK28zkowz8onEWF55n5FkoJFPJMbyyhuNJCONfCIxllfeaSQZauQTibG88lYjyVgjn0CMcw2l"
    "IJbycLGB1JSCWMrD1QZSUwpiHRfyupDnheXyZLyRTyTG8sr7jSQDjnwiMZZX3nAkGXHkE4mxvPKOI8mQI59IjOWVtxxJxhz5"
    "RGIsr7znSDLoyCcSY3nlTUeSUUc+gRhnHUpBLOXhsgOpKQWxlIfrDqSmFMRSHi48kJpSEOu0l7e9PO4tlydDj3wiMZZX3nok"
    "GXvkE4mxvPLeI8ngI59IjOWVNx9JRh/5RGIsr7z7SDL8yCcSY3nl7UeS8Uc+gRjnH0pBLOXhAgSpKQWxlIcrEKSmFMRSHi5B"
    "kJpSEEt5uAZBakpBrMN6XtbztL5cnoxC8onEWF55F5JkGJJPJMbyytuQJOOQfCIxllfehyQZiOQTibG88kYkyUgkn0CMMxGl"
    "IJbycCmC1JSCWMrDtQhSUwpiKQ8XI0hNKYilPFyNIDWlIJbycDmC1JSCWN/Wwu9r4Te2lMuTAUk+kRjLK29IkoxI8onEWF55"
    "R5JkSJJPJMbyyluSJGOSfAIxzkmUgljKw0UJUlMKYikPVyVITSmIpTxcliA1pSCW8nBdgtSUgljKw4UJUlMKYikPVyZITSmI"
    "9U1l/K4yfltZuTwZm+QTibG88t4kyeAkn0iM5ZU3J0lGJ/kEYpydKAWxlIfLE6SmFMRSHq5PkJpSEEt5uEBBakpBLOXhCgWp"
    "KQWxlIdLFKSmFMRSHq5RkJpSEEt5uEhBakpBrG/p5Pd08ps6y+XJMCWfSIzllbcpScYp+QRinKcoBbGUhwsVpKYUxFIerlSQ"
    "mlIQS3m4VEFqSkEs5eFaBakpBbGUh4sVpKYUxFIerlaQmlIQS3m4XEFqSkEs5eF6BakpBbG+oZrfUc1vqX7jPdX6pmp+VzW/"
    "rbr8vmrZsOQTifGt1bhhmX33/VoOzdh8ao7doRm7/jxUt/3j+fX7I+gPVuN/Htrr+tgNY10N/760d/nuq+n6/LPz9915PDbp"
    "pv7UDY/Nsftvc+gvv/vpcOrO3TBe8qnOv4DXn5gPegeg6XvMPDSf2783l8/deaiO7d14Xc8/bOvq8vLdHKZ/H/uH6d/WdfVL"
    "P4796bfTfdsc2ks+Levqru/H18PL78vrNxa6+R9QSwMEFAAAAAgAPHEiXUTOo2uMBAAADQwAABgAAAB4bC93b3Jrc2hlZXRz"
    "L3NoZWV0Mi54bWyNls1uGzcQx1/ljz21qLP68LcROVUctzVgx4Ydp+fx7shiQnLWJFcSgh7aSx+g6APUyCHIoaegl1z3TfIk"
    "BXdlJXa3kU4Sl5zh/zecGfLxk5nRmLDzSuwg6aXdBGwzyZW9HiRlGD3aSZ7sP57tTcW99mPmgJnR1u/NBsk4hGKv0/HZmA35"
    "VAq2M6NH4gwFn4q77vjCMeW1mdGdfre71TGkbBId1l9fKp76eyP4sUx/dCo/Vpb9IOkmiFtfibyO00d5/amz/7jT6uKHevcz"
    "h5xHVOpwLtOfWF2PwyDpbdZ2s71MdG2QiYZRkTqBoVn9O1V5GA+S/m6CscpztvV2WemDmJ+bud5nN415f27eX5jvrC8z73yW"
    "Uet+RoHiwMkUrl4UJa9v3RkvIOrYZXHNsJfA17uGQeKDq2cm+2en5y+Gx3h6hF9wMHw2vHhxfopnh7i8uKx+Oz86vYh7TxoF"
    "C19PF74abU6mX6iJNGGQbHxVzXrtodd9IKeX4swx22xMrRs3ZjsPrJ4T6Ipw6UtySvwairkPPBfDyMQUmoOs4YzdSGnwGjwj"
    "V74QW/09Yb2Gw0eGlAahIBeUQ07Qyo4J/fSekP/QbqxCu9FO209xrIwK3Mq60co6DNV79LtdlL6sbiMuCnEgd1OqiazBkm+U"
    "e/RB6Hd7KYbNJHIGRfNNnDxdgrW5CtZmO9Z6imO5VhZUBjHVbVCZtBJuthKeOWVYOYGNh/cdqo86KCPwcuU4flsDm1hL1Uef"
    "lZo8GJ4NKGMbxC8B21oFbKsd7HDGptCCb2z1VqBMIS6Q+7aVbauV7YScIhxochRT7ELpCeHT73/AxInUx/HX9W+von+7Xf9G"
    "Oq+AVsXbrYovPeOl8iVp9YZycZASw9woq3xw8UOKCzFsA0NwQj6wQyE5I3OK3P2l7FOcgptSq95DikyJJQ2OFZspT4jmzZ0g"
    "mFS3WuWy5EB3VgnITntANlNccKxyZVWmqD0uO+09Rybyfa+/jk+//ongJCPIlVPXFKoP8YytoLhLZMrY+2Ucu6tw7LZzbM0r"
    "zsNxwUHl4ltRdltRTmMHCaRBhdhA0I2rm5LxqroFz5QPbOLBU0GOs1h9pHxsJ6UhTPgNLKHQZJUe0xLMqH05Z1zVBrqd4iVp"
    "lVP1rnrb3lTmpg8hLxhjKSfswM5J7CA3Jembkl3TLtdg2Y5Ls+ir8OyqW2SUU5O+KQ7EOfWKwPPaZ1iZUJ38y6h7K1H32ql3"
    "6ro1yvvqH/bzZFXtRzz38RD/yxLmmCYZX8UznefmXQGg+sujIB/Ix5KcKB9iH54nSIrhq9IHRs6FKB+D+Lm+6xOJOXF5dzEt"
    "i0l/pZj022Oym+LQTlTsOvO7rz0c/fZsID2pHwaCdKb9rL5AfN0KGJlWMffZ4Gje4r+4bK3goEmJB7B4HvlLzxhVH5ypLyYb"
    "ryUd2DHEI6Mrrt6RHv9faO4eqXfPO8Pumg9YNy+/xQiORzEye/Ed1rzA7q8s6JpPyNVVrHkUBkk33U7gmujW/4MU9b/NBFcS"
    "gpi70ZgpZxdH6wlGImExaHZavOz3/wVQSwMEFAAAAAAAPHEiXQyki+MoAQAAKAEAAAsAAABfcmVscy8ucmVsc++7vzw/eG1s"
    "IHZlcnNpb249IjEuMCIgZW5jb2Rpbmc9InV0Zi04Ij8+PFJlbGF0aW9uc2hpcHMgeG1sbnM9Imh0dHA6Ly9zY2hlbWFzLm9w"
    "ZW54bWxmb3JtYXRzLm9yZy9wYWNrYWdlLzIwMDYvcmVsYXRpb25zaGlwcyI+PFJlbGF0aW9uc2hpcCBUeXBlPSJodHRwOi8v"
    "c2NoZW1hcy5vcGVueG1sZm9ybWF0cy5vcmcvb2ZmaWNlRG9jdW1lbnQvMjAwNi9yZWxhdGlvbnNoaXBzL29mZmljZURvY3Vt"
    "ZW50IiBUYXJnZXQ9Ii94bC93b3JrYm9vay54bWwiIElkPSJSN2ZlNzhjNmU2NWRhNGExYyIgLz48L1JlbGF0aW9uc2hpcHM+"
    "UEsDBBQAAAAIADxxIl0PD9ZzIgEAAJEDAAAaAAAAeGwvX3JlbHMvd29ya2Jvb2sueG1sLnJlbHPN0z9OwzAUBvCrWN6J/zZ1"
    "UdMuLKylF3Cd5yRqbEe2C+nZGDgSV0BQhBLEwFKpi4fP0qef35PfX9/W29H16Bli6oKvMCsoRuBNqDvfVPiU7Z3C2816B73O"
    "XfCp7YaERtf7VOE25+GekGRacDoVYQA/ut6G6HRORYgNGbQ56gYIp7QkcdqB551ofx7gP43B2s7AQzAnBz7/UUxSPveQMNrr"
    "2ECuMBn776wYXY/RY13hHRNWaWa45QstjaoxIlcD5RYczD1f0eVkE5WoNVfsYEGuqISVvKYqtTpC/ZRj55vf05peTXgrtTR8"
    "oUAsqZCLml2T9xLiMbUAeU77iT8fAJCn09O15FRwKwQzEg7iBnh8wiu5MMoKahQtZSkvyyWzj7X5AFBLAwQUAAAACAA8cSJd"
    "oTvPThsBAADcAwAAEwAAAFtDb250ZW50X1R5cGVzXS54bWy1k0FOwzAQRa8SeYtit10ghJJ2AWwBCS5gOZPEqj22PJOSno0F"
    "R+IKqC6qACFFVduNZzN+7//FfL5/VKvRu2IDiWzAWszlTBSAJjQWu1oM3JY3YrWsXrcRqBi9Q6pFzxxvlSLTg9ckQwQcvWtD"
    "8ppJhtSpqM1ad6AWs9m1MgEZkEveMcSyuodWD46Lh5EB99rRO1Hc7fd2qlroGJ01mm1AtcHmj6QMbWsNNMEMHpAlxQS6oR6A"
    "vZN5Sq8tXmWw+teZwNFx0u9WMoHLO9TbSAfF0wZSsg0Uzzrxo/ZQCzU6Rbx1QPLMDTN0Ss09eNi/85MDZMxk2V4naF44WezO"
    "3vkneyrIW0jr/JFUHqf3/x3mwD82yOLiQVS+1eUXUEsBAhQDFAAAAAgAPHEiXa90NI3eAAAAtgEAAA8AAAAAAAAAAAAAAKSB"
    "AAAAAHhsL3dvcmtib29rLnhtbFBLAQIUAxQAAAAIADxxIl200Uby8AEAAC8LAAANAAAAAAAAAAAAAACkgQsBAAB4bC9zdHls"
    "ZXMueG1sUEsBAhQDFAAAAAgAPHEiXfpcAVkDAwAA2g0AABMAAAAAAAAAAAAAAKSBJgMAAHhsL3RoZW1lL3RoZW1lMS54bWxQ"
    "SwECFAMUAAAACAA8cSJdDR656GUAAABzAAAAFAAAAAAAAAAAAAAApIFaBgAAeGwvc2hhcmVkU3RyaW5ncy54bWxQSwECFAMU"
    "AAAACAA8cSJdSVRyoY4JAACMSAAAGAAAAAAAAAAAAAAApIHxBgAAeGwvd29ya3NoZWV0cy9zaGVldDEueG1sUEsBAhQDFAAA"
    "AAgAPHEiXUTOo2uMBAAADQwAABgAAAAAAAAAAAAAAKSBtRAAAHhsL3dvcmtzaGVldHMvc2hlZXQyLnhtbFBLAQIUAxQAAAAA"
    "ADxxIl0MpIvjKAEAACgBAAALAAAAAAAAAAAAAACkgXcVAABfcmVscy8ucmVsc1BLAQIUAxQAAAAIADxxIl0PD9ZzIgEAAJED"
    "AAAaAAAAAAAAAAAAAACkgcgWAAB4bC9fcmVscy93b3JrYm9vay54bWwucmVsc1BLAQIUAxQAAAAIADxxIl2hO89OGwEAANwD"
    "AAATAAAAAAAAAAAAAACkgSIYAABbQ29udGVudF9UeXBlc10ueG1sUEsFBgAAAAAJAAkASQIAAG4ZAAAAAA=="
)


def modelo_usuarios_em_memoria(permite_admin=False):
    """Gera uma cópia independente do modelo com regras atuais de cadastro."""
    modelo = io.BytesIO(base64.b64decode(_MODELO_USUARIOS_XLSX, validate=True))
    # Atualizamos as instruções no momento do download. Assim, instalações
    # antigas não dependem de um arquivo .xlsx físico ao lado do app.
    wb = load_workbook(modelo, data_only=False, keep_links=False)
    instrucoes = wb["Instrucoes"]
    instrucoes["B3"] = "Na aba Usuarios, preencha Nome completo, Perfil e E-mail a partir da linha 2."
    instrucoes["B7"] = "Use Visualizador ou Administrador. Somente o Master pode criar Administradores. O e-mail é obrigatório e precisa ter formato válido."
    usuarios = wb["Usuarios"]
    for validacao in usuarios.data_validations.dataValidation:
        if validacao.formula1 in {'"Visualizador,Administrador"', '"Visualizador,Administrador,Gestor"'}:
            validacao.formula1 = '"Visualizador,Administrador"' if permite_admin else '"Visualizador"'
    if not permite_admin:
        # A opção visual acompanha o perfil do autor. A importação ainda
        # valida todas as linhas no servidor, inclusive planilhas alteradas.
        for validacao in usuarios.data_validations.dataValidation:
            if validacao.formula1 == '"Visualizador,Administrador"':
                validacao.formula1 = '"Visualizador"'
    resultado = io.BytesIO()
    wb.save(resultado)
    wb.close()
    resultado.seek(0)
    return resultado
