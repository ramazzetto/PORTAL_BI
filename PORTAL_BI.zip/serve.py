"""Servidor de produção do Portal BI para uso atrás de Apache/Nginx."""
import os

from waitress import serve

from app import app


def _inteiro_ambiente(nome, padrao, minimo, maximo):
    try:
        valor = int(os.environ.get(nome, str(padrao)))
    except ValueError as erro:
        raise RuntimeError(f"{nome} deve ser um número inteiro.") from erro
    if not minimo <= valor <= maximo:
        raise RuntimeError(f"{nome} deve ficar entre {minimo} e {maximo}.")
    return valor


if __name__ == "__main__":
    serve(
        app,
        host=os.environ.get("PORTAL_HOST", "127.0.0.1"),
        port=_inteiro_ambiente("PORTAL_PORT", 8000, 1, 65535),
        threads=_inteiro_ambiente("PORTAL_THREADS", 16, 4, 128),
        trusted_proxy="127.0.0.1",
        trusted_proxy_count=1,
        trusted_proxy_headers={"x-forwarded-for", "x-forwarded-proto"},
    )
