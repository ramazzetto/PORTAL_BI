@echo off
chcp 65001 >nul
setlocal EnableExtensions EnableDelayedExpansion

set "ORIGEM=C:\Users\RodrigoMazzetto\Downloads"
set "PASTA_PROJETO=C:\Users\RodrigoMazzetto\OneDrive - GNX Group\Área de Trabalho\Portal BI\Principal"

set "PASTA_HTML=%PASTA_PROJETO%\templates"
set "PASTA_CSS=%PASTA_PROJETO%\static\css"
set "PASTA_PY=%PASTA_PROJETO%"
set "PASTA_MD=%PASTA_PROJETO%"

if not exist "%PASTA_HTML%" mkdir "%PASTA_HTML%"
if not exist "%PASTA_CSS%" mkdir "%PASTA_CSS%"

call :mover "*.py" "%PASTA_PY%"
call :mover "*.html" "%PASTA_HTML%"
call :mover "*.css" "%PASTA_CSS%"
call :mover "*.md" "%PASTA_MD%"

echo.
echo Processo concluido.
pause
exit /b

:mover
set "PADRAO=%~1"
set "DESTINO=%~2"
set "ENCONTROU=0"

for /f "delims=" %%F in ('dir /b /a-d "%ORIGEM%\%PADRAO%" 2^>nul') do (
    set "ENCONTROU=1"
    copy /Y "%ORIGEM%\%%F" "%DESTINO%\%%F" >nul

    if errorlevel 1 (
        echo FALHOU: %%F
    ) else (
        del /F /Q "%ORIGEM%\%%F"
        echo OK: %%F
    )
)

if "!ENCONTROU!"=="0" echo Nenhum arquivo %PADRAO% encontrado.
